"use client";

import { useState } from "react";
import dynamic from "next/dynamic";
import BackgroundEffects from "@/components/BackgroundEffects";

// Dynamically import to avoid SSR issues with Three.js
const CircularTower = dynamic(() => import("./CircularTower"), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-black">
      <div className="text-yellow-400 text-xl animate-pulse">Loading Circular Tower...</div>
    </div>
  )
});

const CircleTower = dynamic(() => import("./CircleTower"), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-black">
      <div className="text-yellow-400 text-xl animate-pulse">Loading Circle Tower...</div>
    </div>
  )
});

const HexagonStack = dynamic(() => import("./HexagonStack"), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-black">
      <div className="text-yellow-400 text-xl animate-pulse">Loading Hexagon Stack...</div>
    </div>
  )
});

const ImprovedCircularTower = dynamic(() => import("./ImprovedCircularTower"), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-full bg-black">
      <div className="text-yellow-400 text-xl animate-pulse">Loading Physics Tower...</div>
    </div>
  )
});

export default function BlockTowerBPage() {
  const [selectedMode, setSelectedMode] = useState<'circular' | 'circle' | 'hexagon' | 'physics'>('physics');
  
  const gameModes = [
    {
      id: 'physics',
      name: 'Physics Tower',
      description: 'C-rings with realistic physics - cut pieces fall and bounce!',
      icon: '⟳'
    },
    {
      id: 'circular',
      name: 'Circular Tower',
      description: 'Rotating rings that shrink as you stack - align them perfectly!',
      icon: '⭕'
    },
    {
      id: 'circle',
      name: 'Circle Tower',
      description: 'Circles swing in flower patterns - time the pendulum motion!',
      icon: '◉'
    },
    {
      id: 'hexagon',
      name: 'Hexagon Stack',
      description: 'Six-sided blocks rotate and stack - match the edges!',
      icon: '⬡'
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white relative">
      <BackgroundEffects />
      
      {/* Main Container */}
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-yellow-400 mb-4 font-['Orbitron']">
            BLOCK TOWER B
          </h1>
          <p className="text-gray-400 text-lg">
            Experimental tower building with unique mechanics
          </p>
        </div>

        {/* Game Mode Selector */}
        <div className="max-w-5xl mx-auto mb-6">
          <div className="bg-gray-900/50 backdrop-blur border border-yellow-500/20 rounded-lg p-4">
            <h3 className="text-lg font-bold text-yellow-400 mb-3">Select Game Mode:</h3>
            <div className="grid md:grid-cols-4 gap-4">
              {gameModes.map((mode) => (
                <button
                  key={mode.id}
                  onClick={() => setSelectedMode(mode.id as any)}
                  className={`p-4 rounded-lg border transition-all ${
                    selectedMode === mode.id
                      ? 'bg-yellow-500/20 border-yellow-400 scale-105'
                      : 'bg-gray-800/50 border-gray-600 hover:border-yellow-500/50'
                  }`}
                >
                  <div className="text-3xl mb-2">{mode.icon}</div>
                  <div className="text-yellow-400 font-bold mb-1">{mode.name}</div>
                  <div className="text-xs text-gray-400">{mode.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Game Frame Container */}
        <div className="max-w-5xl mx-auto">
          {/* Game Frame Border */}
          <div className="relative bg-gradient-to-r from-purple-600/20 via-yellow-500/30 to-purple-600/20 p-1 rounded-lg">
            <div className="bg-gray-900 rounded-lg overflow-hidden">
              {/* Game Header Bar */}
              <div className="bg-gradient-to-r from-gray-800 to-gray-900 border-b border-yellow-500/30 p-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <h2 className="text-2xl font-bold text-yellow-400">
                      {gameModes.find(m => m.id === selectedMode)?.name}
                    </h2>
                    <div className="text-sm text-gray-400">
                      Experimental Mode Active
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => window.location.reload()}
                      className="px-4 py-2 bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 rounded border border-purple-600/30 transition-colors"
                    >
                      Reset Game
                    </button>
                  </div>
                </div>
              </div>

              {/* Game Container */}
              <div className="relative" style={{ height: '600px' }}>
                {selectedMode === 'physics' && <ImprovedCircularTower />}
                {selectedMode === 'circular' && <CircularTower />}
                {selectedMode === 'circle' && <CircleTower />}
                {selectedMode === 'hexagon' && <HexagonStack />}
              </div>

              {/* Game Footer */}
              <div className="bg-gradient-to-r from-gray-900 to-gray-800 border-t border-yellow-500/30 p-4">
                <div className="flex justify-between items-center text-sm">
                  <div className="text-gray-400">
                    <span className="text-purple-400">EXPERIMENTAL:</span> New mechanics being tested!
                  </div>
                  <div className="flex gap-4">
                    <button
                      onClick={() => window.location.href = "/scrap-yard/block-game"}
                      className="px-4 py-2 bg-gray-700/50 hover:bg-gray-700 text-gray-300 rounded transition-colors"
                    >
                      Classic Mode
                    </button>
                    <button
                      onClick={() => window.location.href = "/hub"}
                      className="px-4 py-2 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 rounded border border-yellow-500/30 transition-colors"
                    >
                      Return to Hub
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Game Variations Ideas Panel */}
          <div className="mt-8 bg-gray-900/50 backdrop-blur border border-purple-500/20 rounded-lg p-6">
            <h3 className="text-xl font-bold text-purple-400 mb-4">Experimental Features</h3>
            <div className="grid md:grid-cols-2 gap-4 text-gray-300">
              <div>
                <h4 className="text-yellow-400 mb-2">Current Innovation:</h4>
                <ul className="space-y-1 text-sm">
                  <li>• <span className="text-purple-400">Circular Motion:</span> Blocks orbit around center</li>
                  <li>• <span className="text-purple-400">Angular Precision:</span> Match rotation angles</li>
                  <li>• <span className="text-purple-400">Cylinder Shapes:</span> Stack rings instead of squares</li>
                </ul>
              </div>
              <div>
                <h4 className="text-yellow-400 mb-2">Future Concepts:</h4>
                <ul className="space-y-1 text-sm">
                  <li>• Gravity shifts (blocks fall sideways)</li>
                  <li>• Magnetic blocks (attract/repel)</li>
                  <li>• Time reversal mechanics</li>
                  <li>• Multi-directional stacking</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}