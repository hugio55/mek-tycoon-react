'use client';

import { useState, useEffect } from 'react';
import { useMutation, useQuery } from 'convex/react';
import { api } from '@/convex/_generated/api';
import { validateUsername, USERNAME_MAX_LENGTH } from '@/lib/usernameValidation';

interface UsernameModalProps {
  isOpen: boolean;
  onClose?: () => void;
  walletAddress: string;
  onSuccess?: (displayName: string) => void;
}

export default function UsernameModal({ isOpen, onClose, walletAddress, onSuccess }: UsernameModalProps) {
  const [username, setUsername] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const setDisplayName = useMutation(api.usernames.setDisplayName);
  const checkAvailability = useQuery(api.usernames.checkUsernameAvailability, 
    username.trim() ? { username: username.trim() } : "skip"
  );

  useEffect(() => {
    if (checkAvailability !== undefined) {
      setIsAvailable(checkAvailability.available);
      if (!checkAvailability.available && checkAvailability.error) {
        setError(checkAvailability.error);
      }
    }
  }, [checkAvailability]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setUsername(value);
    setError(null);
    setIsAvailable(null);

    // Validate on the fly
    if (value) {
      const validation = validateUsername(value);
      if (!validation.valid) {
        setError(validation.error || null);
      }
    }
  };

  const handleSubmit = async () => {
    const validation = validateUsername(username);
    if (!validation.valid) {
      setError(validation.error || "Invalid username");
      return;
    }

    if (!isAvailable) {
      setError("Username is not available");
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await setDisplayName({ 
        walletAddress, 
        displayName: username.trim() 
      });
      
      if (result.success) {
        onSuccess?.(result.displayName);
        onClose?.();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to set username");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-black/90 border border-yellow-500/30 rounded-lg p-8 max-w-md w-full mx-4">
        <h2 className="text-2xl font-bold text-yellow-400 mb-4 font-orbitron">
          Choose Your Display Name
        </h2>
        
        <div className="bg-red-900/20 border border-red-500/30 rounded p-4 mb-6">
          <p className="text-red-400 text-sm">
            <span className="font-bold">⚠️ WARNING:</span> Your display name is PERMANENT and cannot be changed once set!
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-300 text-sm mb-2">
              Display Name
            </label>
            <input
              type="text"
              value={username}
              onChange={handleInputChange}
              maxLength={USERNAME_MAX_LENGTH}
              placeholder="Enter your display name"
              className="w-full px-4 py-2 bg-black/50 border border-yellow-500/30 rounded text-white 
                       focus:outline-none focus:border-yellow-500 transition-colors"
              disabled={isSubmitting}
            />
            <div className="mt-2 text-xs text-gray-400">
              {username.length}/{USERNAME_MAX_LENGTH} characters
            </div>
          </div>

          {error && (
            <div className="text-red-400 text-sm">
              {error}
            </div>
          )}

          {isAvailable === true && !error && username && (
            <div className="text-green-400 text-sm">
              ✓ Username is available
            </div>
          )}

          <div className="text-xs text-gray-400 space-y-1">
            <p>• Letters and numbers only (no special characters)</p>
            <p>• Maximum {USERNAME_MAX_LENGTH} characters</p>
            <p>• Case-sensitive display (but unique regardless of case)</p>
            <p>• This choice is permanent!</p>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              onClick={handleSubmit}
              disabled={!username || !!error || !isAvailable || isSubmitting}
              className="flex-1 px-6 py-3 bg-yellow-500/20 border border-yellow-500/50 rounded
                       text-yellow-400 font-bold transition-all duration-200
                       hover:bg-yellow-500/30 hover:border-yellow-500 hover:shadow-lg hover:shadow-yellow-500/20
                       disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-yellow-500/20"
            >
              {isSubmitting ? "Setting..." : "Confirm Display Name"}
            </button>
            
            {onClose && (
              <button
                onClick={onClose}
                disabled={isSubmitting}
                className="px-6 py-3 bg-gray-800/50 border border-gray-600/50 rounded
                         text-gray-400 font-bold transition-all duration-200
                         hover:bg-gray-800/70 hover:border-gray-600
                         disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Skip for Now
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}