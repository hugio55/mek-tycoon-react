"use client";

import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { Id } from "../../../convex/_generated/dataModel";

// Rarity rank ranges for the 7 tiers
const RARITY_TIERS = [
  { label: "3k to 4k", min: 3001, max: 4000 },
  { label: "2 to 3", min: 2001, max: 3000 },
  { label: "1 to 2", min: 1001, max: 2000 },
  { label: "500 to 1k", min: 501, max: 1000 },
  { label: "100 to 500", min: 101, max: 500 },
  { label: "25 to 100", min: 26, max: 100 },
  { label: "1 to 25", min: 1, max: 25 },
];

// Default buff categories
const DEFAULT_BUFF_CATEGORIES = [
  "Flat Gold",
  "Gold Multiplier",
  "Essence Drop Rate",
  "Essence Multiplier",
  "XP Gain",
  "Critical Chance",
  "Critical Damage",
  "Attack Speed",
  "Movement Speed",
  "Health Regen",
  "Damage Reduction",
  "Luck",
];

interface BuffTable {
  _id?: Id<"mekTreeBuffTables">;
  category: string;
  displayName: string;
  description?: string;
  unit?: string; // e.g., "gold", "%", "x", etc.
  values: number[][]; // [rarityTier][treeTier] = value
  isActive: boolean;
  createdAt?: number;
  updatedAt?: number;
}

export default function MekTreeTablesPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("Flat Gold");
  const [editMode, setEditMode] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const [currentTable, setCurrentTable] = useState<BuffTable | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info', text: string } | null>(null);
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [newCategoryData, setNewCategoryData] = useState({
    category: "",
    displayName: "",
    description: "",
    unit: "",
  });

  // Convex queries and mutations
  const buffTables = useQuery(api.mekTreeBuffTables.getAllBuffTables);
  const saveBuffTable = useMutation(api.mekTreeBuffTables.saveBuffTable);
  const deleteBuffTable = useMutation(api.mekTreeBuffTables.deleteBuffTable);

  // Initialize with default empty table
  const createEmptyTable = (): number[][] => {
    return Array(7).fill(null).map(() => Array(10).fill(0));
  };

  // Load selected category data
  useEffect(() => {
    if (buffTables && selectedCategory) {
      const found = buffTables.find(t => t.category === selectedCategory);
      if (found) {
        setCurrentTable(found);
      } else {
        // Create new empty table for this category
        setCurrentTable({
          category: selectedCategory,
          displayName: selectedCategory,
          values: createEmptyTable(),
          isActive: true,
        });
      }
    }
  }, [buffTables, selectedCategory]);

  // Handle cell value change
  const handleCellChange = (rarityIndex: number, tierIndex: number, value: string) => {
    if (!currentTable) return;
    
    const numValue = parseFloat(value) || 0;
    const newValues = [...currentTable.values];
    newValues[rarityIndex][tierIndex] = numValue;
    
    setCurrentTable({
      ...currentTable,
      values: newValues,
    });
  };

  // Parse pasted data (tab-delimited from spreadsheet)
  const parsePastedData = (text: string) => {
    const lines = text.trim().split('\n');
    const values: number[][] = [];
    
    lines.forEach((line, index) => {
      if (index >= 7) return; // Only take first 7 rows
      
      const cells = line.split('\t');
      const row: number[] = [];
      
      // Skip first cell (rank label) and take next 10
      for (let i = 1; i <= 10 && i < cells.length; i++) {
        const value = parseFloat(cells[i]) || 0;
        row.push(value);
      }
      
      // Ensure row has exactly 10 values
      while (row.length < 10) {
        row.push(0);
      }
      
      values.push(row);
    });
    
    // Ensure we have exactly 7 rows
    while (values.length < 7) {
      values.push(Array(10).fill(0));
    }
    
    return values;
  };

  // Handle paste submission
  const handlePasteSubmit = () => {
    try {
      const values = parsePastedData(pasteText);
      if (currentTable) {
        setCurrentTable({
          ...currentTable,
          values,
        });
      }
      setPasteMode(false);
      setPasteText("");
      setMessage({ type: 'success', text: 'Data pasted successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to parse pasted data. Make sure it\'s in the correct format.' });
    }
  };

  // Save table to database
  const handleSave = async () => {
    if (!currentTable) return;
    
    try {
      await saveBuffTable({
        category: currentTable.category,
        displayName: currentTable.displayName,
        description: currentTable.description,
        unit: currentTable.unit,
        values: currentTable.values,
        isActive: currentTable.isActive,
      });
      
      setMessage({ type: 'success', text: `Saved ${currentTable.displayName} successfully!` });
      setEditMode(false);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to save table' });
    }
  };

  // Create new category
  const handleCreateCategory = async () => {
    if (!newCategoryData.category || !newCategoryData.displayName) {
      setMessage({ type: 'error', text: 'Category and display name are required' });
      return;
    }
    
    try {
      await saveBuffTable({
        category: newCategoryData.category,
        displayName: newCategoryData.displayName,
        description: newCategoryData.description,
        unit: newCategoryData.unit,
        values: createEmptyTable(),
        isActive: true,
      });
      
      setSelectedCategory(newCategoryData.category);
      setShowNewCategory(false);
      setNewCategoryData({ category: "", displayName: "", description: "", unit: "" });
      setMessage({ type: 'success', text: 'New category created!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to create category' });
    }
  };

  // Delete category
  const handleDelete = async () => {
    if (!currentTable?._id) return;
    
    if (!confirm(`Are you sure you want to delete "${currentTable.displayName}"?`)) {
      return;
    }
    
    try {
      await deleteBuffTable({ id: currentTable._id });
      setSelectedCategory("Flat Gold");
      setMessage({ type: 'success', text: 'Category deleted' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to delete category' });
    }
  };

  // Export table as CSV
  const exportAsCSV = () => {
    if (!currentTable) return;
    
    let csv = `${currentTable.displayName}\n`;
    csv += "Rank\t" + Array.from({length: 10}, (_, i) => i + 1).join("\t") + "\n";
    
    RARITY_TIERS.forEach((tier, i) => {
      csv += tier.label + "\t" + currentTable.values[i].join("\t") + "\n";
    });
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentTable.category.replace(/\s+/g, '_')}_table.csv`;
    a.click();
  };

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-yellow-400 mb-2">Mek Tree Buff Tables</h1>
          <p className="text-gray-400">Configure buff values for procedural talent tree generation</p>
        </div>

        {/* Message Display */}
        {message && (
          <div className={`mb-6 p-4 rounded-lg border ${
            message.type === 'success' ? 'bg-green-900/20 border-green-500 text-green-400' :
            message.type === 'error' ? 'bg-red-900/20 border-red-500 text-red-400' :
            'bg-blue-900/20 border-blue-500 text-blue-400'
          }`}>
            {message.text}
          </div>
        )}

        <div className="grid grid-cols-12 gap-6">
          {/* Category Sidebar */}
          <div className="col-span-3">
            <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-yellow-400">Categories</h2>
                <button
                  onClick={() => setShowNewCategory(true)}
                  className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm"
                >
                  + New
                </button>
              </div>
              
              <div className="space-y-2">
                {buffTables?.map((table) => (
                  <button
                    key={table._id}
                    onClick={() => setSelectedCategory(table.category)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-all ${
                      selectedCategory === table.category
                        ? 'bg-yellow-500/20 border border-yellow-500/50 text-yellow-400'
                        : 'bg-gray-800/50 border border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="font-semibold">{table.displayName}</div>
                    {table.unit && (
                      <div className="text-xs text-gray-500">Unit: {table.unit}</div>
                    )}
                    {!table.isActive && (
                      <div className="text-xs text-red-400">Inactive</div>
                    )}
                  </button>
                ))}
                
                {/* Default categories that don't exist yet */}
                {DEFAULT_BUFF_CATEGORIES.filter(cat => 
                  !buffTables?.find(t => t.category === cat)
                ).map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-all ${
                      selectedCategory === cat
                        ? 'bg-yellow-500/20 border border-yellow-500/50 text-yellow-400'
                        : 'bg-gray-800/50 border border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <div className="font-semibold">{cat}</div>
                    <div className="text-xs text-gray-500 italic">Not configured</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Table Area */}
          <div className="col-span-9">
            {currentTable && (
              <div className="bg-gray-900/50 border border-gray-800 rounded-xl p-6">
                {/* Table Header */}
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-yellow-400">{currentTable.displayName}</h2>
                    {currentTable.description && (
                      <p className="text-sm text-gray-400 mt-1">{currentTable.description}</p>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    {!editMode ? (
                      <>
                        <button
                          onClick={() => setEditMode(true)}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                          Edit Values
                        </button>
                        <button
                          onClick={() => setPasteMode(true)}
                          className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                        >
                          Paste Data
                        </button>
                        <button
                          onClick={exportAsCSV}
                          className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                        >
                          Export CSV
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={handleSave}
                          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                        >
                          Save Changes
                        </button>
                        <button
                          onClick={() => setEditMode(false)}
                          className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                        >
                          Cancel
                        </button>
                        {currentTable._id && (
                          <button
                            onClick={handleDelete}
                            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                          >
                            Delete
                          </button>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Settings Row (in edit mode) */}
                {editMode && (
                  <div className="mb-4 p-4 bg-gray-800/50 rounded-lg">
                    <div className="grid grid-cols-4 gap-4">
                      <div>
                        <label className="text-xs text-gray-400">Display Name</label>
                        <input
                          type="text"
                          value={currentTable.displayName}
                          onChange={(e) => setCurrentTable({...currentTable, displayName: e.target.value})}
                          className="w-full px-2 py-1 bg-gray-900 border border-gray-700 rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-400">Unit (e.g., gold, %, x)</label>
                        <input
                          type="text"
                          value={currentTable.unit || ""}
                          onChange={(e) => setCurrentTable({...currentTable, unit: e.target.value})}
                          className="w-full px-2 py-1 bg-gray-900 border border-gray-700 rounded text-sm"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="text-xs text-gray-400">Description</label>
                        <input
                          type="text"
                          value={currentTable.description || ""}
                          onChange={(e) => setCurrentTable({...currentTable, description: e.target.value})}
                          className="w-full px-2 py-1 bg-gray-900 border border-gray-700 rounded text-sm"
                        />
                      </div>
                    </div>
                    <div className="mt-3 flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="isActive"
                        checked={currentTable.isActive}
                        onChange={(e) => setCurrentTable({...currentTable, isActive: e.target.checked})}
                        className="w-4 h-4"
                      />
                      <label htmlFor="isActive" className="text-sm">
                        Active (include in procedural generation)
                      </label>
                    </div>
                  </div>
                )}

                {/* Value Table */}
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-left py-3 px-4 text-yellow-400">Rank</th>
                        {Array.from({length: 10}, (_, i) => (
                          <th key={i} className="text-center py-3 px-4 text-yellow-400 min-w-[80px]">
                            {i + 1}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {RARITY_TIERS.map((tier, rarityIndex) => (
                        <tr key={rarityIndex} className="border-b border-gray-800 hover:bg-gray-800/30">
                          <td className="py-3 px-4 font-semibold text-gray-300">{tier.label}</td>
                          {Array.from({length: 10}, (_, tierIndex) => (
                            <td key={tierIndex} className="text-center px-2">
                              {editMode ? (
                                <input
                                  type="number"
                                  value={currentTable.values[rarityIndex][tierIndex]}
                                  onChange={(e) => handleCellChange(rarityIndex, tierIndex, e.target.value)}
                                  className="w-full px-2 py-1 bg-gray-900 border border-gray-700 rounded text-center text-sm"
                                />
                              ) : (
                                <span className="text-gray-200">
                                  {currentTable.values[rarityIndex][tierIndex]}
                                  {currentTable.unit && ` ${currentTable.unit}`}
                                </span>
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Rarity Info */}
                <div className="mt-6 p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
                  <div className="flex items-start gap-3">
                    <span className="text-xl">ℹ️</span>
                    <div className="text-sm text-gray-400">
                      <p className="mb-2 text-blue-400">How it works:</p>
                      <ul className="space-y-1">
                        <li>• Rows represent Mek rarity tiers (rarer = lower numbers)</li>
                        <li>• Columns represent talent tree tiers (1-10)</li>
                        <li>• Values scale based on both Mek rarity and tree progression</li>
                        <li>• Procedural generator uses these tables to assign buff values</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Paste Modal */}
        {pasteMode && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="bg-gray-900 border border-gray-700 rounded-xl p-6 max-w-3xl w-full">
              <h3 className="text-2xl font-bold text-yellow-400 mb-4">Paste Table Data</h3>
              
              <p className="text-gray-400 mb-4">
                Copy data from your spreadsheet (including headers) and paste below.
                Expected format: 7 rows × 10 columns of numbers (rank labels will be ignored).
              </p>
              
              <textarea
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder="Paste your data here..."
                className="w-full h-64 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-mono text-sm"
              />
              
              <div className="flex gap-3 mt-4">
                <button
                  onClick={handlePasteSubmit}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Import Data
                </button>
                <button
                  onClick={() => {
                    setPasteMode(false);
                    setPasteText("");
                  }}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* New Category Modal */}
        {showNewCategory && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <div className="bg-gray-900 border border-gray-700 rounded-xl p-6 max-w-md w-full">
              <h3 className="text-2xl font-bold text-yellow-400 mb-4">Create New Category</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400">Category ID (no spaces)</label>
                  <input
                    type="text"
                    value={newCategoryData.category}
                    onChange={(e) => setNewCategoryData({...newCategoryData, category: e.target.value.replace(/\s+/g, '_')})}
                    placeholder="e.g., attack_power"
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
                  />
                </div>
                
                <div>
                  <label className="text-sm text-gray-400">Display Name</label>
                  <input
                    type="text"
                    value={newCategoryData.displayName}
                    onChange={(e) => setNewCategoryData({...newCategoryData, displayName: e.target.value})}
                    placeholder="e.g., Attack Power"
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
                  />
                </div>
                
                <div>
                  <label className="text-sm text-gray-400">Unit (optional)</label>
                  <input
                    type="text"
                    value={newCategoryData.unit}
                    onChange={(e) => setNewCategoryData({...newCategoryData, unit: e.target.value})}
                    placeholder="e.g., damage, %, gold"
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white"
                  />
                </div>
                
                <div>
                  <label className="text-sm text-gray-400">Description (optional)</label>
                  <textarea
                    value={newCategoryData.description}
                    onChange={(e) => setNewCategoryData({...newCategoryData, description: e.target.value})}
                    placeholder="What does this buff do?"
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white h-20"
                  />
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleCreateCategory}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Create Category
                </button>
                <button
                  onClick={() => {
                    setShowNewCategory(false);
                    setNewCategoryData({ category: "", displayName: "", description: "", unit: "" });
                  }}
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}