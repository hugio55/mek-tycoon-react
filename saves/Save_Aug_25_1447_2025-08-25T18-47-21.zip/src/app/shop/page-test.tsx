"use client";

export default function ShopPage() {
  return (
    <div style={{ color: 'white', padding: '2rem', backgroundColor: 'black' }}>
      <h1 style={{ color: '#fab617', fontSize: '2rem' }}>Shop - Testing</h1>
      <p>If you can see this, the basic page structure works.</p>
    </div>
  );
}