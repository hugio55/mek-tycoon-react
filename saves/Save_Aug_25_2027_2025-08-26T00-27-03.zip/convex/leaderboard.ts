import { v } from "convex/values";
import { query } from "./_generated/server";
import { Doc } from "./_generated/dataModel";

export const getTopPlayersByGold = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 100;
    
    const users = await ctx.db
      .query("users")
      .order("desc")
      .take(limit);
    
    return users
      .sort((a, b) => (b.gold ?? 0) - (a.gold ?? 0))
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        walletAddress: user.walletAddress,
        username: user.username || `Mek Owner ${user.walletAddress.slice(0, 6)}`,
        gold: user.gold ?? 0,
        level: user.level ?? 1,
        achievementCount: user.achievementCount ?? 0,
        mekCount: user.mekCount ?? 0,
        totalGoldRate: user.totalGoldRate ?? 0,
      }));
  },
});

export const getTopPlayersByEssence = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 100;
    
    const users = await ctx.db
      .query("users")
      .order("desc")
      .take(limit);
    
    return users
      .sort((a, b) => (b.totalEssence ?? 0) - (a.totalEssence ?? 0))
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        walletAddress: user.walletAddress,
        username: user.username || `Mek Owner ${user.walletAddress.slice(0, 6)}`,
        totalEssence: user.totalEssence ?? 0,
        gold: user.gold ?? 0,
        level: user.level ?? 1,
        mekCount: user.mekCount ?? 0,
      }));
  },
});

export const getTopPlayersByMekCount = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 100;
    
    const users = await ctx.db
      .query("users")
      .order("desc")
      .take(limit);
    
    return users
      .sort((a, b) => (b.mekCount ?? 0) - (a.mekCount ?? 0))
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        walletAddress: user.walletAddress,
        username: user.username || `Mek Owner ${user.walletAddress.slice(0, 6)}`,
        mekCount: user.mekCount ?? 0,
        gold: user.gold ?? 0,
        totalGoldRate: user.totalGoldRate ?? 0,
        averageMekLevel: user.averageMekLevel ?? 1,
      }));
  },
});

export const getTopPlayersByAchievements = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 100;
    
    const users = await ctx.db
      .query("users")
      .order("desc")
      .take(limit);
    
    return users
      .sort((a, b) => (b.achievementCount ?? 0) - (a.achievementCount ?? 0))
      .slice(0, limit)
      .map((user, index) => ({
        rank: index + 1,
        walletAddress: user.walletAddress,
        username: user.username || `Mek Owner ${user.walletAddress.slice(0, 6)}`,
        achievementCount: user.achievementCount ?? 0,
        achievementPoints: user.achievementPoints ?? 0,
        level: user.level ?? 1,
        gold: user.gold ?? 0,
      }));
  },
});

export const getTopMeksByLevel = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 100;
    
    const meks = await ctx.db
      .query("meks")
      .order("desc")
      .take(limit);
    
    return meks
      .sort((a, b) => {
        const levelDiff = (b.level ?? 1) - (a.level ?? 1);
        if (levelDiff !== 0) return levelDiff;
        return (b.xp ?? 0) - (a.xp ?? 0);
      })
      .slice(0, limit)
      .map((mek, index) => ({
        rank: index + 1,
        assetId: mek.assetId,
        assetName: mek.assetName,
        owner: mek.owner,
        level: mek.level ?? 1,
        xp: mek.xp ?? 0,
        goldRate: (mek.level ?? 1) * 3.5,
        headVariation: mek.headVariation,
        bodyVariation: mek.bodyVariation,
        sourceKeyBase: mek.sourceKeyBase,
      }));
  },
});

export const getPlayerRank = query({
  args: {
    walletAddress: v.string(),
    category: v.union(v.literal("gold"), v.literal("essence"), v.literal("meks"), v.literal("achievements")),
  },
  handler: async (ctx, args) => {
    const users = await ctx.db.query("users").collect();
    
    let sortedUsers: Doc<"users">[];
    switch (args.category) {
      case "gold":
        sortedUsers = users.sort((a, b) => (b.gold ?? 0) - (a.gold ?? 0));
        break;
      case "essence":
        sortedUsers = users.sort((a, b) => (b.totalEssence ?? 0) - (a.totalEssence ?? 0));
        break;
      case "meks":
        sortedUsers = users.sort((a, b) => (b.mekCount ?? 0) - (a.mekCount ?? 0));
        break;
      case "achievements":
        sortedUsers = users.sort((a, b) => (b.achievementPoints ?? 0) - (a.achievementPoints ?? 0));
        break;
    }
    
    const userIndex = sortedUsers.findIndex(user => user.walletAddress === args.walletAddress);
    
    if (userIndex === -1) return null;
    
    const user = sortedUsers[userIndex];
    return {
      rank: userIndex + 1,
      totalPlayers: sortedUsers.length,
      percentile: Math.round(((sortedUsers.length - userIndex) / sortedUsers.length) * 100),
      walletAddress: user.walletAddress,
      username: user.username || `Mek Owner ${user.walletAddress.slice(0, 6)}`,
      gold: user.gold ?? 0,
      level: user.level ?? 1,
      mekCount: user.mekCount ?? 0,
      achievementCount: user.achievementCount ?? 0,
      achievementPoints: user.achievementPoints ?? 0,
      totalEssence: user.totalEssence ?? 0,
    };
  },
});