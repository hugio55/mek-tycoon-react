"use client";

import { useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";
import BackgroundEffects from "@/components/BackgroundEffects";
import MekImage from "@/components/MekImage";
import Link from "next/link";

type LeaderboardCategory = 'achievements' | 'gold' | 'essence' | 'meks' | 'topMeks';

interface LeaderboardEntry {
  rank: number;
  walletAddress?: string;
  username?: string;
  gold?: number;
  level?: number;
  xp?: number;
  mekCount?: number;
  achievementCount?: number;
  achievementPoints?: number;
  totalGoldRate?: number;
  totalEssence?: number;
  averageMekLevel?: number;
  assetId?: string;
  assetName?: string;
  owner?: string;
  goldRate?: number;
  headVariation?: string;
  bodyVariation?: string;
  sourceKeyBase?: string | null;
}

export default function LeaderboardPage() {
  const [currentWallet, setCurrentWallet] = useState<string>("demo_wallet_123");

  useEffect(() => {
    const stakeAddress = localStorage.getItem('stakeAddress');
    const paymentAddress = localStorage.getItem('walletAddress');
    const addressToUse = stakeAddress || paymentAddress || "demo_wallet_123";
    setCurrentWallet(addressToUse);
  }, []);

  const topByAchievements = useQuery(api.leaderboard.getTopPlayersByAchievements, { limit: 10 });
  const topByGold = useQuery(api.leaderboard.getTopPlayersByGold, { limit: 10 });
  const topByEssence = useQuery(api.leaderboard.getTopPlayersByEssence, { limit: 10 });
  const topByMeks = useQuery(api.leaderboard.getTopPlayersByMekCount, { limit: 10 });
  const topMeks = useQuery(api.leaderboard.getTopMeksByLevel, { limit: 10 });
  
  const achievementRank = useQuery(api.leaderboard.getPlayerRank, {
    walletAddress: currentWallet,
    category: 'achievements'
  });
  const goldRank = useQuery(api.leaderboard.getPlayerRank, {
    walletAddress: currentWallet,
    category: 'gold'
  });
  const essenceRank = useQuery(api.leaderboard.getPlayerRank, {
    walletAddress: currentWallet,
    category: 'essence'
  });
  const meksRank = useQuery(api.leaderboard.getPlayerRank, {
    walletAddress: currentWallet,
    category: 'meks'
  });

  const formatNumber = (num: number | string | undefined) => {
    // Convert to number and handle invalid values
    const value = typeof num === 'number' ? num : Number(num) || 0;
    
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return '#FFD700';
    if (rank === 2) return '#C0C0C0';
    if (rank === 3) return '#CD7F32';
    if (rank <= 10) return '#E5E4E2';
    return '#6B7280';
  };

  const getRankIcon = (rank: number) => {
    if (rank === 1) return '👑';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return '';
  };

  return (
    <div className="text-white py-8 min-h-screen relative">
      <BackgroundEffects />
      
      <h1 className="text-4xl font-bold text-yellow-400 mb-2 text-center">Global Leaderboards</h1>
      <p className="text-gray-400 mb-12 text-center">Compete for glory and eternal fame in Mek Tycoon</p>

      {/* Top 3 Achievement Leaders - Permanent */}
      <div className="mb-12 max-w-6xl mx-auto">
        <h2 className="text-2xl font-bold text-green-400 mb-6 text-center">🏆 Achievement Leaders</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {topByAchievements?.slice(0, 3).map((player, index) => (
            <div
              key={index}
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                background: index === 0 
                  ? 'linear-gradient(135deg, rgba(255, 215, 0, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)'
                  : index === 1
                  ? 'linear-gradient(135deg, rgba(192, 192, 192, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)'
                  : 'linear-gradient(135deg, rgba(205, 127, 50, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: `2px solid ${index === 0 ? '#FFD700' : index === 1 ? '#C0C0C0' : '#CD7F32'}`,
                boxShadow: `0 20px 40px ${index === 0 ? 'rgba(255, 215, 0, 0.3)' : index === 1 ? 'rgba(192, 192, 192, 0.3)' : 'rgba(205, 127, 50, 0.3)'}`,
              }}
            >
              <div className="text-5xl mb-3">{getRankIcon(index + 1)}</div>
              <div className="text-3xl font-bold mb-2" style={{ color: getRankColor(index + 1) }}>
                #{index + 1}
              </div>
              <div className="text-xl font-medium text-white mb-1">{player.username}</div>
              <div className="text-xs text-gray-400 mb-3">{player.walletAddress?.slice(0, 6)}...{player.walletAddress?.slice(-4)}</div>
              <div className="text-3xl font-bold text-green-400">{player.achievementPoints || 0}</div>
              <div className="text-sm text-gray-400">Achievement Points</div>
              <div className="mt-3 text-sm text-gray-300">
                {player.achievementCount} achievements • Level {player.level}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Category Leaderboards */}
      <div className="max-w-7xl mx-auto space-y-8">
        {[
          { 
            title: 'Achievement Points',
            icon: '🏆',
            color: '#10B981',
            data: topByAchievements,
            userRank: achievementRank,
            columns: ['Player', 'Points', 'Achievements', 'Level'],
            renderRow: (entry: LeaderboardEntry) => [
              entry.achievementPoints || 0,
              entry.achievementCount || 0,
              `Lvl ${entry.level}`
            ]
          },
          { 
            title: 'Gold Leaders',
            icon: '🪙',
            color: '#FFD700',
            data: topByGold,
            userRank: goldRank,
            columns: ['Player', 'Gold', 'Gold/hr', 'Meks'],
            renderRow: (entry: LeaderboardEntry) => [
              formatNumber(entry.gold || 0),
              `${entry.totalGoldRate?.toFixed(1)}/hr`,
              entry.mekCount || 0
            ]
          },
          { 
            title: 'Total Essence',
            icon: '💎',
            color: '#8B5CF6',
            data: topByEssence,
            userRank: essenceRank,
            columns: ['Player', 'Essence', 'Gold', 'Meks'],
            renderRow: (entry: LeaderboardEntry) => [
              formatNumber(entry.totalEssence || 0),
              formatNumber(entry.gold || 0),
              entry.mekCount || 0
            ]
          },
          { 
            title: 'Meks Owned',
            icon: '🤖',
            color: '#3B82F6',
            data: topByMeks,
            userRank: meksRank,
            columns: ['Player', 'Meks', 'Avg Level', 'Gold/hr'],
            renderRow: (entry: LeaderboardEntry) => [
              entry.mekCount || 0,
              entry.averageMekLevel?.toFixed(1) || '1.0',
              `${entry.totalGoldRate?.toFixed(1)}/hr`
            ]
          },
          { 
            title: 'Top Meks',
            icon: '👾',
            color: '#EC4899',
            data: topMeks,
            userRank: null,
            columns: ['Mek', 'Level', 'XP', 'Gold/hr'],
            isMekList: true,
            renderRow: (entry: LeaderboardEntry) => [
              `Lvl ${entry.level}`,
              formatNumber(entry.xp || 0),
              `${entry.goldRate?.toFixed(1)}/hr`
            ]
          },
        ].map((category) => {
          const isUserInTop10 = category.data?.some(entry => 
            entry.walletAddress === currentWallet || entry.owner === currentWallet
          );

          return (
            <div
              key={category.title}
              className="rounded-lg overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.4) 0%, rgba(15, 15, 15, 0.4) 100%)',
                backdropFilter: 'blur(10px)',
                border: `1px solid ${category.color}33`,
              }}
            >
              <div 
                className="p-4 flex items-center gap-3"
                style={{
                  background: `linear-gradient(90deg, ${category.color}22 0%, transparent 100%)`,
                  borderBottom: `1px solid ${category.color}44`,
                }}
              >
                <span className="text-2xl">{category.icon}</span>
                <h3 className="text-xl font-bold" style={{ color: category.color }}>{category.title}</h3>
              </div>

              <table className="w-full">
                <thead>
                  <tr className="text-sm" style={{ borderBottom: `1px solid ${category.color}22` }}>
                    <th className="text-left p-3 text-gray-400 font-medium w-16">Rank</th>
                    {category.columns.map((col, i) => (
                      <th key={i} className={`p-3 text-gray-400 font-medium ${i === 0 ? 'text-left' : 'text-center'}`}>
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {category.data?.slice(0, 10).map((entry, index) => {
                    const isCurrentUser = entry.walletAddress === currentWallet || entry.owner === currentWallet;
                    
                    return (
                      <tr
                        key={index}
                        className="transition-all duration-200 hover:bg-white/5"
                        style={{
                          background: isCurrentUser ? `${category.color}11` : 'transparent',
                          borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
                        }}
                      >
                        <td className="p-3 w-16">
                          <div className="flex items-center gap-1">
                            <span className="font-bold" style={{ color: getRankColor(entry.rank) }}>
                              {entry.rank}
                            </span>
                            {entry.rank <= 3 && <span className="text-sm">{getRankIcon(entry.rank)}</span>}
                          </div>
                        </td>
                        <td className="p-3">
                          {category.isMekList ? (
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded overflow-hidden bg-gray-800">
                                <MekImage
                                  src={undefined}
                                  headVariation={entry.headVariation}
                                  bodyVariation={entry.bodyVariation}
                                  assetId={entry.assetId}
                                  size={32}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <Link
                                href={`/mek/${entry.assetId}`}
                                className="text-white hover:text-yellow-400 text-sm transition-colors"
                              >
                                {entry.assetName}
                              </Link>
                            </div>
                          ) : (
                            <div className="flex flex-col">
                              <span className={`text-sm font-medium ${isCurrentUser ? 'text-yellow-400' : 'text-white'}`}>
                                {entry.username}
                              </span>
                              <span className="text-xs text-gray-500">
                                {entry.walletAddress?.slice(0, 6)}...
                              </span>
                            </div>
                          )}
                        </td>
                        {category.renderRow(entry).map((value, i) => (
                          <td key={i} className="p-3 text-center text-sm text-gray-300">
                            {value}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                  
                  {/* User's position if not in top 10 */}
                  {!isUserInTop10 && category.userRank && category.userRank.rank > 10 && (
                    <tr
                      className="transition-all duration-200"
                      style={{
                        background: `${category.color}11`,
                        borderTop: `2px solid ${category.color}44`,
                      }}
                    >
                      <td className="p-3 w-16">
                        <span className="font-bold text-yellow-400">
                          {category.userRank.rank}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-yellow-400">
                            {category.userRank.username} (You)
                          </span>
                          <span className="text-xs text-gray-500">
                            {category.userRank.walletAddress?.slice(0, 6)}...
                          </span>
                        </div>
                      </td>
                      {(() => {
                        const userData = {
                          ...category.userRank,
                          achievementPoints: category.userRank.achievementPoints || 0,
                          achievementCount: category.userRank.achievementCount || 0,
                          totalGoldRate: category.userRank.totalGoldRate || 0,
                          totalEssence: category.userRank.totalEssence || 0,
                          averageMekLevel: 1,
                        } as LeaderboardEntry;
                        
                        return category.renderRow(userData).map((value, i) => (
                          <td key={i} className="p-3 text-center text-sm text-gray-300">
                            {value}
                          </td>
                        ));
                      })()}
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          );
        })}
      </div>
    </div>
  );
}