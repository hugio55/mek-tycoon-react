"use client";

import { useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";
import BackgroundEffects from "@/components/BackgroundEffects";
import MekImage from "@/components/MekImage";
import Link from "next/link";

type LeaderboardCategory = 'gold' | 'meks' | 'essence' | 'networth' | 'level';

interface LeaderboardEntry {
  rank: number;
  walletAddress: string;
  username?: string;
  value: number;
  metadata?: {
    level?: number;
    essenceBreakdown?: any;
    mekDetails?: {
      total: number;
      legendary: number;
      epic: number;
      rare: number;
      uncommon: number;
      common: number;
    };
    goldPerHour?: number;
    bankBalance?: number;
    stockValue?: number;
  };
}

export default function LeaderboardPage() {
  const [currentWallet, setCurrentWallet] = useState<string>("demo_wallet_123");
  const [selectedCategory, setSelectedCategory] = useState<LeaderboardCategory>('gold');

  useEffect(() => {
    const stakeAddress = localStorage.getItem('stakeAddress');
    const paymentAddress = localStorage.getItem('walletAddress');
    const addressToUse = stakeAddress || paymentAddress || "demo_wallet_123";
    setCurrentWallet(addressToUse);
  }, []);

  // Use optimized cached leaderboard queries
  const leaderboardData = useQuery(api.leaderboardOptimized.getCachedLeaderboard, {
    category: selectedCategory,
    limit: 100
  });
  
  // Get current user from auth
  const currentUser = useQuery(api.users.getCurrentUser);
  
  // Get user's rank for current category
  const userRank = useQuery(api.leaderboardOptimized.getUserRank, {
    userId: currentUser?._id!,
    category: selectedCategory
  }, { enabled: !!currentUser?._id });
  
  // Also get top 3 for gold (for podium display)
  const topGoldData = useQuery(api.leaderboardOptimized.getCachedLeaderboard, {
    category: 'gold',
    limit: 3
  });

  const formatNumber = (num: number | string | undefined) => {
    // Convert to number and handle invalid values
    const value = typeof num === 'number' ? num : Number(num) || 0;
    
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return '#FFD700';
    if (rank === 2) return '#C0C0C0';
    if (rank === 3) return '#CD7F32';
    if (rank <= 10) return '#E5E4E2';
    return '#6B7280';
  };

  const getRankIcon = (rank: number) => {
    return '';
  };

  const getCategoryData = () => {
    switch (selectedCategory) {
      case 'gold':
        return {
          columns: ['Player', 'Total Gold', 'Gold/hr'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            `${entry.metadata?.goldPerHour?.toFixed(1) || '0'}/hr`
          ]
        };
      case 'meks':
        return {
          columns: ['Player', 'Mek Count', 'Breakdown'],
          renderRow: (entry: LeaderboardEntry) => [
            entry.value,
            entry.metadata?.mekDetails ? 
              `L:${entry.metadata.mekDetails.legendary} E:${entry.metadata.mekDetails.epic} R:${entry.metadata.mekDetails.rare}` : 
              '-'
          ]
        };
      case 'essence':
        return {
          columns: ['Player', 'Total Essence', 'Level'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            `Lvl ${entry.metadata?.level || 1}`
          ]
        };
      case 'networth':
        return {
          columns: ['Player', 'Net Worth', 'Breakdown'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            `Bank: ${formatNumber(entry.metadata?.bankBalance || 0)} | Stocks: ${formatNumber(entry.metadata?.stockValue || 0)}`
          ]
        };
      case 'level':
        return {
          columns: ['Player', 'Level', 'Gold/hr'],
          renderRow: (entry: LeaderboardEntry) => [
            entry.value,
            `${entry.metadata?.goldPerHour?.toFixed(1) || '0'}/hr`
          ]
        };
      default:
        return { columns: [], renderRow: () => [] };
    }
  };

  const currentCategoryData = getCategoryData();
  const isUserInTop10 = leaderboardData?.some(entry => 
    entry.walletAddress === currentWallet
  );

  return (
    <div className="text-white py-8 min-h-screen relative">
      <BackgroundEffects />
      
      {/* Epic Title */}
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold mb-2">
          <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-500 bg-clip-text text-transparent">
            HALL OF LEGENDS
          </span>
        </h1>
        <p className="text-gray-400">Where champions are immortalized</p>
      </div>

      {/* Top 3 Gold Leaders - Podium Style with Ember Effects */}
      <div className="mb-12 max-w-5xl mx-auto">
        <div className="flex items-end justify-center gap-4 mb-8">
          {/* 2nd Place - Left */}
          {topGoldData?.[1] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '280px',
                marginBottom: '0px',
                background: 'linear-gradient(135deg, rgba(192, 192, 192, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '2px solid #C0C0C0',
                boxShadow: '0 20px 40px rgba(192, 192, 192, 0.3)',
              }}
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={64}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-2xl font-bold mb-2" style={{ color: '#C0C0C0' }}>
                #2
              </div>
              <div className="text-lg font-medium text-white mb-1">{topGoldData[1].username}</div>
              <div className="text-xs text-gray-400 mb-3">
                {topGoldData[1].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-2xl font-bold text-yellow-400">{formatNumber(topGoldData[1].value)}</div>
              <div className="text-xs text-gray-400">Total Gold</div>
            </div>
          )}

          {/* 1st Place - Center, Elevated with Embers */}
          {topGoldData?.[0] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '320px',
                marginBottom: '40px',
                background: 'linear-gradient(135deg, rgba(255, 215, 0, 0.2) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '3px solid #FFD700',
                boxShadow: '0 30px 60px rgba(255, 215, 0, 0.4)',
              }}
            >
              {/* Ember particles */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute bottom-0 left-1/4 w-1 h-1 bg-orange-400 rounded-full animate-float-up" style={{ animationDelay: '0s', animationDuration: '3s' }} />
                <div className="absolute bottom-0 left-1/2 w-1.5 h-1.5 bg-yellow-400 rounded-full animate-float-up" style={{ animationDelay: '0.5s', animationDuration: '2.5s' }} />
                <div className="absolute bottom-0 left-3/4 w-1 h-1 bg-red-400 rounded-full animate-float-up" style={{ animationDelay: '1s', animationDuration: '3.5s' }} />
                <div className="absolute bottom-0 left-1/3 w-0.5 h-0.5 bg-orange-500 rounded-full animate-float-up" style={{ animationDelay: '1.5s', animationDuration: '3s' }} />
                <div className="absolute bottom-0 left-2/3 w-1 h-1 bg-yellow-500 rounded-full animate-float-up" style={{ animationDelay: '2s', animationDuration: '2.8s' }} />
              </div>
              <div className="w-20 h-20 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800 ring-4 ring-yellow-400/50">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={80}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-3xl font-bold mb-2" style={{ color: '#FFD700' }}>
                #1
              </div>
              <div className="text-xl font-bold text-white mb-1">{topGoldData[0].username}</div>
              <div className="text-xs text-gray-400 mb-3">
                {topGoldData[0].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-3xl font-bold text-yellow-400">{formatNumber(topGoldData[0].value)}</div>
              <div className="text-sm text-gray-400">Total Gold</div>
              <div className="mt-3 text-sm text-gray-300">
                {topGoldData[0].metadata?.mekDetails?.total || 0} meks • {topGoldData[0].metadata?.goldPerHour?.toFixed(1) || '0'}/hr
              </div>
            </div>
          )}

          {/* 3rd Place - Right */}
          {topGoldData?.[2] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '280px',
                marginBottom: '0px',
                background: 'linear-gradient(135deg, rgba(205, 127, 50, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '2px solid #CD7F32',
                boxShadow: '0 20px 40px rgba(205, 127, 50, 0.3)',
              }}
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={64}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-2xl font-bold mb-2" style={{ color: '#CD7F32' }}>
                #3
              </div>
              <div className="text-lg font-medium text-white mb-1">{topGoldData[2].username}</div>
              <div className="text-xs text-gray-400 mb-3">
                {topGoldData[2].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-2xl font-bold text-yellow-400">{formatNumber(topGoldData[2].value)}</div>
              <div className="text-xs text-gray-400">Total Gold</div>
            </div>
          )}
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 mb-8 justify-center flex-wrap">
        <button
          onClick={() => setSelectedCategory('gold')}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'gold'
              ? 'bg-yellow-400/20 text-yellow-400 border border-yellow-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Total Gold
        </button>
        
        <button
          onClick={() => setSelectedCategory('meks')}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'meks'
              ? 'bg-blue-400/20 text-blue-400 border border-blue-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Meks Owned
        </button>
        
        <button
          onClick={() => setSelectedCategory('essence')}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'essence'
              ? 'bg-purple-400/20 text-purple-400 border border-purple-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Total Essence
        </button>
        
        <button
          onClick={() => setSelectedCategory('networth')}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'networth'
              ? 'bg-green-400/20 text-green-400 border border-green-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Net Worth
        </button>
        
        <button
          onClick={() => setSelectedCategory('level')}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'level'
              ? 'bg-pink-400/20 text-pink-400 border border-pink-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Player Level
        </button>
      </div>

      {/* Top 10 Table */}
      <div className="max-w-5xl mx-auto">
        <div
          className="rounded-lg overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.4) 0%, rgba(15, 15, 15, 0.4) 100%)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 204, 0, 0.2)',
          }}
        >
          <table className="w-full">
            <thead>
              <tr className="text-sm" style={{ borderBottom: '1px solid rgba(255, 204, 0, 0.3)' }}>
                <th className="text-left p-4 text-yellow-400 font-medium w-16">Rank</th>
                {currentCategoryData.columns?.map((col, i) => (
                  <th key={i} className={`p-4 text-yellow-400 font-medium ${i === 0 ? 'text-left' : 'text-center'}`}>
                    {col}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {leaderboardData?.slice(0, 10).map((entry, index) => {
                const isCurrentUser = entry.walletAddress === currentWallet;
                
                return (
                  <tr
                    key={index}
                    className="transition-all duration-200 hover:bg-white/5"
                    style={{
                      background: isCurrentUser ? 'rgba(250, 182, 23, 0.1)' : 'transparent',
                      borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
                    }}
                  >
                    <td className="p-4 w-16">
                      <div className="flex items-center gap-1">
                        <span className="font-bold" style={{ color: getRankColor(entry.rank) }}>
                          {entry.rank}
                        </span>
                        {entry.rank <= 3 && <span className="text-sm">{getRankIcon(entry.rank)}</span>}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                          <MekImage
                            src={undefined}
                            assetId={"0000"}
                            size={40}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex flex-col">
                          <span className={`font-medium ${isCurrentUser ? 'text-yellow-400' : 'text-white'}`}>
                            {entry.username || 'Anonymous'}
                          </span>
                          <span className="text-xs text-gray-500">
                            {entry.walletAddress?.slice(0, 6)}...
                          </span>
                        </div>
                      </div>
                    </td>
                    {currentCategoryData.renderRow && currentCategoryData.renderRow(entry).map((value, i) => (
                      <td key={i} className="p-4 text-center text-gray-300">
                        {value}
                      </td>
                    ))}
                  </tr>
                );
              })}
              
              {/* User's position if not in top 10 */}
              {!isUserInTop10 && userRank && userRank > 10 && currentUser && (
                <tr
                  className="transition-all duration-200"
                  style={{
                    background: 'rgba(250, 182, 23, 0.15)',
                    borderTop: '2px solid rgba(250, 182, 23, 0.5)',
                  }}
                >
                  <td className="p-4 w-16">
                    <span className="font-bold text-yellow-400">
                      {userRank}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                        <MekImage
                          src={undefined}
                          assetId={"0000"}
                          size={40}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex flex-col">
                        <span className="font-medium text-yellow-400">
                          {currentUser.username || 'You'}
                        </span>
                        <span className="text-xs text-gray-500">
                          {currentUser.walletAddress?.slice(0, 6)}...
                        </span>
                      </div>
                    </div>
                  </td>
                  <td colSpan={currentCategoryData.columns.length - 1} className="p-4 text-center text-gray-400">
                    Loading your stats...
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}