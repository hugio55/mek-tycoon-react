"use client";

import { useParams } from "next/navigation";
import { useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import Link from "next/link";
import MekImage from "../../../components/MekImage";
import { useState, useEffect } from "react";
import BackgroundEffects from "@/components/BackgroundEffects";

export default function MekProfilePage() {
  const params = useParams();
  const mekId = params.id as string;
  
  const mekFromDb = useQuery(api.meks.getMekByAssetId, { assetId: mekId });
  const [isEmployed, setIsEmployed] = useState(false);
  const [currentGoldForOwner, setCurrentGoldForOwner] = useState(12847.582);
  const [allTimeGold, setAllTimeGold] = useState(458392.891);
  
  // Create demo mek data if not found in database
  const demoMeks: Record<string, any> = {
    "1234": { assetId: "1234", assetName: "Demo Mek #1234", level: 5, goldRate: 15.5, isEmployee: true, headVariation: "000-000-000", bodyVariation: "000-000-000", owner: "demo_wallet_123" },
    "2468": { assetId: "2468", assetName: "Demo Mek #2468", level: 3, goldRate: 8.2, isEmployee: false, headVariation: "000-000-000", bodyVariation: "000-000-000", owner: "demo_wallet_123" },
    "3691": { assetId: "3691", assetName: "Demo Mek #3691", level: 7, goldRate: 22.1, isEmployee: true, headVariation: "000-000-000", bodyVariation: "000-000-000", owner: "demo_wallet_123" },
    "0013": { assetId: "0013", assetName: "Demo Mek #0013", level: 10, goldRate: 35.0, isEmployee: true, headVariation: "000-000-000", bodyVariation: "000-000-000", owner: "demo_wallet_123" },
  };
  
  // Use database mek or fall back to demo mek
  const mek = mekFromDb || demoMeks[mekId];
  
  // Example gold rate: 20 gold/hour = 0.00556 gold/second
  const goldPerSecond = 20 / 3600;
  
  useEffect(() => {
    if (mek) {
      setIsEmployed(mek.isEmployee || false);
    }
  }, [mek]);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentGoldForOwner(prev => prev + goldPerSecond);
      setAllTimeGold(prev => prev + goldPerSecond);
    }, 100); // Update every 100ms for smooth counting
    return () => clearInterval(interval);
  }, [goldPerSecond]);
  
  // Equipment slots with actual variation images
  const equipmentSlots = [
    { 
      id: "head", 
      name: "Gold Head", 
      variation: "gold", 
      type: "heads",
      filled: true 
    },
    { 
      id: "body", 
      name: "Chrome Body", 
      variation: "chrome", 
      type: "bodies",
      filled: true 
    },
    { 
      id: "trait", 
      name: "Blasters", 
      variation: "blasters",
      type: "traits",
      filled: true 
    }
  ];
  
  const talentNodes = [
    { id: 1, name: "Gold Rush", level: 1, unlocked: true, buff: "+2.5 gold/hr" },
    { id: 2, name: "Efficient Worker", level: 2, unlocked: true, buff: "+5% gold rate" },
    { id: 3, name: "Banker", level: 3, unlocked: true, buff: "+1% bank interest" },
    { id: 4, name: "Essence Master", level: 4, unlocked: true, buff: "+1.4 global essence" },
    { id: 5, name: "Speed Demon", level: 5, unlocked: false, buff: "+15% craft speed" }
  ];
  
  const activeBuffs = talentNodes.filter(node => node.unlocked);
  
  if (!mek) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-2xl font-mono text-yellow-400 mb-2">LOADING</div>
          <div className="w-48 h-1 bg-gray-800 mx-auto">
            <div className="h-full bg-yellow-400 animate-pulse" style={{ width: "60%" }}></div>
          </div>
        </div>
      </div>
    );
  }
  
  const getRarityColor = (tier: string | undefined) => {
    switch(tier) {
      case "Legendary": return "text-orange-400";
      case "Epic": return "text-purple-400";
      case "Rare": return "text-blue-400";
      case "Uncommon": return "text-green-400";
      default: return "text-gray-400";
    }
  };
  
  const isOwner = true; // You'd check if current user owns this mek
  
  return (
    <div className="min-h-screen bg-black text-white">
      <BackgroundEffects />
      
      {/* Minimal Header */}
      <div className="border-b border-gray-900">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/profile" className="text-gray-500 hover:text-yellow-400 transition-colors text-sm font-mono">
              ← BACK
            </Link>
            <div className="text-xs font-mono text-gray-600">
              MEK PROFILE / {mek.assetId}
            </div>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        
        {/* Top Section */}
        <div className="grid grid-cols-12 gap-6 mb-12">
          
          {/* Left Panel - Stats & Modifiers */}
          <div className="col-span-3 space-y-4">
            {/* Designation & Details */}
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden glass-panel">
              {/* Subtle texture overlay */}
              <div className="absolute inset-0 opacity-[0.015]" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Cpath d='M0 50 L100 50' stroke='white' stroke-width='0.5' opacity='0.3'/%3E%3Cpath d='M20 0 L20 100' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Cpath d='M60 0 L60 100' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Cpath d='M0 20 L100 20' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Cpath d='M0 80 L100 80' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '100px 100px'
              }} />
              <div className="relative text-xs font-mono text-gray-500 mb-1">DESIGNATION</div>
              <div className="text-lg font-bold text-yellow-400 mb-4">
                {mek.assetName || `MEK-${mek.assetId}`}
              </div>
            </div>
            
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              <div className="text-xs font-mono text-gray-500 mb-1">RANK</div>
              <div className="text-2xl font-bold text-white">
                {mek.rarityRank || "N/A"}
              </div>
            </div>
            
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              <div className="text-xs font-mono text-gray-500 mb-1">OPERATOR</div>
              <div className="text-xs font-mono text-gray-400 break-all">
                {mek.owner ? `${mek.owner.slice(0, 8)}...${mek.owner.slice(-6)}` : "UNASSIGNED"}
              </div>
            </div>
            
            {/* Employment Status */}
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              {/* Subtle texture overlay */}
              <div className="absolute inset-0 opacity-[0.015]" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Cpath d='M10 10 L90 90' stroke='white' stroke-width='0.2' opacity='0.3'/%3E%3Cpath d='M90 10 L10 90' stroke='white' stroke-width='0.2' opacity='0.2'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '100px 100px'
              }} />
              <div className="flex items-center justify-between">
                <span className={`text-lg font-bold ${isEmployed ? 'text-green-400' : 'text-gray-500'}`}>
                  {isEmployed ? 'EMPLOYED' : 'IDLE'}
                </span>
                {isOwner && (
                  <button
                    onClick={() => setIsEmployed(!isEmployed)}
                    className={`
                      relative w-12 h-6 rounded-full transition-colors duration-200
                      ${isEmployed ? 'bg-green-500/30' : 'bg-gray-800'}
                    `}
                  >
                    <div className={`
                      absolute top-1 w-4 h-4 rounded-full transition-transform duration-200
                      ${isEmployed 
                        ? 'translate-x-7 bg-green-400' 
                        : 'translate-x-1 bg-gray-600'
                      }
                    `} />
                  </button>
                )}
              </div>
            </div>
            
            {/* Active Modifiers */}
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              {/* Subtle texture overlay */}
              <div className="absolute inset-0 opacity-[0.02]" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='120' height='120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Ccircle cx='60' cy='60' r='30' fill='none' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Ccircle cx='20' cy='20' r='10' fill='none' stroke='white' stroke-width='0.2' opacity='0.15'/%3E%3Ccircle cx='100' cy='100' r='10' fill='none' stroke='white' stroke-width='0.2' opacity='0.15'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '120px 120px'
              }} />
              <div className="text-xs font-mono text-gray-500 mb-3">ACTIVE MODIFIERS</div>
              <div className="space-y-2">
                {activeBuffs.map((buff, index) => (
                  <div key={index} className="text-xs">
                    <span className="text-green-400 font-mono">{buff.buff}</span>
                  </div>
                ))}
                {activeBuffs.length === 0 && (
                  <div className="text-xs text-gray-600 italic">NO ACTIVE MODIFIERS</div>
                )}
              </div>
            </div>
          </div>
          
          {/* Center - Mek Display with Nebula Effect */}
          <div className="col-span-6">
            <div className="relative">
              {/* Nebula Glow Effect */}
              <div className="absolute inset-0 overflow-hidden">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                  {/* Animated nebula layers */}
                  <div className="absolute w-[600px] h-[600px] -translate-x-1/2 -translate-y-1/2 animate-pulse">
                    <div className="absolute inset-0 bg-gradient-radial from-purple-600/10 via-blue-600/5 to-transparent rounded-full blur-3xl" />
                  </div>
                  <div className="absolute w-[500px] h-[500px] -translate-x-1/2 -translate-y-1/2 animate-pulse" style={{ animationDelay: '0.5s' }}>
                    <div className="absolute inset-0 bg-gradient-radial from-cyan-500/10 via-purple-500/5 to-transparent rounded-full blur-2xl" />
                  </div>
                  <div className="absolute w-[400px] h-[400px] -translate-x-1/2 -translate-y-1/2 animate-pulse" style={{ animationDelay: '1s' }}>
                    <div className="absolute inset-0 bg-gradient-radial from-yellow-500/10 via-orange-500/5 to-transparent rounded-full blur-xl" />
                  </div>
                </div>
              </div>
              
              {/* Mek Image */}
              <div className="relative border border-gray-800/50 bg-gradient-to-b from-gray-950/40 to-black/40 backdrop-blur-[2px] p-8 overflow-hidden">
                {/* Very subtle scratch texture */}
                <div className="absolute inset-0 opacity-[0.008]" style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='200' height='200' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Cpath d='M20 20 L180 180' stroke='white' stroke-width='0.08' opacity='0.3'/%3E%3Cpath d='M180 20 L20 180' stroke='white' stroke-width='0.08' opacity='0.25'/%3E%3Cpath d='M100 0 L100 200' stroke='white' stroke-width='0.05' opacity='0.2'/%3E%3Cpath d='M0 100 L200 100' stroke='white' stroke-width='0.05' opacity='0.2'/%3E%3Cpath d='M50 0 L50 200' stroke='white' stroke-width='0.03' opacity='0.15'/%3E%3Cpath d='M150 0 L150 200' stroke='white' stroke-width='0.03' opacity='0.15'/%3E%3C/g%3E%3C/svg%3E")`,
                  backgroundSize: '200px 200px'
                }} />
                <MekImage
                  src={mek.iconUrl}
                  headVariation={mek.headVariation}
                  bodyVariation={mek.bodyVariation}
                  assetId={mek.assetId}
                  size={500}
                  className="w-full aspect-square relative z-10"
                />
              </div>
            </div>
            
            {/* Equipment Slots - Grid Below Mek */}
            <div className="flex justify-center gap-4 mt-4">
              {equipmentSlots.map((slot, index) => (
                <div key={slot.id} className="flex flex-col items-center">
                  {/* Round variation image - smaller and floating */}
                  <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-900/50 border border-gray-700/50 flex items-center justify-center">
                    {slot.filled && slot.variation ? (
                      <img 
                        src={`/variation-images/${slot.variation}.png`}
                        alt={slot.name || ''}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          // Fallback to icon if image fails
                          const target = e.currentTarget;
                          target.style.display = 'none';
                          if (target.nextElementSibling) {
                            (target.nextElementSibling as HTMLElement).style.display = 'flex';
                          }
                        }}
                      />
                    ) : null}
                    <div 
                      className="w-full h-full flex items-center justify-center"
                      style={{ display: slot.filled && slot.variation ? 'none' : 'flex' }}
                    >
                      {slot.filled ? (
                        <div className="text-2xl text-yellow-400">⚙</div>
                      ) : (
                        <div className="text-xl text-gray-600">+</div>
                      )}
                    </div>
                  </div>
                  
                  {/* Item Name Below */}
                  <div className="mt-1 text-center">
                    {slot.filled && slot.name ? (
                      <div className="text-xs font-mono text-yellow-400">
                        {slot.name}
                      </div>
                    ) : (
                      <div className="text-xs font-mono text-gray-600">
                        EMPTY
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Talent Tree Section - Below Equipment */}
            <div className="mt-6">
              <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
                <div className="text-xs font-mono text-gray-500 mb-3">TALENT TREE</div>
                <div className="grid grid-cols-5 gap-2">
                  {talentNodes.map((node) => (
                    <div key={node.id} className="text-center">
                      <div className={`
                        w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-bold mb-1
                        ${
                          node.unlocked
                            ? 'border-yellow-400 bg-yellow-400/20 text-yellow-400'
                            : 'border-gray-600 bg-gray-800/20 text-gray-600'
                        }
                      `}>
                        {node.level}
                      </div>
                      <div className="text-[10px] text-gray-500 leading-tight">
                        {node.name}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Panel - Level Progress & Gold Stats */}
          <div className="col-span-3 space-y-4">
            {/* Level Progress Bar */}
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              <div className="text-xs font-mono text-gray-500 mb-2">LEVEL PROGRESS</div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">LEVEL {mek.level || 1}</span>
                  <span className="text-sm text-gray-400">LEVEL {(mek.level || 1) + 1}</span>
                </div>
                <div className="w-full h-2 bg-gray-800 rounded">
                  <div 
                    className="h-full bg-gradient-to-r from-yellow-600 to-yellow-400 rounded transition-all duration-300"
                    style={{ width: '67%' }}
                  />
                </div>
                <div className="text-center">
                  <span className="text-xs text-gray-500">6,720 / 10,000 XP</span>
                </div>
              </div>
            </div>
            
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden glass-panel">
              {/* Subtle texture overlay */}
              <div className="absolute inset-0 opacity-[0.015]" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Cpath d='M0 30 L100 30' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Cpath d='M0 70 L100 70' stroke='white' stroke-width='0.3' opacity='0.2'/%3E%3Cpath d='M30 0 L30 100' stroke='white' stroke-width='0.2' opacity='0.15'/%3E%3Cpath d='M70 0 L70 100' stroke='white' stroke-width='0.2' opacity='0.15'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '100px 100px'
              }} />
              <div className="text-xs font-mono text-gray-500 mb-2">GOLD GENERATION</div>
              <div className="space-y-2">
                <div>
                  <div className="text-xs text-gray-600">BASE</div>
                  <div className="text-lg font-mono text-gray-400">20.0/hr</div>
                </div>
                <div className="h-px bg-gray-800"></div>
                <div>
                  <div className="text-xs text-green-400">EFFECTIVE</div>
                  <div className="text-xl font-mono font-bold text-green-400">23.5/hr</div>
                </div>
              </div>
            </div>
            
            <div className="relative border border-gray-800/50 bg-gray-950/30 backdrop-blur-[2px] p-4 overflow-hidden">
              {/* Subtle texture overlay */}
              <div className="absolute inset-0 opacity-[0.02]" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='80' height='80' xmlns='http://www.w3.org/2000/svg'%3E%3Cg%3E%3Cpath d='M5 5 L75 75' stroke='white' stroke-width='0.15' opacity='0.2'/%3E%3Cpath d='M75 5 L5 75' stroke='white' stroke-width='0.15' opacity='0.15'/%3E%3Cpath d='M40 0 L40 80' stroke='white' stroke-width='0.1' opacity='0.1'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundSize: '80px 80px'
              }} />
              <div className="text-xs font-mono text-gray-500 mb-2">GOLD PRODUCED</div>
              <div className="space-y-2">
                <div>
                  <div className="text-xs text-gray-600">CURRENT OWNER</div>
                  <div className="text-lg font-mono text-yellow-400">
                    {Math.floor(currentGoldForOwner).toLocaleString('en-US')}
                    <span className="text-sm text-yellow-400/70">.</span>
                    <span className="text-sm text-yellow-400/70">
                      {(currentGoldForOwner % 1).toFixed(3).substring(2)}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="text-xs text-gray-600">ALL TIME</div>
                  <div className="text-lg font-mono text-yellow-500">
                    {Math.floor(allTimeGold).toLocaleString('en-US')}
                    <span className="text-sm text-yellow-500/70">.</span>
                    <span className="text-sm text-yellow-500/70">
                      {(allTimeGold % 1).toFixed(3).substring(2)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      
    </div>
  );
}