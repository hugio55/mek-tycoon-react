"use client";

import { useState, useEffect } from "react";
import { useQuery } from "convex/react";
import { api } from "../../../convex/_generated/api";
import BackgroundEffects from "@/components/BackgroundEffects";
import MekImage from "@/components/MekImage";
import Link from "next/link";

type LeaderboardCategory = 'gold' | 'meks' | 'essence' | 'topMeks' | 'achievements';
type TopMeksSortBy = 'goldTotal' | 'goldPerHour' | 'essenceTotal' | 'essencePerHour';

interface LeaderboardEntry {
  rank: number;
  walletAddress: string;
  username?: string;
  value: number;
  metadata?: {
    level?: number;
    essenceBreakdown?: any;
    mekDetails?: {
      total: number;
      legendary: number;
      epic: number;
      rare: number;
      uncommon: number;
      common: number;
      topMekAssetId?: string;
      topMekLevel?: number;
    };
    goldPerHour?: number;
    essencePerHour?: number;
    achievementScore?: number;
    topMek?: {
      assetId: string;
      assetName: string;
      level: number;
      goldRate: number;
      essenceRate?: number;
      totalGold?: number;
      totalEssence?: number;
    };
  };
}

export default function LeaderboardPage() {
  const [currentWallet, setCurrentWallet] = useState<string>("demo_wallet_123");
  const [selectedCategory, setSelectedCategory] = useState<LeaderboardCategory>('gold');
  const [topMeksSortBy, setTopMeksSortBy] = useState<TopMeksSortBy>('goldPerHour');

  useEffect(() => {
    const stakeAddress = localStorage.getItem('stakeAddress');
    const paymentAddress = localStorage.getItem('walletAddress');
    const addressToUse = stakeAddress || paymentAddress || "demo_wallet_123";
    setCurrentWallet(addressToUse);
  }, []);

  // Use optimized cached leaderboard queries
  const leaderboardData = useQuery(api.leaderboardOptimized.getCachedLeaderboard, {
    category: selectedCategory,
    limit: 100,
    sortBy: selectedCategory === 'topMeks' ? topMeksSortBy : undefined
  });
  
  // Get current user from auth
  const currentUser = useQuery(api.users.getCurrentUser, { 
    walletAddress: currentWallet 
  });
  
  // Get user's rank for current category
  const userRank = useQuery(api.leaderboardOptimized.getUserRank, {
    userId: currentUser?._id,
    category: selectedCategory
  });
  
  // Get top 3 for achievements (for podium display), fallback to gold if no achievement data
  const topAchievementData = useQuery(api.leaderboardOptimized.getCachedLeaderboard, {
    category: 'achievements',
    limit: 3
  });
  
  // Fallback to gold data if no achievement data available
  const topGoldData = useQuery(api.leaderboardOptimized.getCachedLeaderboard, {
    category: 'gold',
    limit: 3
  });
  
  // Use achievement data if available, otherwise fall back to gold data
  const podiumData = (topAchievementData && topAchievementData.length > 0) ? topAchievementData : topGoldData;

  const formatNumber = (num: number | string | undefined) => {
    // Convert to number and handle invalid values
    const value = typeof num === 'number' ? num : Number(num) || 0;
    
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return '#FFD700';
    if (rank === 2) return '#C0C0C0';
    if (rank === 3) return '#CD7F32';
    if (rank <= 10) return '#E5E4E2';
    return '#6B7280';
  };

  const getRankIcon = (rank: number) => {
    return '';
  };

  const getCategoryData = () => {
    switch (selectedCategory) {
      case 'gold':
        return {
          columns: ['Player', 'Total Gold', 'Gold/hr'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            `${entry.metadata?.goldPerHour?.toFixed(1) || '0'}/hr`
          ],
          showHighestMek: false
        };
      case 'meks':
        return {
          columns: ['Player', 'Mek Count'],
          renderRow: (entry: LeaderboardEntry) => [
            entry.value
          ],
          showHighestMek: true
        };
      case 'essence':
        return {
          columns: ['Player', 'Total Essence', 'Essence/hr'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            `${entry.metadata?.essencePerHour?.toFixed(1) || '0'}/hr`
          ],
          showHighestMek: false
        };
      case 'topMeks':
        return {
          columns: ['Mek', 'Total Gold', 'Gold/hr', 'Total Essence', 'Essence/hr'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.metadata?.topMek?.totalGold || 0),
            `${entry.metadata?.topMek?.goldRate?.toFixed(1) || '0'}/hr`,
            formatNumber(entry.metadata?.topMek?.totalEssence || 0),
            `${entry.metadata?.topMek?.essenceRate?.toFixed(1) || '0'}/hr`
          ],
          clickableColumns: [1, 2, 3, 4], // indices of clickable columns
          sortValues: ['goldTotal', 'goldPerHour', 'essenceTotal', 'essencePerHour'],
          isMekList: true,
          showHighestMek: false
        };
      case 'achievements':
        return {
          columns: ['Achievement Points', 'Player'],
          renderRow: (entry: LeaderboardEntry) => [
            formatNumber(entry.value),
            null // Player cell handled separately
          ],
          showHighestMek: false,
          playerColIndex: 1
        };
      default:
        return { columns: [], renderRow: () => [], showHighestMek: false };
    }
  };

  const currentCategoryData = getCategoryData();
  const isUserInTop10 = leaderboardData?.some(entry => 
    entry.walletAddress === currentWallet
  );

  return (
    <div className="text-white py-8 min-h-screen relative">
      <BackgroundEffects />
      
      {/* Epic Title */}
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold mb-2">
          <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-500 bg-clip-text text-transparent">
            CARDOMINATORS
          </span>
        </h1>
        <p className="text-gray-400">The leaders of the leaders</p>
      </div>

      {/* Top 3 Gold Leaders - Podium Style with Ember Effects */}
      <div className="mb-12 max-w-5xl mx-auto">
        <div className="flex items-end justify-center gap-4 mb-8">
          {/* 2nd Place - Left */}
          {podiumData?.[1] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '280px',
                marginBottom: '0px',
                background: 'linear-gradient(135deg, rgba(192, 192, 192, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '2px solid #C0C0C0',
                boxShadow: '0 20px 40px rgba(192, 192, 192, 0.3)',
              }}
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={64}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-2xl font-bold mb-2" style={{ color: '#C0C0C0' }}>
                #2
              </div>
              <div className="text-lg font-medium text-white mb-1">{podiumData[1].username || 'Player 2'}</div>
              <div className="text-xs text-gray-400 mb-3">
                {podiumData[1].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-2xl font-bold text-yellow-400">{formatNumber(podiumData[1].value)}</div>
              <div className="text-xs text-gray-400">{topAchievementData?.length > 0 ? 'Achievement Score' : 'Total Gold'}</div>
            </div>
          )}

          {/* 1st Place - Center, Elevated with Embers */}
          {podiumData?.[0] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '320px',
                marginBottom: '40px',
                background: 'linear-gradient(135deg, rgba(255, 215, 0, 0.2) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '3px solid #FFD700',
                boxShadow: '0 30px 60px rgba(255, 215, 0, 0.4)',
              }}
            >
              {/* Ember particles */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute bottom-0 left-1/4 w-1 h-1 bg-orange-400 rounded-full animate-float-up" style={{ animationDelay: '0s', animationDuration: '3s' }} />
                <div className="absolute bottom-0 left-1/2 w-1.5 h-1.5 bg-yellow-400 rounded-full animate-float-up" style={{ animationDelay: '0.5s', animationDuration: '2.5s' }} />
                <div className="absolute bottom-0 left-3/4 w-1 h-1 bg-red-400 rounded-full animate-float-up" style={{ animationDelay: '1s', animationDuration: '3.5s' }} />
                <div className="absolute bottom-0 left-1/3 w-0.5 h-0.5 bg-orange-500 rounded-full animate-float-up" style={{ animationDelay: '1.5s', animationDuration: '3s' }} />
                <div className="absolute bottom-0 left-2/3 w-1 h-1 bg-yellow-500 rounded-full animate-float-up" style={{ animationDelay: '2s', animationDuration: '2.8s' }} />
              </div>
              <div className="w-20 h-20 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800 ring-4 ring-yellow-400/50">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={80}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-3xl font-bold mb-2" style={{ color: '#FFD700' }}>
                #1
              </div>
              <div className="text-xl font-bold text-white mb-1">{podiumData[0].username || 'Player 1'}</div>
              <div className="text-xs text-gray-400 mb-3">
                {podiumData[0].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-3xl font-bold text-yellow-400">{formatNumber(podiumData[0].value)}</div>
              <div className="text-sm text-gray-400">{topAchievementData?.length > 0 ? 'Achievement Score' : 'Total Gold'}</div>
              <div className="mt-3 text-sm text-gray-300">
                {podiumData[0].metadata?.mekDetails?.total || 0} meks • Level {podiumData[0].metadata?.level || 1}
              </div>
            </div>
          )}

          {/* 3rd Place - Right */}
          {podiumData?.[2] && (
            <div
              className="relative overflow-hidden rounded-lg p-6 text-center transform transition-all duration-300 hover:scale-105"
              style={{
                width: '280px',
                marginBottom: '0px',
                background: 'linear-gradient(135deg, rgba(205, 127, 50, 0.15) 0%, rgba(26, 26, 26, 0.85) 100%)',
                backdropFilter: 'blur(10px)',
                border: '2px solid #CD7F32',
                boxShadow: '0 20px 40px rgba(205, 127, 50, 0.3)',
              }}
            >
              <div className="w-16 h-16 mx-auto mb-3 rounded-full overflow-hidden bg-gray-800">
                <MekImage
                  src={undefined}
                  assetId={"0000"}
                  size={64}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-2xl font-bold mb-2" style={{ color: '#CD7F32' }}>
                #3
              </div>
              <div className="text-lg font-medium text-white mb-1">{podiumData[2].username || 'Player 3'}</div>
              <div className="text-xs text-gray-400 mb-3">
                {podiumData[2].walletAddress?.slice(0, 6)}...
              </div>
              <div className="text-2xl font-bold text-yellow-400">{formatNumber(podiumData[2].value)}</div>
              <div className="text-xs text-gray-400">{topAchievementData?.length > 0 ? 'Achievement Score' : 'Total Gold'}</div>
            </div>
          )}
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 mb-8 justify-center flex-wrap">
        <button
          onClick={(e) => {
            e.preventDefault();
            setSelectedCategory('achievements');
          }}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'achievements'
              ? 'bg-green-400/20 text-green-400 border border-green-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Achievement Points
        </button>
        
        <button
          onClick={(e) => {
            e.preventDefault();
            setSelectedCategory('gold');
          }}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'gold'
              ? 'bg-yellow-400/20 text-yellow-400 border border-yellow-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Gold
        </button>
        
        <button
          onClick={(e) => {
            e.preventDefault();
            setSelectedCategory('meks');
          }}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'meks'
              ? 'bg-blue-400/20 text-blue-400 border border-blue-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Mek Count
        </button>
        
        <button
          onClick={(e) => {
            e.preventDefault();
            setSelectedCategory('essence');
          }}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'essence'
              ? 'bg-purple-400/20 text-purple-400 border border-purple-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Essence
        </button>
        
        <button
          onClick={(e) => {
            e.preventDefault();
            setSelectedCategory('topMeks');
          }}
          className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
            selectedCategory === 'topMeks'
              ? 'bg-pink-400/20 text-pink-400 border border-pink-400/50'
              : 'bg-gray-900/50 text-gray-400 hover:text-white'
          }`}
        >
          Top Meks
        </button>
      </div>

      {/* Top 10 Table */}
      <div className="max-w-5xl mx-auto">
        <div
          className="rounded-lg overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.4) 0%, rgba(15, 15, 15, 0.4) 100%)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 204, 0, 0.2)',
          }}
        >
          <table className="w-full">
            <thead>
              <tr className="text-sm" style={{ borderBottom: '1px solid rgba(255, 204, 0, 0.3)' }}>
                <th className="text-left p-4 text-yellow-400 font-medium w-16">Rank</th>
                {currentCategoryData.columns?.map((col, i) => {
                  const isClickable = selectedCategory === 'topMeks' && currentCategoryData.clickableColumns?.includes(i);
                  const clickableIndex = currentCategoryData.clickableColumns?.indexOf(i);
                  const sortValue = isClickable && clickableIndex !== undefined ? currentCategoryData.sortValues?.[clickableIndex] : null;
                  const isActive = sortValue === topMeksSortBy;
                  
                  return (
                    <th 
                      key={i} 
                      className={`p-4 font-medium ${
                        i === 0 || (selectedCategory === 'achievements' && i === 1) ? 'text-left' : 'text-center'
                      } ${
                        isClickable ? 'cursor-pointer hover:text-yellow-300 hover:underline transition-all' : ''
                      } ${
                        isActive ? 'text-yellow-300 underline' : 'text-yellow-400'
                      }`}
                      onClick={isClickable && sortValue ? () => setTopMeksSortBy(sortValue as TopMeksSortBy) : undefined}
                    >
                      <div className={`flex items-center ${i === 0 ? 'justify-start' : 'justify-center'} gap-1`}>
                        {col}
                        {isClickable && (
                          <span className={`text-xs transition-transform ${isActive ? 'rotate-0' : '-rotate-90'}`}>
                            ▼
                          </span>
                        )}
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {leaderboardData?.slice(0, 10).map((entry, index) => {
                const isCurrentUser = entry.walletAddress === currentWallet;
                
                return (
                  <tr
                    key={index}
                    className="transition-all duration-200 hover:bg-white/5"
                    style={{
                      background: isCurrentUser ? 'rgba(250, 182, 23, 0.1)' : 'transparent',
                      borderBottom: '1px solid rgba(255, 255, 255, 0.03)',
                    }}
                  >
                    <td className="p-4 w-16">
                      <div className="flex items-center gap-1">
                        <span className="font-bold" style={{ color: getRankColor(entry.rank) }}>
                          {entry.rank}
                        </span>
                        {entry.rank <= 3 && <span className="text-sm">{getRankIcon(entry.rank)}</span>}
                      </div>
                    </td>
                    {selectedCategory === 'achievements' ? (
                      <>
                        <td className="p-4 text-center text-gray-300">
                          {formatNumber(entry.value)}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                              <MekImage
                                src={undefined}
                                assetId={"0000"}
                                size={40}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex flex-col">
                              <span className={`font-medium ${isCurrentUser ? 'text-yellow-400' : 'text-white'}`}>
                                {entry.username || 'Anonymous'}
                              </span>
                              <span className="text-xs text-gray-500">
                                {entry.walletAddress?.slice(0, 6)}...
                              </span>
                            </div>
                          </div>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="p-4">
                          {currentCategoryData.isMekList ? (
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded overflow-hidden bg-gray-800">
                                <MekImage
                                  src={undefined}
                                  assetId={entry.metadata?.topMek?.assetId || "0000"}
                                  size={40}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex flex-col">
                                <span className={`font-medium ${isCurrentUser ? 'text-yellow-400' : 'text-white'}`}>
                                  {entry.metadata?.topMek?.assetName || 'Unknown Mek'}
                                </span>
                                <span className="text-xs text-gray-500">
                                  Level {entry.metadata?.topMek?.level || 1}
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                                <MekImage
                                  src={undefined}
                                  assetId={currentCategoryData.showHighestMek && entry.metadata?.mekDetails?.topMekAssetId ? 
                                    entry.metadata.mekDetails.topMekAssetId : "0000"}
                                  size={40}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex flex-col">
                                <span className={`font-medium ${isCurrentUser ? 'text-yellow-400' : 'text-white'}`}>
                                  {entry.username || 'Anonymous'}
                                </span>
                                <span className="text-xs text-gray-500">
                                  {entry.walletAddress?.slice(0, 6)}...
                                </span>
                              </div>
                            </div>
                          )}
                        </td>
                        {currentCategoryData.renderRow && currentCategoryData.renderRow(entry).map((value, i) => (
                          value !== null && (
                            <td key={i} className="p-4 text-center text-gray-300">
                              {value}
                            </td>
                          )
                        ))}
                      </>
                    )}
                  </tr>
                );
              })}
              
              {/* Show 11th row as user's position if not in top 10 */}
              {!isUserInTop10 && userRank && userRank > 10 && currentUser && leaderboardData?.length >= 10 && (
                <>
                  {/* Separator row */}
                  <tr>
                    <td colSpan={currentCategoryData.columns.length + 1} className="p-2">
                      <div className="flex items-center justify-center gap-2">
                        <div className="flex-1 h-px bg-gray-700"></div>
                        <span className="text-xs text-gray-500 px-2">Your Rank</span>
                        <div className="flex-1 h-px bg-gray-700"></div>
                      </div>
                    </td>
                  </tr>
                  {/* User's rank row */}
                  <tr
                    className="transition-all duration-200"
                    style={{
                      background: 'rgba(250, 182, 23, 0.15)',
                      border: '1px solid rgba(250, 182, 23, 0.3)',
                    }}
                  >
                    <td className="p-4 w-16">
                      <span className="font-bold text-yellow-400">
                        {userRank}
                      </span>
                    </td>
                    {selectedCategory === 'achievements' ? (
                      <>
                        <td className="p-4 text-center text-gray-300">
                          {(() => {
                            const userEntry = leaderboardData?.find(e => e.walletAddress === currentUser.walletAddress);
                            return userEntry ? formatNumber(userEntry.value) : '0';
                          })()}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                              <MekImage
                                src={undefined}
                                assetId={"0000"}
                                size={40}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-medium text-yellow-400">
                                {currentUser.username || 'You'}
                              </span>
                              <span className="text-xs text-gray-500">
                                {currentUser.walletAddress?.slice(0, 6)}...
                              </span>
                            </div>
                          </div>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-800">
                              <MekImage
                                src={undefined}
                                assetId={"0000"}
                                size={40}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex flex-col">
                              <span className="font-medium text-yellow-400">
                                {currentUser.username || 'You'}
                              </span>
                              <span className="text-xs text-gray-500">
                                {currentUser.walletAddress?.slice(0, 6)}...
                              </span>
                            </div>
                          </div>
                        </td>
                        {/* Show actual user data if available */}
                        {(() => {
                          const userEntry = leaderboardData?.find(e => e.walletAddress === currentUser.walletAddress);
                          if (userEntry && currentCategoryData.renderRow) {
                            return currentCategoryData.renderRow(userEntry).map((value, i) => (
                              value !== null && (
                                <td key={i} className="p-4 text-center text-gray-300">
                                  {value}
                                </td>
                              )
                            ));
                          }
                          return (
                            <td colSpan={currentCategoryData.columns.length - 1} className="p-4 text-center text-gray-400">
                              Loading your stats...
                            </td>
                          );
                        })()}
                      </>
                    )}
                  </tr>
                </>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}