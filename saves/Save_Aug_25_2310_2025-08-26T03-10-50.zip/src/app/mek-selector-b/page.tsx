'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery } from 'convex/react';
import { api } from '@/convex/_generated/api';
import Image from 'next/image';

// Temporary mek images for demonstration
const TEMP_MEK_IMAGES = [
  'mek1085', 'mek1107', 'mek1234', 'mek1456', 'mek1789',
  'mek2001', 'mek2345', 'mek2567', 'mek2890', 'mek3012',
  'mek3234', 'mek3456', 'mek3678', 'mek3890', 'mek4012',
  'mek4234', 'mek4456', 'mek4678', 'mek4890', 'mek5012',
  'mek5234', 'mek5456', 'mek5678', 'mek5890', 'mek6012',
  'mek6234', 'mek6456', 'mek6678', 'mek6890', 'mek7012',
  'mek7234', 'mek7456', 'mek7678', 'mek7890', 'mek8012',
  'mek8234', 'mek8456', 'mek8678', 'mek8890', 'mek9012',
  'mek9234', 'mek9456', 'mek9678', 'mek9890', 'mek9999',
];

export default function MekSelectorB() {
  const allMeks = useQuery(api.meks.getAllMeksWithSourceKeys, { limit: 500 });
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [gridSize, setGridSize] = useState(30); // Default to 30 meks
  const [isAnimating, setIsAnimating] = useState(false);
  const [feedback, setFeedback] = useState<'perfect' | 'undershoot' | 'overshoot' | null>(null);
  const animationRef = useRef<number>();
  const containerRef = useRef<HTMLDivElement>(null);
  const plungerRef = useRef<HTMLDivElement>(null);
  const dragStartX = useRef(0);
  const currentIndexRef = useRef(0);
  const targetIndexRef = useRef(0);
  const animationSpeed = useRef(0);
  const audioRef = useRef<HTMLAudioElement>();
  const totalDistanceTraveled = useRef(0);
  
  // Sort meks by rank (lowest to highest) and limit to gridSize
  const sortedMeks = allMeks?.sort((a, b) => (a.rarityRank || 9999) - (b.rarityRank || 9999)).slice(0, gridSize) || [];
  const gridCols = Math.min(10, Math.ceil(Math.sqrt(gridSize))); // Dynamic columns based on grid size
  const totalMeks = sortedMeks.length;

  // Animate the selection movement with proper inertia
  const animate = useCallback(() => {
    if (animationSpeed.current > 0.005) {
      // Move the selector
      currentIndexRef.current += animationSpeed.current;
      totalDistanceTraveled.current += animationSpeed.current;
      
      // Wrap around if necessary
      while (currentIndexRef.current >= totalMeks) {
        currentIndexRef.current -= totalMeks;
      }
      
      // Update visible selection
      setSelectedIndex(Math.floor(currentIndexRef.current));
      
      // Apply variable friction - increases at higher speeds (like air resistance)
      // This makes it MUCH harder to control at high power
      const baseFriction = 0.985;
      const speedPenalty = Math.min(animationSpeed.current * 0.003, 0.015); // Extra friction at high speed
      const actualFriction = baseFriction - speedPenalty;
      
      animationSpeed.current *= actualFriction;
      
      // Add slight random wobble at very high speeds (instability)
      if (animationSpeed.current > 0.8) {
        animationSpeed.current *= (0.97 + Math.random() * 0.06);
      }
      
      // Bounce-back effect - at extreme speeds, sometimes reverse direction slightly
      if (animationSpeed.current > 1.2 && Math.random() < 0.05) {
        animationSpeed.current *= -0.3; // Occasional bounce-back
      }
      
      animationRef.current = requestAnimationFrame(animate);
    } else {
      // Animation complete - snap to final position
      const finalIndex = Math.round(currentIndexRef.current) % totalMeks;
      setSelectedIndex(finalIndex);
      setIsAnimating(false);
      animationSpeed.current = 0;
      
      // Check result and provide feedback
      const totalDistance = totalDistanceTraveled.current;
      const targetRareZone = totalMeks * 0.7; // Rare meks are in the last 30%
      const perfectZone = totalMeks * 0.85; // Sweet spot for best meks
      
      if (totalDistance >= targetRareZone && totalDistance <= perfectZone + 5) {
        setFeedback('perfect');
      } else if (totalDistance < targetRareZone) {
        setFeedback('undershoot');
      } else {
        setFeedback('overshoot');
      }
      
      // Clear feedback after 3 seconds
      setTimeout(() => setFeedback(null), 3000);
    }
  }, [totalMeks]);

  // Handle mouse/touch start on plunger
  const handlePlungerStart = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const point = 'touches' in e ? e.touches[0] : e;
    setIsDragging(true);
    dragStartX.current = point.clientX;
    setPullDistance(0);
    
    // Stop any ongoing animation
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    setIsAnimating(false);
    animationSpeed.current = 0;
  };

  // Handle mouse/touch move
  const handleDragMove = (e: MouseEvent | TouchEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    const point = 'touches' in e ? e.touches[0] : e;
    
    // Calculate pull distance (only to the right)
    const distance = Math.max(0, point.clientX - dragStartX.current);
    const maxPull = 400; // Maximum pull distance in pixels
    setPullDistance(Math.min(distance, maxPull));
  };

  // Handle mouse/touch end
  const handleDragEnd = () => {
    if (!isDragging) return;
    
    // Reset distance counter
    totalDistanceTraveled.current = 0;
    
    // Calculate power percentage with exponential scaling for difficulty
    const rawPowerPercentage = pullDistance / 400;
    
    // Super exponential scaling - EXTREMELY sensitive at high power levels
    // This creates a narrow "sweet spot" mechanic where precision is critical
    const powerPercentage = Math.pow(rawPowerPercentage, 2.2); // Even more exponential!
    
    // Add variance that increases dramatically with power (chaos at high power)
    const baseVariance = 0.05 + Math.random() * 0.08; // 5-13% base
    const powerVariance = powerPercentage * 0.25 * Math.random(); // Up to 25% additional at full power
    const totalVariance = baseVariance + powerVariance;
    const varianceMultiplier = 1 + (Math.random() > 0.5 ? totalVariance : -totalVariance);
    
    // Calculate target distance with EXTREME overshoot at high power
    // Sweet spot is now VERY narrow (65-72% raw power)
    const loopsMultiplier = 
      rawPowerPercentage < 0.5 ? 0.5 :          // Way too weak
      rawPowerPercentage < 0.65 ? 0.8 :         // Still too weak
      rawPowerPercentage < 0.72 ? 1.2 :         // SWEET SPOT!
      rawPowerPercentage < 0.78 ? 3.0 :         // Starting to overshoot
      rawPowerPercentage < 0.85 ? 5.0 :         // Major overshoot
      8.0;                                       // Complete disaster!
    
    const targetDistance = loopsMultiplier * totalMeks * powerPercentage * varianceMultiplier;
    
    // With friction of 0.985, calculate initial speed
    const frictionFactor = 0.015; // 1 - 0.985
    const initialSpeed = targetDistance * frictionFactor;
    
    // Cap max speed at 1.5 meks per frame for visibility
    animationSpeed.current = Math.min(initialSpeed, 1.5);
    
    setIsDragging(false);
    setPullDistance(0);
    
    // Start animation
    if (animationSpeed.current > 0) {
      setIsAnimating(true);
      currentIndexRef.current = selectedIndex;
      animationRef.current = requestAnimationFrame(animate);
    }
  };

  // Add global event listeners for drag
  useEffect(() => {
    if (isDragging) {
      const handleMove = (e: MouseEvent | TouchEvent) => handleDragMove(e);
      const handleEnd = () => handleDragEnd();
      
      window.addEventListener('mousemove', handleMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleMove);
      window.addEventListener('touchend', handleEnd);
      
      return () => {
        window.removeEventListener('mousemove', handleMove);
        window.removeEventListener('mouseup', handleEnd);
        window.removeEventListener('touchmove', handleMove);
        window.removeEventListener('touchend', handleEnd);
      };
    }
  }, [isDragging, pullDistance]);

  // Clean up animation on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  // Reset function
  const handleReset = () => {
    setSelectedIndex(0);
    currentIndexRef.current = 0;
    animationSpeed.current = 0;
    setIsAnimating(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  if (!allMeks) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-yellow-400">Loading Meks...</p>
      </div>
    );
  }

  const currentMek = sortedMeks[selectedIndex];

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-black text-white p-8 relative overflow-hidden select-none"
    >
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-4xl font-bold text-yellow-400 mb-2">Mek Selector B</h1>
          <p className="text-gray-400">Pull the plunger right and release to launch through Meks</p>
          
          {/* Current Selection Info */}
          <div className="mt-4">
            <p className="text-xl text-yellow-400">
              Mek #{selectedIndex + 1} of {totalMeks} | Rank: {currentMek?.rarityRank || 'N/A'}
            </p>
            {isAnimating && (
              <p className="text-green-400">
                Speed: {(animationSpeed.current * 10).toFixed(1)}
              </p>
            )}
          </div>
          
          {/* Result Feedback */}
          {feedback && (
            <div className={`mt-4 p-3 rounded-lg text-center font-bold animate-pulse ${
              feedback === 'perfect' ? 'bg-green-600/30 text-green-400 border-2 border-green-400' :
              feedback === 'undershoot' ? 'bg-blue-600/30 text-blue-400 border-2 border-blue-400' :
              'bg-red-600/30 text-red-400 border-2 border-red-400'
            }`}>
              {feedback === 'perfect' ? '🎯 PERFECT! You hit the sweet spot!' :
               feedback === 'undershoot' ? '📉 Too weak! Need more power to reach rare meks!' :
               '🚀 Too powerful! You overshot the rare meks!'}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="flex gap-4 mb-6">
          {/* Reset Button */}
          <button
            onClick={handleReset}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
          >
            Reset
          </button>
          
          {/* Grid Size Selector */}
          <div className="flex gap-2">
            <span className="text-gray-400 py-2">Grid Size:</span>
            {[3, 10, 30, 100].map(size => (
              <button
                key={size}
                onClick={() => {
                  setGridSize(size);
                  handleReset();
                }}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  gridSize === size 
                    ? 'bg-yellow-400 text-black' 
                    : 'bg-gray-700 hover:bg-gray-600 text-white'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Horizontal Plunger - Full Width */}
        <div className="w-full mb-6">
          <div className="w-full h-16 bg-gray-800 rounded-lg border-2 border-yellow-400/50 relative overflow-hidden">
            {/* Difficulty Zones Background */}
            <div className="absolute inset-0 flex">
              {/* Too Weak Zone (0-65%) */}
              <div className="w-[65%] bg-gradient-to-r from-blue-900/20 to-green-900/20" />
              {/* Sweet Spot Zone (65-72%) - VERY NARROW for reaching rare meks */}
              <div className="w-[7%] bg-gradient-to-r from-yellow-500/40 to-green-500/40 animate-pulse" />
              {/* Overshoot Warning (72-78%) */}
              <div className="w-[6%] bg-gradient-to-r from-orange-900/30 to-red-900/30" />
              {/* Danger Zone (78-100%) - Guaranteed overshoot */}
              <div className="w-[22%] bg-gradient-to-r from-red-900/40 to-red-900/60" />
            </div>
            
            {/* Zone Labels */}
            <div className="absolute inset-0 flex items-end pb-1 pointer-events-none">
              <div className="w-[65%] text-center text-[9px] text-blue-400/50">TOO WEAK</div>
              <div className="w-[7%] text-center text-[8px] text-yellow-400/70 font-bold">WIN!</div>
              <div className="w-[6%] text-center text-[8px] text-orange-400/50">WARN</div>
              <div className="w-[22%] text-center text-[9px] text-red-400/50">FAIL ZONE</div>
            </div>
            
            {/* Plunger Handle */}
            <div
              ref={plungerRef}
              className="absolute top-1/2 left-4 transform -translate-y-1/2 w-16 h-12 bg-yellow-400 rounded-lg cursor-grab active:cursor-grabbing shadow-lg transition-none z-10"
              style={{ 
                transform: `translate(${pullDistance}px, -50%)`,
              }}
              onMouseDown={handlePlungerStart}
              onTouchStart={handlePlungerStart}
            >
              <div className="w-full h-full flex items-center justify-center">
                <div className="w-8 h-2 bg-black/30 rounded-full" />
              </div>
            </div>
            
            {/* Power Indicator Bar */}
            {pullDistance > 0 && (
              <div 
                className={`absolute top-0 bottom-0 left-0 transition-colors ${
                  pullDistance < 260 ? 'bg-gradient-to-r from-blue-400/20 via-blue-400/30 to-blue-400/40' :
                  pullDistance < 288 ? 'bg-gradient-to-r from-yellow-400/30 via-green-400/40 to-yellow-400/50' :
                  pullDistance < 312 ? 'bg-gradient-to-r from-orange-400/20 via-orange-400/30 to-orange-400/40' :
                  'bg-gradient-to-r from-red-400/30 via-red-400/40 to-red-600/50'
                }`}
                style={{ width: `${(pullDistance / 400) * 100}%` }}
              />
            )}
            
            {/* Visual guides */}
            <div className="absolute inset-0 flex items-center px-20 pointer-events-none">
              {[65, 72, 78].map(percent => (
                <div 
                  key={percent}
                  className={`absolute top-0 bottom-0 ${
                    percent === 65 || percent === 72 ? 'w-[2px] bg-yellow-400/50' : 'w-px bg-red-400/40'
                  }`}
                  style={{ left: `${percent}%` }}
                />
              ))}
            </div>
          </div>
          
          {/* Helper Text */}
          {isDragging && (
            <div className="text-center text-xs mt-1">
              {pullDistance < 260 ? 
                <span className="text-blue-400">Too weak - Won't reach rare meks</span> :
               pullDistance < 288 ? 
                <span className="text-yellow-400 font-bold animate-pulse">⚡ PERFECT ZONE! Release now! ⚡</span> :
               pullDistance < 312 ?
                <span className="text-orange-400">Warning - Starting to overshoot!</span> :
                <span className="text-red-400 font-bold">💥 DANGER! Will massively overshoot! 💥</span>
              }
            </div>
          )}
        </div>

        {/* Mek Grid */}
        <div className="max-w-6xl mx-auto">
          <div 
            className="grid gap-2"
            style={{ gridTemplateColumns: `repeat(${gridCols}, minmax(0, 1fr))` }}
          >
            {sortedMeks.map((mek, index) => {
              const isSelected = index === selectedIndex;
              // Use temporary image if no sourceKeyBase
              const tempImage = TEMP_MEK_IMAGES[index % TEMP_MEK_IMAGES.length];
              
              return (
                <div
                  key={mek._id}
                  className={`relative aspect-square rounded-lg overflow-hidden transition-all ${
                    isSelected 
                      ? 'ring-4 ring-yellow-400 scale-110 z-10 duration-100' 
                      : 'ring-1 ring-gray-700 opacity-50 duration-300'
                  }`}
                >
                  {mek.sourceKeyBase || tempImage ? (
                    <Image
                      src={`/mek_nft_images_150px/${mek.sourceKeyBase || tempImage}.png`}
                      alt={mek.assetName || `Mek #${mek.assetId}`}
                      width={150}
                      height={150}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        // Fallback if image doesn't exist
                        (e.target as HTMLImageElement).style.display = 'none';
                        (e.target as HTMLImageElement).parentElement!.innerHTML = `
                          <div class="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                            <span class="text-xs text-gray-500">#${mek.assetId}</span>
                          </div>
                        `;
                      }}
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                      <span className="text-xs text-gray-500">#{mek.assetId}</span>
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-1">
                    <p className="text-xs text-center">Rank {mek.rarityRank || index + 1}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}