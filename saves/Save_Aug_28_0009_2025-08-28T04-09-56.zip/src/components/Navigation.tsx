"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useSound } from "@/contexts/SoundContext";

interface NavCategory {
  id: string;
  title: string;
  icon: string;
  items: {
    label: string;
    href: string;
  }[];
}

const navCategories: readonly NavCategory[] = [
  {
    id: "operations",
    title: "Operations",
    icon: "🏭",
    items: [
      { label: "Essence", href: "/essence" },
      // { label: "Essence Empire", href: "/essence-empire" },
    ],
  },
  {
    id: "scrapyard",
    title: "Scrap Yard",
    icon: "🎮",
    items: [
      // { label: "Fighting Arena", href: "/arena" },
      // { label: "Minigames", href: "/minigames" },
      { label: "Flux Battle", href: "/scrapyard/flux" },
      { label: "Bagatelle", href: "/bagatelle" },
      { label: "Block Tower", href: "/scrap-yard/block-game" },
      { label: "Circular Tower", href: "/scrap-yard/block-tower-b" },
      { label: "Spell Caster", href: "/spell-caster" },
    ],
  },
  {
    id: "production",
    title: "Production",
    icon: "⚙️",
    items: [
      { label: "Crafting", href: "/crafting" },
      { label: "Incinerator", href: "/incinerator" },
      { label: "Shop", href: "/shop" },
      { label: "Bank", href: "/bank" },
      { label: "Inventory", href: "/inventory" },
    ],
  },
  {
    id: "progression",
    title: "Progression",
    icon: "📈",
    items: [
      { label: "CiruTree", href: "/cirutree" },
      { label: "Achievements", href: "/achievements" },
      { label: "XP Allocation", href: "/xp-allocation" },
      { label: "My Meks", href: "/profile" },
      { label: "Search", href: "/search" },
      { label: "Leaderboard", href: "/leaderboard" },
    ],
  },
];

const adminCategory: NavCategory = {
  id: "admin",
  title: "Admin",
  icon: "⚡",
  items: [
    { label: "Save System", href: "/admin-save" },
    // { label: "Mek Assignment", href: "/mek-assignment" },
    { label: "Mek Selector", href: "/mek-selector" },
    { label: "Mek Selector Grid", href: "/mek-selector-grid" },
    { label: "Mek Selector B", href: "/mek-selector-b" },
    // { label: "Mek Swarm", href: "/mek-swarm" },
    { label: "Shop Manager", href: "/admin-shop" },
    // { label: "Balance", href: "/balance" },
    { label: "Rarity Bias", href: "/rarity-bias" },
    { label: "Talent Builder", href: "/talent-builder" },
  ],
};

export default function Navigation() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [expandedAdmin, setExpandedAdmin] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const adminRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  const { soundEnabled, toggleSound, playClickSound } = useSound();

  const toggleCategory = (categoryId: string) => {
    playClickSound();
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  // Handle mounting
  useEffect(() => {
    setMounted(true);
  }, []);

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setExpandedCategory(null);
      }
      if (adminRef.current && !adminRef.current.contains(event.target as Node)) {
        setExpandedAdmin(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div>
      {/* Navigation Layout */}
      <div className="flex flex-col items-center mb-4">
        {/* Logo */}
        <Link href="/hub" className="group mb-4">
          <Image
            src="/logo-big.png"
            alt="Mek Tycoon Logo"
            width={250}
            height={60}
            className="object-contain h-[60px] w-auto drop-shadow-[0_0_5px_rgba(250,182,23,0.5)] group-hover:drop-shadow-[0_0_7.5px_rgba(250,182,23,0.8)] transition-all"
            priority
          />
        </Link>
        
        {/* 4 Menu Buttons in a Row */}
        <div className="flex items-center justify-center gap-2 mb-4" ref={navRef}>
          {/* Operations Button */}
          <div
            className={`relative bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/50 rounded-lg overflow-visible transition-all ${
              expandedCategory === 'operations'
                ? "border-yellow-400 shadow-[0_4px_20px_rgba(255,204,0,0.3)] z-50"
                : "hover:border-yellow-400/70"
            }`}
          >
            <button
              onClick={() => toggleCategory('operations')}
              className="px-4 py-2 flex items-center gap-1.5 hover:bg-yellow-400/5 transition-colors"
            >
              <span className="text-yellow-400 text-xs font-bold uppercase tracking-wider">
                Operations
              </span>
              <span className={`text-yellow-400 text-[10px] transition-transform ${expandedCategory === 'operations' ? "rotate-180" : ""}`}>
                ▼
              </span>
            </button>
            {mounted && (
              <div
                className={`absolute top-full left-0 mt-1 min-w-[160px] bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all z-50 ${
                  expandedCategory === 'operations'
                    ? "opacity-100 visible translate-y-0 pointer-events-auto"
                    : "opacity-0 invisible -translate-y-2 pointer-events-none"
                }`}
              >
                <div className="p-2 grid grid-cols-1 gap-1">
                  {navCategories[0].items.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="relative px-3 py-1.5 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-xs font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                      onClick={() => {
                        playClickSound();
                        setExpandedCategory(null);
                      }}
                    >
                      <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                      <span className="relative z-10">{item.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Scrap Yard Button */}
          <div
            className={`relative bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/50 rounded-lg overflow-visible transition-all ${
              expandedCategory === 'scrapyard'
                ? "border-yellow-400 shadow-[0_4px_20px_rgba(255,204,0,0.3)] z-50"
                : "hover:border-yellow-400/70"
            }`}
          >
            <button
              onClick={() => toggleCategory('scrapyard')}
              className="px-4 py-2 flex items-center gap-1.5 hover:bg-yellow-400/5 transition-colors"
            >
              <span className="text-yellow-400 text-xs font-bold uppercase tracking-wider">
                Scrap Yard
              </span>
              <span className={`text-yellow-400 text-[10px] transition-transform ${expandedCategory === 'scrapyard' ? "rotate-180" : ""}`}>
                ▼
              </span>
            </button>
            {mounted && (
              <div
                className={`absolute top-full left-0 mt-1 min-w-[160px] bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all z-50 ${
                  expandedCategory === 'scrapyard'
                    ? "opacity-100 visible translate-y-0 pointer-events-auto"
                    : "opacity-0 invisible -translate-y-2 pointer-events-none"
                }`}
              >
                <div className="p-2 grid grid-cols-1 gap-1">
                  {navCategories[1].items.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="relative px-3 py-1.5 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-xs font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                      onClick={() => {
                        playClickSound();
                        setExpandedCategory(null);
                      }}
                    >
                      <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                      <span className="relative z-10">{item.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Production Button */}
          <div
            className={`relative bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/50 rounded-lg overflow-visible transition-all ${
              expandedCategory === 'production'
                ? "border-yellow-400 shadow-[0_4px_20px_rgba(255,204,0,0.3)] z-50"
                : "hover:border-yellow-400/70"
            }`}
          >
            <button
              onClick={() => toggleCategory('production')}
              className="px-4 py-2 flex items-center gap-1.5 hover:bg-yellow-400/5 transition-colors"
            >
              <span className="text-yellow-400 text-xs font-bold uppercase tracking-wider">
                Production
              </span>
              <span className={`text-yellow-400 text-[10px] transition-transform ${expandedCategory === 'production' ? "rotate-180" : ""}`}>
                ▼
              </span>
            </button>
            {mounted && (
              <div
                className={`absolute top-full left-0 mt-1 min-w-[160px] bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all z-50 ${
                  expandedCategory === 'production'
                    ? "opacity-100 visible translate-y-0 pointer-events-auto"
                    : "opacity-0 invisible -translate-y-2 pointer-events-none"
                }`}
              >
                <div className="p-2 grid grid-cols-1 gap-1">
                  {navCategories[2].items.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="relative px-3 py-1.5 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-xs font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                      onClick={() => {
                        playClickSound();
                        setExpandedCategory(null);
                      }}
                    >
                      <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                      <span className="relative z-10">{item.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Progression Button */}
          <div
            className={`relative bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/50 rounded-lg overflow-visible transition-all ${
              expandedCategory === 'progression'
                ? "border-yellow-400 shadow-[0_4px_20px_rgba(255,204,0,0.3)] z-50"
                : "hover:border-yellow-400/70"
            }`}
          >
            <button
              onClick={() => toggleCategory('progression')}
              className="px-4 py-2 flex items-center gap-1.5 hover:bg-yellow-400/5 transition-colors"
            >
              <span className="text-yellow-400 text-xs font-bold uppercase tracking-wider">
                Progression
              </span>
              <span className={`text-yellow-400 text-[10px] transition-transform ${expandedCategory === 'progression' ? "rotate-180" : ""}`}>
                ▼
              </span>
            </button>
            {mounted && (
              <div
                className={`absolute top-full right-0 mt-1 min-w-[160px] bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all z-50 ${
                  expandedCategory === 'progression'
                    ? "opacity-100 visible translate-y-0 pointer-events-auto"
                    : "opacity-0 invisible -translate-y-2 pointer-events-none"
                }`}
              >
                <div className="p-2 grid grid-cols-1 gap-1">
                  {navCategories[3].items.map((item) => (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="relative px-3 py-1.5 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-xs font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                      onClick={() => {
                        playClickSound();
                        setExpandedCategory(null);
                      }}
                    >
                      <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                      <span className="relative z-10">{item.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* HUB Button Below */}
        <div className="flex justify-center">
          <Link
            href="/hub"
            onClick={playClickSound}
            className="relative h-[40px] w-[100px] flex items-center justify-center bg-black/20 border-2 border-yellow-400 text-yellow-400 rounded-lg font-bold uppercase tracking-wider text-lg hover:scale-105 transition-transform hover:shadow-[0_0_15px_rgba(250,182,23,0.5)] group overflow-hidden"
            style={{
              background: `
                repeating-linear-gradient(
                  45deg,
                  rgba(0, 0, 0, 0.3),
                  rgba(0, 0, 0, 0.3) 8px,
                  rgba(255, 204, 0, 0.08) 8px,
                  rgba(255, 204, 0, 0.08) 16px
                ),
                linear-gradient(135deg, rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.4) 50%, rgba(0, 0, 0, 0.3) 100%)
              `,
            }}
          >
            <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
            <span className="relative z-10 drop-shadow-[0_0_4px_rgba(255,204,0,0.4)]">HUB</span>
          </Link>
        </div>
      </div>

      {/* Admin Dropdown in Upper Left */}
      <div className="absolute top-2 left-2 z-50" ref={adminRef}>
        <button
          onClick={() => {
            playClickSound();
            setExpandedAdmin(!expandedAdmin);
          }}
          className="px-2 py-1 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/30 rounded hover:border-yellow-400/50 transition-all flex items-center gap-1"
        >
          <span className="text-[10px]">⚡</span>
          <span className="text-yellow-400 text-[10px] font-semibold uppercase tracking-wider">Admin</span>
          <span className={`text-yellow-400 text-[8px] transition-transform ${expandedAdmin ? "rotate-180" : ""}`}>▼</span>
        </button>
        
        {mounted && (
          <div
            className={`absolute top-full left-0 mt-1 w-40 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all ${
              expandedAdmin
                ? "opacity-100 visible translate-y-0 pointer-events-auto"
                : "opacity-0 invisible -translate-y-2 pointer-events-none"
            }`}
          >
            <div className="p-2 grid grid-cols-1 gap-1">
              {adminCategory.items.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="relative px-2 py-1 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-[10px] font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                  onClick={() => {
                    playClickSound();
                    setExpandedAdmin(false);
                  }}
                >
                  <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                  <span className="relative z-10">{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Wallet Button in Upper Right */}
      <div className="absolute top-2 right-2 z-50">
        <button
          onClick={() => {
            playClickSound();
            // Clear wallet data from localStorage
            localStorage.removeItem('connectedWallet');
            localStorage.removeItem('walletAddress');
            localStorage.removeItem('stakeAddress');
            // Redirect to welcome page
            window.location.href = '/';
          }}
          className="px-2 py-1 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/30 rounded hover:border-yellow-400/50 transition-all flex items-center gap-1"
        >
          <span className="text-yellow-400 text-[10px] font-semibold uppercase tracking-wider">Wallet</span>
        </button>
      </div>

      {/* Sound Toggle and Welcome Link Bottom Left */}
      <div className="absolute bottom-2 left-2 z-50 flex items-center gap-2">
        <button
          onClick={() => {
            playClickSound();
            toggleSound();
          }}
          className="text-gray-400 hover:text-yellow-400 text-sm transition-colors p-1"
          title={soundEnabled ? "Mute Sounds" : "Enable Sounds"}
        >
          {soundEnabled ? (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path>
            </svg>
          ) : (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <line x1="23" y1="9" x2="17" y2="15"></line>
              <line x1="17" y1="9" x2="23" y2="15"></line>
            </svg>
          )}
        </button>
        <Link
          href="/"
          className="text-gray-500 hover:text-yellow-400 text-[10px] transition-colors"
          onClick={playClickSound}
        >
          ← Welcome
        </Link>
      </div>

    </div>
  );
}