"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useSound } from "@/contexts/SoundContext";

interface NavCategory {
  id: string;
  title: string;
  icon: string;
  items: {
    label: string;
    href: string;
  }[];
}

const navCategories: readonly NavCategory[] = [
  {
    id: "operations",
    title: "Operations",
    icon: "🏭",
    items: [
      { label: "Essence", href: "/essence" },
      // { label: "Essence Empire", href: "/essence-empire" },
    ],
  },
  {
    id: "scrapyard",
    title: "Scrap Yard",
    icon: "🎮",
    items: [
      // { label: "Fighting Arena", href: "/arena" },
      // { label: "Minigames", href: "/minigames" },
      { label: "Flux Battle", href: "/scrapyard/flux" },
      { label: "Bagatelle", href: "/bagatelle" },
      { label: "Block Tower", href: "/scrap-yard/block-game" },
      { label: "Circular Tower", href: "/scrap-yard/block-tower-b" },
      { label: "Spell Caster", href: "/spell-caster" },
    ],
  },
  {
    id: "production",
    title: "Production",
    icon: "⚙️",
    items: [
      { label: "Crafting", href: "/crafting" },
      { label: "Incinerator", href: "/incinerator" },
      { label: "Shop", href: "/shop" },
      { label: "Bank", href: "/bank" },
      { label: "Inventory", href: "/inventory" },
    ],
  },
  {
    id: "progression",
    title: "Progression",
    icon: "📈",
    items: [
      { label: "CiruTree", href: "/cirutree" },
      { label: "Achievements", href: "/achievements" },
      { label: "XP Allocation", href: "/xp-allocation" },
      { label: "My Meks", href: "/profile" },
      { label: "Search", href: "/search" },
      { label: "Leaderboard", href: "/leaderboard" },
    ],
  },
];

const adminCategory: NavCategory = {
  id: "admin",
  title: "Admin",
  icon: "⚡",
  items: [
    { label: "Save System", href: "/admin-save" },
    // { label: "Mek Assignment", href: "/mek-assignment" },
    { label: "Mek Selector", href: "/mek-selector" },
    { label: "Mek Selector Grid", href: "/mek-selector-grid" },
    { label: "Mek Selector B", href: "/mek-selector-b" },
    // { label: "Mek Swarm", href: "/mek-swarm" },
    { label: "Shop Manager", href: "/admin-shop" },
    // { label: "Balance", href: "/balance" },
    { label: "Rarity Bias", href: "/rarity-bias" },
    { label: "Talent Builder", href: "/talent-builder" },
  ],
};

export default function Navigation() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [expandedAdmin, setExpandedAdmin] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);
  const adminRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);
  const { soundEnabled, toggleSound, playClickSound } = useSound();

  const toggleCategory = (categoryId: string) => {
    playClickSound();
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
  };

  // Handle mounting
  useEffect(() => {
    setMounted(true);
  }, []);

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setExpandedCategory(null);
      }
      if (adminRef.current && !adminRef.current.contains(event.target as Node)) {
        setExpandedAdmin(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div>
      {/* Navigation Layout */}
      <div className="flex flex-col items-center mb-4">
        {/* Logo with padding */}
        <Link href="/hub" className="group mb-6 mt-4">
          <Image
            src="/logo-big.png"
            alt="Mek Tycoon Logo"
            width={250}
            height={60}
            className="object-contain h-[60px] w-auto drop-shadow-[0_0_5px_rgba(250,182,23,0.5)] group-hover:drop-shadow-[0_0_7.5px_rgba(250,182,23,0.8)] transition-all"
            priority
          />
        </Link>
        
        {/* Industrial Navigation Panel */}
        <div className="relative mb-4">
          {/* Metal Panel Background */}
          <div className="absolute inset-0 bg-gradient-to-b from-zinc-800 via-zinc-900 to-black rounded-sm border border-zinc-600 shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)]" />
          
          {/* Grid Pattern Overlay */}
          <div 
            className="absolute inset-0 opacity-10 rounded-sm"
            style={{
              backgroundImage: `
                repeating-linear-gradient(0deg, transparent, transparent 19px, rgba(250,182,23,0.1) 20px),
                repeating-linear-gradient(90deg, transparent, transparent 19px, rgba(250,182,23,0.1) 20px)
              `
            }}
          />
          
          {/* Corner Screws */}
          <div className="absolute top-1 left-1 w-2 h-2 bg-zinc-600 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
          <div className="absolute top-1 right-1 w-2 h-2 bg-zinc-600 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
          <div className="absolute bottom-1 left-1 w-2 h-2 bg-zinc-600 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
          <div className="absolute bottom-1 right-1 w-2 h-2 bg-zinc-600 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
          
          {/* 4 Menu Buttons in Industrial Style */}
          <div className="relative flex items-center gap-1 p-3" ref={navRef}>
            {/* Operations Button */}
            <div className="relative">
              <button
                onClick={() => toggleCategory('operations')}
                className={`relative px-5 py-2.5 transition-all ${
                  expandedCategory === 'operations' ? 'translate-y-0.5' : 'hover:-translate-y-0.5'
                }`}
              >
                {/* Button Base */}
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-700 to-zinc-800 border border-zinc-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_2px_4px_rgba(0,0,0,0.5)]" />
                
                {/* Active LED Indicator */}
                <div className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full transition-all ${
                  expandedCategory === 'operations' 
                    ? 'bg-yellow-400 shadow-[0_0_6px_rgba(250,182,23,0.8)]' 
                    : 'bg-zinc-600'
                }`} />
                
                {/* Text Content */}
                <div className="relative flex items-center gap-2">
                  <span className="text-zinc-300 text-[10px] font-mono uppercase tracking-widest">
                    OPS
                  </span>
                  <div className="w-px h-3 bg-zinc-600" />
                  <span className={`text-[8px] transition-transform ${expandedCategory === 'operations' ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </div>
              </button>
              {mounted && (
                <div
                  className={`absolute top-full left-0 mt-2 min-w-[140px] transition-all z-50 ${
                    expandedCategory === 'operations'
                      ? "opacity-100 visible translate-y-0 pointer-events-auto"
                      : "opacity-0 invisible -translate-y-2 pointer-events-none"
                  }`}
                >
                  {/* Industrial Dropdown Panel */}
                  <div className="relative bg-gradient-to-b from-zinc-800 to-zinc-900 border border-zinc-600 shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
                    {/* Tech Pattern */}
                    <div className="absolute inset-0 opacity-5" style={{
                      backgroundImage: `linear-gradient(45deg, transparent 48%, rgba(250,182,23,0.1) 49%, rgba(250,182,23,0.1) 51%, transparent 52%)`
                    }} />
                    
                    <div className="p-1.5">
                      {navCategories[0].items.map((item, index) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="group block"
                          onClick={() => {
                            playClickSound();
                            setExpandedCategory(null);
                          }}
                        >
                          <div className="relative px-3 py-1.5 mb-0.5 bg-gradient-to-r from-zinc-700 to-zinc-800 border border-zinc-600 hover:border-zinc-500 transition-all overflow-hidden">
                            {/* Hover Glow */}
                            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent" />
                            
                            {/* LED Indicator */}
                            <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1 h-1 bg-zinc-600 group-hover:bg-yellow-400 transition-colors rounded-full group-hover:shadow-[0_0_4px_rgba(250,182,23,0.6)]" />
                            
                            <span className="relative z-10 text-zinc-300 group-hover:text-zinc-100 text-[10px] font-mono uppercase tracking-wider ml-2">
                              {item.label}
                            </span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Scrap Yard Button */}
            <div className="relative">
              <button
                onClick={() => toggleCategory('scrapyard')}
                className={`relative px-5 py-2.5 transition-all ${
                  expandedCategory === 'scrapyard' ? 'translate-y-0.5' : 'hover:-translate-y-0.5'
                }`}
              >
                {/* Button Base */}
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-700 to-zinc-800 border border-zinc-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_2px_4px_rgba(0,0,0,0.5)]" />
                
                {/* Active LED Indicator */}
                <div className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full transition-all ${
                  expandedCategory === 'scrapyard' 
                    ? 'bg-yellow-400 shadow-[0_0_6px_rgba(250,182,23,0.8)]' 
                    : 'bg-zinc-600'
                }`} />
                
                {/* Text Content */}
                <div className="relative flex items-center gap-2">
                  <span className="text-zinc-300 text-[10px] font-mono uppercase tracking-widest">
                    SCRAP
                  </span>
                  <div className="w-px h-3 bg-zinc-600" />
                  <span className={`text-[8px] transition-transform ${expandedCategory === 'scrapyard' ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </div>
              </button>
              {mounted && (
                <div
                  className={`absolute top-full left-0 mt-2 min-w-[140px] transition-all z-50 ${
                    expandedCategory === 'scrapyard'
                      ? "opacity-100 visible translate-y-0 pointer-events-auto"
                      : "opacity-0 invisible -translate-y-2 pointer-events-none"
                  }`}
                >
                  {/* Industrial Dropdown Panel */}
                  <div className="relative bg-gradient-to-b from-zinc-800 to-zinc-900 border border-zinc-600 shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
                    {/* Tech Pattern */}
                    <div className="absolute inset-0 opacity-5" style={{
                      backgroundImage: `linear-gradient(45deg, transparent 48%, rgba(250,182,23,0.1) 49%, rgba(250,182,23,0.1) 51%, transparent 52%)`
                    }} />
                    
                    <div className="p-1.5">
                      {navCategories[1].items.map((item, index) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="group block"
                          onClick={() => {
                            playClickSound();
                            setExpandedCategory(null);
                          }}
                        >
                          <div className="relative px-3 py-1.5 mb-0.5 bg-gradient-to-r from-zinc-700 to-zinc-800 border border-zinc-600 hover:border-zinc-500 transition-all overflow-hidden">
                            {/* Hover Glow */}
                            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent" />
                            
                            {/* LED Indicator */}
                            <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1 h-1 bg-zinc-600 group-hover:bg-yellow-400 transition-colors rounded-full group-hover:shadow-[0_0_4px_rgba(250,182,23,0.6)]" />
                            
                            <span className="relative z-10 text-zinc-300 group-hover:text-zinc-100 text-[10px] font-mono uppercase tracking-wider ml-2">
                              {item.label}
                            </span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Production Button */}
            <div className="relative">
              <button
                onClick={() => toggleCategory('production')}
                className={`relative px-5 py-2.5 transition-all ${
                  expandedCategory === 'production' ? 'translate-y-0.5' : 'hover:-translate-y-0.5'
                }`}
              >
                {/* Button Base */}
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-700 to-zinc-800 border border-zinc-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_2px_4px_rgba(0,0,0,0.5)]" />
                
                {/* Active LED Indicator */}
                <div className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full transition-all ${
                  expandedCategory === 'production' 
                    ? 'bg-yellow-400 shadow-[0_0_6px_rgba(250,182,23,0.8)]' 
                    : 'bg-zinc-600'
                }`} />
                
                {/* Text Content */}
                <div className="relative flex items-center gap-2">
                  <span className="text-zinc-300 text-[10px] font-mono uppercase tracking-widest">
                    PROD
                  </span>
                  <div className="w-px h-3 bg-zinc-600" />
                  <span className={`text-[8px] transition-transform ${expandedCategory === 'production' ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </div>
              </button>
              {mounted && (
                <div
                  className={`absolute top-full left-0 mt-2 min-w-[140px] transition-all z-50 ${
                    expandedCategory === 'production'
                      ? "opacity-100 visible translate-y-0 pointer-events-auto"
                      : "opacity-0 invisible -translate-y-2 pointer-events-none"
                  }`}
                >
                  {/* Industrial Dropdown Panel */}
                  <div className="relative bg-gradient-to-b from-zinc-800 to-zinc-900 border border-zinc-600 shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
                    {/* Tech Pattern */}
                    <div className="absolute inset-0 opacity-5" style={{
                      backgroundImage: `linear-gradient(45deg, transparent 48%, rgba(250,182,23,0.1) 49%, rgba(250,182,23,0.1) 51%, transparent 52%)`
                    }} />
                    
                    <div className="p-1.5">
                      {navCategories[2].items.map((item, index) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="group block"
                          onClick={() => {
                            playClickSound();
                            setExpandedCategory(null);
                          }}
                        >
                          <div className="relative px-3 py-1.5 mb-0.5 bg-gradient-to-r from-zinc-700 to-zinc-800 border border-zinc-600 hover:border-zinc-500 transition-all overflow-hidden">
                            {/* Hover Glow */}
                            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent" />
                            
                            {/* LED Indicator */}
                            <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1 h-1 bg-zinc-600 group-hover:bg-yellow-400 transition-colors rounded-full group-hover:shadow-[0_0_4px_rgba(250,182,23,0.6)]" />
                            
                            <span className="relative z-10 text-zinc-300 group-hover:text-zinc-100 text-[10px] font-mono uppercase tracking-wider ml-2">
                              {item.label}
                            </span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Progression Button */}
            <div className="relative">
              <button
                onClick={() => toggleCategory('progression')}
                className={`relative px-5 py-2.5 transition-all ${
                  expandedCategory === 'progression' ? 'translate-y-0.5' : 'hover:-translate-y-0.5'
                }`}
              >
                {/* Button Base */}
                <div className="absolute inset-0 bg-gradient-to-b from-zinc-700 to-zinc-800 border border-zinc-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_2px_4px_rgba(0,0,0,0.5)]" />
                
                {/* Active LED Indicator */}
                <div className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full transition-all ${
                  expandedCategory === 'progression' 
                    ? 'bg-yellow-400 shadow-[0_0_6px_rgba(250,182,23,0.8)]' 
                    : 'bg-zinc-600'
                }`} />
                
                {/* Text Content */}
                <div className="relative flex items-center gap-2">
                  <span className="text-zinc-300 text-[10px] font-mono uppercase tracking-widest">
                    PROG
                  </span>
                  <div className="w-px h-3 bg-zinc-600" />
                  <span className={`text-[8px] transition-transform ${expandedCategory === 'progression' ? "rotate-180" : ""}`}>
                    ▼
                  </span>
                </div>
              </button>
              {mounted && (
                <div
                  className={`absolute top-full right-0 mt-2 min-w-[140px] transition-all z-50 ${
                    expandedCategory === 'progression'
                      ? "opacity-100 visible translate-y-0 pointer-events-auto"
                      : "opacity-0 invisible -translate-y-2 pointer-events-none"
                  }`}
                >
                  {/* Industrial Dropdown Panel */}
                  <div className="relative bg-gradient-to-b from-zinc-800 to-zinc-900 border border-zinc-600 shadow-[0_4px_16px_rgba(0,0,0,0.8)]">
                    {/* Tech Pattern */}
                    <div className="absolute inset-0 opacity-5" style={{
                      backgroundImage: `linear-gradient(45deg, transparent 48%, rgba(250,182,23,0.1) 49%, rgba(250,182,23,0.1) 51%, transparent 52%)`
                    }} />
                    
                    <div className="p-1.5">
                      {navCategories[3].items.map((item, index) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="group block"
                          onClick={() => {
                            playClickSound();
                            setExpandedCategory(null);
                          }}
                        >
                          <div className="relative px-3 py-1.5 mb-0.5 bg-gradient-to-r from-zinc-700 to-zinc-800 border border-zinc-600 hover:border-zinc-500 transition-all overflow-hidden">
                            {/* Hover Glow */}
                            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent" />
                            
                            {/* LED Indicator */}
                            <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-1 h-1 bg-zinc-600 group-hover:bg-yellow-400 transition-colors rounded-full group-hover:shadow-[0_0_4px_rgba(250,182,23,0.6)]" />
                            
                            <span className="relative z-10 text-zinc-300 group-hover:text-zinc-100 text-[10px] font-mono uppercase tracking-wider ml-2">
                              {item.label}
                            </span>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* HUB Button - Industrial Style */}
        <div className="flex justify-center">
          <Link
            href="/hub"
            onClick={playClickSound}
            className="group relative"
          >
            <div className="relative h-[45px] w-[120px] flex items-center justify-center transition-transform hover:scale-105">
              {/* Industrial Base */}
              <div className="absolute inset-0 bg-gradient-to-b from-zinc-700 via-zinc-800 to-zinc-900 border-2 border-yellow-400/80 shadow-[0_4px_8px_rgba(0,0,0,0.6),inset_0_1px_0_rgba(255,255,255,0.1)]" />
              
              {/* Corner Bolts */}
              <div className="absolute top-0.5 left-0.5 w-1.5 h-1.5 bg-yellow-400/60 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
              <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-yellow-400/60 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
              <div className="absolute bottom-0.5 left-0.5 w-1.5 h-1.5 bg-yellow-400/60 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
              <div className="absolute bottom-0.5 right-0.5 w-1.5 h-1.5 bg-yellow-400/60 rounded-full shadow-[inset_0_1px_2px_rgba(0,0,0,0.8)]" />
              
              {/* Hazard Stripes */}
              <div className="absolute inset-x-0 bottom-0 h-1 opacity-50" style={{
                background: `repeating-linear-gradient(45deg, #fab617 0px, #fab617 2px, #000 2px, #000 4px)`
              }} />
              
              {/* Power Indicator */}
              <div className="absolute top-2 right-2 w-2 h-2 bg-yellow-400 rounded-full shadow-[0_0_8px_rgba(250,182,23,0.8)] animate-pulse" />
              
              {/* Text */}
              <span className="relative z-10 text-yellow-400 font-mono font-bold text-base tracking-[0.2em] drop-shadow-[0_0_8px_rgba(250,182,23,0.6)]">HUB</span>
              
              {/* Scan Line Effect on Hover */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none overflow-hidden">
                <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-yellow-400/50 to-transparent animate-pulse" />
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Admin Dropdown in Upper Left */}
      <div className="absolute top-2 left-2 z-50" ref={adminRef}>
        <button
          onClick={() => {
            playClickSound();
            setExpandedAdmin(!expandedAdmin);
          }}
          className="px-2 py-1 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/30 rounded hover:border-yellow-400/50 transition-all flex items-center gap-1"
        >
          <span className="text-[10px]">⚡</span>
          <span className="text-yellow-400 text-[10px] font-semibold uppercase tracking-wider">Admin</span>
          <span className={`text-yellow-400 text-[8px] transition-transform ${expandedAdmin ? "rotate-180" : ""}`}>▼</span>
        </button>
        
        {mounted && (
          <div
            className={`absolute top-full left-0 mt-1 w-40 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400 rounded-lg shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition-all ${
              expandedAdmin
                ? "opacity-100 visible translate-y-0 pointer-events-auto"
                : "opacity-0 invisible -translate-y-2 pointer-events-none"
            }`}
          >
            <div className="p-2 grid grid-cols-1 gap-1">
              {adminCategory.items.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="relative px-2 py-1 bg-gradient-to-r from-gray-600 to-gray-700 border border-gray-600 text-white text-[10px] font-medium uppercase tracking-wider rounded hover:from-gray-700 hover:to-gray-800 hover:border-gray-500 transition-all overflow-hidden group"
                  onClick={() => {
                    playClickSound();
                    setExpandedAdmin(false);
                  }}
                >
                  <div className="absolute inset-0 -left-full group-hover:left-full transition-all duration-500 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent" />
                  <span className="relative z-10">{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Wallet Button in Upper Right */}
      <div className="absolute top-2 right-2 z-50">
        <button
          onClick={() => {
            playClickSound();
            // Clear wallet data from localStorage
            localStorage.removeItem('connectedWallet');
            localStorage.removeItem('walletAddress');
            localStorage.removeItem('stakeAddress');
            // Redirect to welcome page
            window.location.href = '/';
          }}
          className="px-2 py-1 bg-gradient-to-br from-gray-800 to-gray-900 border border-yellow-400/30 rounded hover:border-yellow-400/50 transition-all flex items-center gap-1"
        >
          <span className="text-yellow-400 text-[10px] font-semibold uppercase tracking-wider">Wallet</span>
        </button>
      </div>

      {/* Sound Toggle and Welcome Link Bottom Left */}
      <div className="absolute bottom-2 left-2 z-50 flex items-center gap-2">
        <button
          onClick={() => {
            playClickSound();
            toggleSound();
          }}
          className="text-gray-400 hover:text-yellow-400 text-sm transition-colors p-1"
          title={soundEnabled ? "Mute Sounds" : "Enable Sounds"}
        >
          {soundEnabled ? (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path>
            </svg>
          ) : (
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
              <line x1="23" y1="9" x2="17" y2="15"></line>
              <line x1="17" y1="9" x2="23" y2="15"></line>
            </svg>
          )}
        </button>
        <Link
          href="/"
          className="text-gray-500 hover:text-yellow-400 text-[10px] transition-colors"
          onClick={playClickSound}
        >
          ← Welcome
        </Link>
      </div>

    </div>
  );
}