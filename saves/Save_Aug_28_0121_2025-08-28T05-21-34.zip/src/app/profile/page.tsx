"use client";

import { useState } from "react";
import BackgroundEffects from "@/components/BackgroundEffects";
import MekImage from "@/components/MekImage";

type EssenceType = {
  type: string;
  amount: number;
  color: string;
};

type Equipment = {
  id: string;
  name: string;
  equipped: boolean;
  rarity: string;
  icon: string;
};

type Mek = {
  id: string;
  name: string;
  level: number;
  equipped: {
    head?: string;
    body?: string; 
    accessory?: string;
  };
};

type Frame = {
  id: string;
  name: string;
  rarity: string;
  unlocked: boolean;
  borderStyle: string;
};

type OfferModal = {
  type: 'essence' | 'equipment' | null;
  item?: EssenceType | Equipment;
};

type ActiveOffer = {
  id: string;
  type: 'essence' | 'equipment';
  item: EssenceType | Equipment;
  totalPaid: number;
  pricePerUnit?: number;
  quantity?: number;
  duration: number;
  expiresAt: Date;
  targetPlayer: string;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
};

const FRAMES: Frame[] = [
  { id: 'none', name: 'No Frame', rarity: 'common', unlocked: true, borderStyle: '' },
  { id: 'bronze', name: 'Bronze Frame', rarity: 'common', unlocked: true, borderStyle: 'border-4 border-amber-700' },
  { id: 'silver', name: 'Silver Frame', rarity: 'uncommon', unlocked: true, borderStyle: 'border-4 border-gray-400' },
  { id: 'gold', name: 'Gold Frame', rarity: 'rare', unlocked: true, borderStyle: 'border-4 border-yellow-500 shadow-[0_0_20px_rgba(250,204,21,0.5)]' },
  { id: 'diamond', name: 'Diamond Frame', rarity: 'epic', unlocked: false, borderStyle: 'border-4 border-cyan-400 shadow-[0_0_30px_rgba(34,211,238,0.6)]' },
  { id: 'animated', name: 'Plasma Frame', rarity: 'legendary', unlocked: false, borderStyle: 'border-4 border-gradient-to-r from-purple-500 via-pink-500 to-purple-500 animate-pulse' },
];

const OFFER_DURATIONS = [
  { hours: 24, label: '24 hours', fee: 0 },
  { hours: 48, label: '48 hours', fee: 0 },
  { hours: 72, label: '72 hours', fee: 0.05 },
  { hours: 96, label: '96 hours', fee: 0.07 },
];

export default function ProfilePage() {
  const [isOwnProfile, setIsOwnProfile] = useState(true);
  const [selectedAvatar, setSelectedAvatar] = useState('1234');
  const [selectedFrame, setSelectedFrame] = useState('gold');
  const [availableFrames, setAvailableFrames] = useState<string[]>(['none', 'bronze', 'silver', 'gold']); // User's unlocked frames
  const [showAvatarSelector, setShowAvatarSelector] = useState(false);
  const [showFrameSelector, setShowFrameSelector] = useState(false);
  const [offerModal, setOfferModal] = useState<OfferModal>({ type: null });
  const [activeOffers, setActiveOffers] = useState<ActiveOffer[]>([]);
  const [showActiveOffers, setShowActiveOffers] = useState(false);
  const [userGold, setUserGold] = useState(125420);
  
  // Offer form states
  const [offerAmount, setOfferAmount] = useState('');
  const [essenceQuantity, setEssenceQuantity] = useState('1');
  const [offerDuration, setOfferDuration] = useState(48);
  
  // Mock user data
  const userData = {
    username: isOwnProfile ? 'YourUsername' : 'OtherPlayer123',
    totalGold: userGold,
    totalEssence: 342,
    level: 42,
    joinDate: '2024-01-15',
    prestige: 0,
    wrenPiecesOwned: { head: false, body: false, trait: false },
    essences: [
      { type: 'Fire', amount: 85, color: '#ef4444' },
      { type: 'Water', amount: 120, color: '#3b82f6' },
      { type: 'Earth', amount: 67, color: '#84cc16' },
      { type: 'Air', amount: 45, color: '#06b6d4' },
      { type: 'Dark', amount: 25, color: '#7c3aed' },
    ],
    equipment: [
      { id: 'sword1', name: 'Flame Sword', equipped: true, rarity: 'epic', icon: '🗡️' },
      { id: 'armor1', name: 'Dragon Scale Armor', equipped: false, rarity: 'legendary', icon: '🛡️' },
      { id: 'ring1', name: 'Ring of Power', equipped: true, rarity: 'rare', icon: '💍' },
      { id: 'boots1', name: 'Speed Boots', equipped: false, rarity: 'uncommon', icon: '👢' },
      { id: 'helm1', name: 'Crystal Helm', equipped: true, rarity: 'epic', icon: '⛑️' },
    ],
    meks: [
      { id: '1234', name: 'Mek #1234', level: 8, equipped: { head: '🎩', body: '🎮', accessory: '💎' } },
      { id: '5678', name: 'Mek #5678', level: 10, equipped: { head: '👑', body: '⚔️' } },
      { id: '9012', name: 'Mek #9012', level: 5, equipped: {} },
      { id: '3456', name: 'Mek #3456', level: 7, equipped: { accessory: '🔮' } },
      { id: '7890', name: 'Mek #7890', level: 10, equipped: { head: '🎭', body: '🛡️', accessory: '⭐' } },
    ]
  };

  const currentFrame = FRAMES.find(f => f.id === selectedFrame) || FRAMES[0];

  const handleMakeOffer = () => {
    if (offerModal.type === 'essence' && offerModal.item) {
      const essenceItem = offerModal.item as EssenceType;
      const pricePerEssence = parseFloat(offerAmount) || 0;
      const quantity = parseInt(essenceQuantity) || 0;
      const totalCost = pricePerEssence * quantity;
      const duration = OFFER_DURATIONS.find(d => d.hours === offerDuration)!;
      const fee = totalCost * duration.fee;
      const finalCost = totalCost + fee;
      
      if (finalCost > userGold) {
        alert(`Insufficient gold! You need ${finalCost.toLocaleString()} gold but only have ${userGold.toLocaleString()}.`);
        return;
      }
      
      // Deduct gold immediately
      setUserGold(prev => prev - finalCost);
      
      // Create the offer
      const newOffer: ActiveOffer = {
        id: `offer_${Date.now()}`,
        type: 'essence',
        item: essenceItem,
        totalPaid: finalCost,
        pricePerUnit: pricePerEssence,
        quantity,
        duration: duration.hours,
        expiresAt: new Date(Date.now() + duration.hours * 60 * 60 * 1000),
        targetPlayer: userData.username,
        status: 'pending'
      };
      
      setActiveOffers(prev => [...prev, newOffer]);
      
    } else if (offerModal.type === 'equipment' && offerModal.item) {
      const equipment = offerModal.item as Equipment;
      const offerPrice = parseFloat(offerAmount) || 0;
      const duration = OFFER_DURATIONS.find(d => d.hours === offerDuration)!;
      const fee = offerPrice * duration.fee;
      const finalCost = offerPrice + fee;
      
      if (finalCost > userGold) {
        alert(`Insufficient gold! You need ${finalCost.toLocaleString()} gold but only have ${userGold.toLocaleString()}.`);
        return;
      }
      
      // Deduct gold immediately
      setUserGold(prev => prev - finalCost);
      
      // Create the offer
      const newOffer: ActiveOffer = {
        id: `offer_${Date.now()}`,
        type: 'equipment',
        item: equipment,
        totalPaid: finalCost,
        duration: duration.hours,
        expiresAt: new Date(Date.now() + duration.hours * 60 * 60 * 1000),
        targetPlayer: userData.username,
        status: 'pending'
      };
      
      setActiveOffers(prev => [...prev, newOffer]);
    }
    
    setOfferModal({ type: null });
    setOfferAmount('');
    setEssenceQuantity('1');
  };
  
  // Function to handle offer expiration/cancellation
  const handleOfferExpired = (offerId: string) => {
    const offer = activeOffers.find(o => o.id === offerId);
    if (offer && offer.status === 'pending') {
      // Refund the gold
      setUserGold(prev => prev + offer.totalPaid);
      // Update offer status
      setActiveOffers(prev => 
        prev.map(o => o.id === offerId ? {...o, status: 'expired'} : o)
      );
    }
  };
  
  const cancelOffer = (offerId: string) => {
    const offer = activeOffers.find(o => o.id === offerId);
    if (offer && offer.status === 'pending') {
      // Refund the gold
      setUserGold(prev => prev + offer.totalPaid);
      // Remove the offer
      setActiveOffers(prev => prev.filter(o => o.id !== offerId));
    }
  };

  return (
    <div className="min-h-screen p-5 relative text-white">
      <BackgroundEffects />
      
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Dev Toggle and Active Offers */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3 bg-gray-900/60 backdrop-blur-sm border border-gray-700 rounded-lg px-4 py-2">
            <span className="text-sm text-gray-400">View as:</span>
            <button
              onClick={() => setIsOwnProfile(true)}
              className={`px-3 py-1 rounded text-sm transition-all ${
                isOwnProfile
                  ? 'bg-yellow-500 text-black font-bold'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Own Profile
            </button>
            <button
              onClick={() => setIsOwnProfile(false)}
              className={`px-3 py-1 rounded text-sm transition-all ${
                !isOwnProfile
                  ? 'bg-yellow-500 text-black font-bold'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Other Player
            </button>
          </div>
          
          {/* Active Offers Button */}
          {isOwnProfile && (
            <button
              onClick={() => setShowActiveOffers(true)}
              className="relative px-4 py-2 bg-gray-900/60 backdrop-blur-sm border border-gray-700 rounded-lg hover:border-gray-600 transition-all"
            >
              <span className="text-sm text-gray-300">Active Offers</span>
              {activeOffers.filter(o => o.status === 'pending').length > 0 && (
                <span className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {activeOffers.filter(o => o.status === 'pending').length}
                </span>
              )}
            </button>
          )}
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Left Column - Profile Avatar & Basic Info */}
          <div className="col-span-3">
            <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-lg p-6">
              {/* Avatar with Frame */}
              <div className="relative mb-6">
                <div className={`relative rounded-lg overflow-hidden ${currentFrame.borderStyle}`}>
                  <div className="w-full aspect-square bg-gray-800 relative">
                    <MekImage
                      assetId={selectedAvatar}
                      size={280}
                      alt="Profile Avatar"
                      className="w-full h-full object-cover"
                    />
                    
                    {/* Edit Avatar Button (own profile only) */}
                    {isOwnProfile && (
                      <button
                        onClick={() => setShowAvatarSelector(true)}
                        className="absolute bottom-2 right-2 bg-black/80 hover:bg-black/90 text-white px-3 py-1 rounded text-xs font-bold transition-all"
                      >
                        Edit Avatar
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Frame Selector Button (own profile only) */}
                {isOwnProfile && (
                  <button
                    onClick={() => setShowFrameSelector(true)}
                    className="absolute -top-2 -right-2 bg-yellow-500 hover:bg-yellow-400 text-black p-2 rounded-full transition-all transform hover:scale-110"
                    title="Change Frame"
                  >
                    🖼️
                  </button>
                )}
              </div>
              
              {/* Username & Basic Stats */}
              <div className="text-center mb-4">
                <h1 className="text-2xl font-bold text-yellow-400 mb-1">{userData.username}</h1>
                <div className="text-sm text-gray-400">Level {userData.level}</div>
                {/* Prestige Display */}
                <div className="flex items-center justify-center gap-2 mt-2">
                  <div className="text-purple-400 font-bold">
                    Prestige {userData.prestige || 0}
                  </div>
                  {(userData.prestige || 0) > 0 && (
                    <div className="flex">
                      {[...Array(Math.min(userData.prestige || 0, 5))].map((_, i) => (
                        <span key={i} className="text-purple-400">⭐</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-xs text-gray-500 mt-1">Joined {userData.joinDate}</div>
              </div>
              
              {/* Quick Stats */}
              <div className="space-y-2 pt-4 border-t border-gray-700">
                <div className="flex justify-between">
                  <span className="text-gray-400 text-sm">Total Gold</span>
                  <span className="text-yellow-400 font-bold">{userData.totalGold.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400 text-sm">Total Essence</span>
                  <span className="text-purple-400 font-bold">{userData.totalEssence}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400 text-sm">Meks Owned</span>
                  <span className="text-cyan-400 font-bold">{userData.meks.length}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Middle Column - Meks Collection */}
          <div className="col-span-5">
            <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4 text-yellow-400">Mek Collection</h2>
              
              <div className="grid grid-cols-3 gap-3">
                {userData.meks.map(mek => (
                  <div
                    key={mek.id}
                    className="bg-gray-800/50 border border-gray-700 rounded-lg p-3 hover:border-gray-600 transition-all"
                  >
                    {/* Mek Image */}
                    <div className="relative mb-2">
                      <MekImage
                        assetId={mek.id}
                        size={100}
                        alt={mek.name}
                        className="w-full rounded"
                      />
                      {/* Level Badge */}
                      <div className="absolute bottom-1 right-1 bg-black/80 px-2 py-0.5 rounded text-xs font-bold text-yellow-400">
                        Lv.{mek.level}
                      </div>
                    </div>
                    
                    {/* Mek Name */}
                    <div className="text-sm font-medium text-gray-300 mb-1 truncate">{mek.name}</div>
                    
                    {/* Equipment Indicators */}
                    <div className="flex gap-1 justify-center">
                      <div className={`w-6 h-6 rounded flex items-center justify-center text-xs ${
                        mek.equipped.head ? 'bg-green-900/50 border border-green-600' : 'bg-gray-900 border border-gray-700'
                      }`}>
                        {mek.equipped.head || '•'}
                      </div>
                      <div className={`w-6 h-6 rounded flex items-center justify-center text-xs ${
                        mek.equipped.body ? 'bg-green-900/50 border border-green-600' : 'bg-gray-900 border border-gray-700'
                      }`}>
                        {mek.equipped.body || '•'}
                      </div>
                      <div className={`w-6 h-6 rounded flex items-center justify-center text-xs ${
                        mek.equipped.accessory ? 'bg-green-900/50 border border-green-600' : 'bg-gray-900 border border-gray-700'
                      }`}>
                        {mek.equipped.accessory || '•'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Equipment Section */}
            <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-lg p-6 mt-4">
              <h2 className="text-xl font-bold mb-4 text-yellow-400">Equipment</h2>
              
              <div className="grid grid-cols-2 gap-3">
                {userData.equipment.map(item => (
                  <div
                    key={item.id}
                    className={`flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer hover:shadow-lg ${
                      item.equipped
                        ? 'bg-green-900/20 border-green-600'
                        : 'bg-gray-800/50 border-gray-700 hover:border-gray-600'
                    }`}
                    onClick={() => !isOwnProfile && !item.equipped && setOfferModal({ type: 'equipment', item })}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      <div>
                        <div className="text-sm font-medium text-gray-200">{item.name}</div>
                        <div className={`text-xs ${
                          item.rarity === 'legendary' ? 'text-orange-400' :
                          item.rarity === 'epic' ? 'text-purple-400' :
                          item.rarity === 'rare' ? 'text-blue-400' :
                          item.rarity === 'uncommon' ? 'text-green-400' :
                          'text-gray-400'
                        }`}>{item.rarity}</div>
                      </div>
                    </div>
                    {item.equipped && (
                      <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">Equipped</span>
                    )}
                    {!isOwnProfile && !item.equipped && (
                      <span className="text-xs text-gray-400">Click to offer</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Essences */}
          <div className="col-span-4">
            <div className="bg-gray-900/60 backdrop-blur-sm border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4 text-yellow-400">Essence Collection</h2>
              
              <div className="space-y-4">
                {userData.essences.map(essence => (
                  <div
                    key={essence.type}
                    className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 hover:border-gray-600 transition-all cursor-pointer"
                    onClick={() => !isOwnProfile && setOfferModal({ type: 'essence', item: essence })}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {/* Essence Bottle Icon */}
                        <div className="relative w-12 h-16">
                          <div
                            className="absolute inset-0 rounded-full blur-md opacity-50"
                            style={{ backgroundColor: essence.color }}
                          />
                          <div className="relative bg-gray-900/80 rounded-t-sm rounded-b-full w-12 h-16 border-2 border-gray-600 flex items-center justify-center">
                            <div
                              className="w-8 h-10 rounded-b-full"
                              style={{
                                background: `linear-gradient(to bottom, ${essence.color}40, ${essence.color})`,
                              }}
                            />
                          </div>
                        </div>
                        
                        {/* Essence Info */}
                        <div>
                          <div className="font-medium" style={{ color: essence.color }}>
                            {essence.type} Essence
                          </div>
                          <div className="text-sm text-gray-400">
                            {essence.amount} units
                          </div>
                        </div>
                      </div>
                      
                      {!isOwnProfile && (
                        <button className="text-xs bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded transition-all">
                          Make Offer
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Total Essence Summary */}
              <div className="mt-6 pt-4 border-t border-gray-700">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Total Essence</span>
                  <span className="text-2xl font-bold text-purple-400">{userData.totalEssence}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Avatar Selector Modal */}
        {showAvatarSelector && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-3xl w-full max-h-[80vh] overflow-y-auto">
              <h3 className="text-xl font-bold text-yellow-400 mb-4">Select Profile Avatar</h3>
              <div className="grid grid-cols-5 gap-3">
                {userData.meks.map(mek => (
                  <button
                    key={mek.id}
                    onClick={() => {
                      setSelectedAvatar(mek.id);
                      setShowAvatarSelector(false);
                    }}
                    className={`border-2 rounded-lg p-2 transition-all ${
                      selectedAvatar === mek.id
                        ? 'border-yellow-500 bg-yellow-500/20'
                        : 'border-gray-700 hover:border-gray-600'
                    }`}
                  >
                    <MekImage
                      assetId={mek.id}
                      size={100}
                      alt={mek.name}
                      className="w-full rounded"
                    />
                    <div className="text-xs mt-1 text-gray-400">{mek.name}</div>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowAvatarSelector(false)}
                className="mt-4 w-full px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Frame Selector Modal */}
        {showFrameSelector && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-2xl w-full">
              <h3 className="text-xl font-bold text-yellow-400 mb-4">Select Profile Frame</h3>
              <div className="grid grid-cols-3 gap-3">
                {FRAMES.map(frame => (
                  <button
                    key={frame.id}
                    onClick={() => {
                      if (frame.unlocked) {
                        setSelectedFrame(frame.id);
                        setShowFrameSelector(false);
                      }
                    }}
                    disabled={!frame.unlocked}
                    className={`relative border-2 rounded-lg p-4 transition-all ${
                      selectedFrame === frame.id
                        ? 'border-yellow-500 bg-yellow-500/20'
                        : frame.unlocked
                        ? 'border-gray-700 hover:border-gray-600'
                        : 'border-gray-800 bg-gray-900/50 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <div className={`w-20 h-20 mx-auto rounded ${frame.borderStyle} bg-gray-800`} />
                    <div className="text-sm mt-2 font-medium">{frame.name}</div>
                    <div className={`text-xs ${
                      frame.rarity === 'legendary' ? 'text-orange-400' :
                      frame.rarity === 'epic' ? 'text-purple-400' :
                      frame.rarity === 'rare' ? 'text-blue-400' :
                      frame.rarity === 'uncommon' ? 'text-green-400' :
                      'text-gray-400'
                    }`}>{frame.rarity}</div>
                    {!frame.unlocked && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/60 rounded-lg">
                        <span className="text-red-400 font-bold">LOCKED</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowFrameSelector(false)}
                className="mt-4 w-full px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded transition-all"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Offer Modal */}
        {offerModal.type && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-md w-full">
              <h3 className="text-xl font-bold text-yellow-400 mb-4">
                Make Offer - {offerModal.type === 'essence' ? 'Essence' : 'Equipment'}
              </h3>
              
              {offerModal.type === 'essence' && offerModal.item && (
                <div className="space-y-4">
                  <div className="bg-gray-800 rounded-lg p-3">
                    <div className="text-sm text-gray-400 mb-1">Offering on:</div>
                    <div className="font-medium" style={{ color: (offerModal.item as EssenceType).color }}>
                      {(offerModal.item as EssenceType).type} Essence
                    </div>
                    <div className="text-xs text-gray-500">
                      Available: {(offerModal.item as EssenceType).amount} units
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Gold per Essence</label>
                    <input
                      type="number"
                      value={offerAmount}
                      onChange={(e) => setOfferAmount(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="Enter price per essence"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Quantity</label>
                    <input
                      type="number"
                      value={essenceQuantity}
                      onChange={(e) => setEssenceQuantity(e.target.value)}
                      max={(offerModal.item as EssenceType).amount}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="Number of essence"
                    />
                  </div>
                </div>
              )}
              
              {offerModal.type === 'equipment' && offerModal.item && (
                <div className="space-y-4">
                  <div className="bg-gray-800 rounded-lg p-3">
                    <div className="text-sm text-gray-400 mb-1">Offering on:</div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{(offerModal.item as Equipment).icon}</span>
                      <div>
                        <div className="font-medium">{(offerModal.item as Equipment).name}</div>
                        <div className={`text-xs ${
                          (offerModal.item as Equipment).rarity === 'legendary' ? 'text-orange-400' :
                          (offerModal.item as Equipment).rarity === 'epic' ? 'text-purple-400' :
                          (offerModal.item as Equipment).rarity === 'rare' ? 'text-blue-400' :
                          (offerModal.item as Equipment).rarity === 'uncommon' ? 'text-green-400' :
                          'text-gray-400'
                        }`}>{(offerModal.item as Equipment).rarity}</div>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-1">Offer Amount (Gold)</label>
                    <input
                      type="number"
                      value={offerAmount}
                      onChange={(e) => setOfferAmount(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="Enter offer amount"
                    />
                  </div>
                </div>
              )}
              
              <div className="mt-4">
                <label className="block text-sm text-gray-400 mb-1">Offer Duration</label>
                <select
                  value={offerDuration}
                  onChange={(e) => setOfferDuration(parseInt(e.target.value))}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                >
                  {OFFER_DURATIONS.map(duration => (
                    <option key={duration.hours} value={duration.hours}>
                      {duration.label} {duration.fee > 0 ? `(${duration.fee * 100}% fee)` : '(free)'}
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Total Cost Display */}
              <div className="mt-4 p-3 bg-gray-800 rounded-lg">
                {offerModal.type === 'essence' && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Subtotal:</span>
                      <span className="text-white">
                        {((parseFloat(offerAmount) || 0) * (parseInt(essenceQuantity) || 0)).toLocaleString()} gold
                      </span>
                    </div>
                    {OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee > 0 && (
                      <div className="flex justify-between text-sm mt-1">
                        <span className="text-gray-400">Fee ({(OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee * 100)}%):</span>
                        <span className="text-yellow-400">
                          {(((parseFloat(offerAmount) || 0) * (parseInt(essenceQuantity) || 0)) * OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee).toLocaleString()} gold
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold mt-2 pt-2 border-t border-gray-700">
                      <span className="text-gray-300">Total:</span>
                      <span className="text-yellow-400">
                        {(((parseFloat(offerAmount) || 0) * (parseInt(essenceQuantity) || 0)) * (1 + OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee)).toLocaleString()} gold
                      </span>
                    </div>
                  </>
                )}
                {offerModal.type === 'equipment' && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Offer:</span>
                      <span className="text-white">
                        {(parseFloat(offerAmount) || 0).toLocaleString()} gold
                      </span>
                    </div>
                    {OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee > 0 && (
                      <div className="flex justify-between text-sm mt-1">
                        <span className="text-gray-400">Fee ({(OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee * 100)}%):</span>
                        <span className="text-yellow-400">
                          {((parseFloat(offerAmount) || 0) * OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee).toLocaleString()} gold
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold mt-2 pt-2 border-t border-gray-700">
                      <span className="text-gray-300">Total:</span>
                      <span className="text-yellow-400">
                        {((parseFloat(offerAmount) || 0) * (1 + OFFER_DURATIONS.find(d => d.hours === offerDuration)!.fee)).toLocaleString()} gold
                      </span>
                    </div>
                  </>
                )}
                
                {/* Current Gold Display */}
                <div className="mt-3 text-xs text-gray-500">
                  Your Gold: {userGold.toLocaleString()}
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleMakeOffer}
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold rounded hover:from-yellow-400 hover:to-yellow-500 transition-all"
                >
                  Submit Offer
                </button>
                <button
                  onClick={() => {
                    setOfferModal({ type: null });
                    setOfferAmount('');
                    setEssenceQuantity('1');
                  }}
                  className="flex-1 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Active Offers Modal */}
        {showActiveOffers && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-6 max-w-4xl w-full max-h-[80vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-yellow-400">Your Active Offers</h3>
                <button
                  onClick={() => setShowActiveOffers(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>
              
              {activeOffers.filter(o => o.status === 'pending').length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No active offers at the moment
                </div>
              ) : (
                <div className="space-y-3">
                  {activeOffers.filter(o => o.status === 'pending').map(offer => (
                    <div
                      key={offer.id}
                      className="bg-gray-800/50 border border-gray-700 rounded-lg p-4"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-sm font-bold text-gray-300">
                              {offer.type === 'essence' ? 'Essence Offer' : 'Equipment Offer'}
                            </span>
                            <span className="text-xs text-gray-500">
                              To: {offer.targetPlayer}
                            </span>
                          </div>
                          
                          {offer.type === 'essence' ? (
                            <div className="text-sm text-gray-400">
                              <span style={{ color: (offer.item as EssenceType).color }}>
                                {(offer.item as EssenceType).type} Essence
                              </span>
                              {' - '}
                              {offer.quantity} units @ {offer.pricePerUnit} gold each
                            </div>
                          ) : (
                            <div className="text-sm text-gray-400">
                              {(offer.item as Equipment).icon} {(offer.item as Equipment).name}
                            </div>
                          )}
                          
                          <div className="flex items-center gap-4 mt-2">
                            <div className="text-xs text-gray-500">
                              Expires: {new Date(offer.expiresAt).toLocaleString()}
                            </div>
                            <div className="text-sm font-bold text-yellow-400">
                              {offer.totalPaid.toLocaleString()} gold
                            </div>
                          </div>
                        </div>
                        
                        <button
                          onClick={() => cancelOffer(offer.id)}
                          className="px-3 py-1 bg-red-900/50 hover:bg-red-800/50 text-red-400 text-xs rounded transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {activeOffers.filter(o => o.status !== 'pending').length > 0 && (
                <>
                  <h4 className="text-lg font-bold text-gray-400 mt-6 mb-3">History</h4>
                  <div className="space-y-2 opacity-60">
                    {activeOffers.filter(o => o.status !== 'pending').map(offer => (
                      <div
                        key={offer.id}
                        className="bg-gray-900/50 border border-gray-800 rounded-lg p-3 text-sm"
                      >
                        <div className="flex justify-between items-center">
                          <div className="text-gray-500">
                            {offer.type === 'essence' 
                              ? `${(offer.item as EssenceType).type} Essence` 
                              : (offer.item as Equipment).name}
                          </div>
                          <div className="flex items-center gap-3">
                            <span className={`text-xs px-2 py-1 rounded ${
                              offer.status === 'accepted' ? 'bg-green-900/50 text-green-400' :
                              offer.status === 'declined' ? 'bg-red-900/50 text-red-400' :
                              'bg-gray-800 text-gray-500'
                            }`}>
                              {offer.status}
                            </span>
                            <span className="text-gray-600">
                              {offer.totalPaid.toLocaleString()} gold
                              {offer.status === 'expired' || offer.status === 'declined' ? ' (refunded)' : ''}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}