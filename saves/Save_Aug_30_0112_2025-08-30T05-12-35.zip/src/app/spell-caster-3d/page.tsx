'use client';

import dynamic from 'next/dynamic';

const SpellCasterCanvas = dynamic(() => import('./SpellCasterCanvas'), { 
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center min-h-screen bg-black">
      <div className="text-yellow-400 text-2xl font-orbitron">Loading Spell Caster...</div>
    </div>
  )
});

export default function SpellCaster3DPage() {
  return <SpellCasterCanvas />
}