'use client';

import React, { useState, useEffect, useRef } from 'react';
import { getAllVariations } from '../../lib/variationsData';

interface Spell {
  id: string;
  name: string;
  rarity: 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'God Tier';
  pattern: string;
  patternScale: number;
  patternOffsetX: number;
  patternOffsetY: number;
  essenceRequirements: {
    type: string;
    amount: number;
  }[];
  fluxMin: number;
  fluxMax: number;
  description: string;
  unlockRequirements: {
    gold: number;
    essences: {
      type: string;
      amount: number;
    }[];
    specialIngredients: string[];
  };
}

// Custom number input component for XX.XXX format
const PrecisionNumberInput: React.FC<{
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
}> = ({ value, onChange, min = 0, max = 99.999 }) => {
  const digits = value.toFixed(3).padStart(6, '0').split('');
  const [tens, ones, decimal, tenths, hundredths, thousandths] = digits;
  
  const adjustDigit = (position: number, increment: boolean) => {
    const multipliers = [10, 1, 0, 0.1, 0.01, 0.001];
    const multiplier = multipliers[position];
    const newValue = increment ? value + multiplier : value - multiplier;
    const clamped = Math.max(min, Math.min(max, newValue));
    onChange(parseFloat(clamped.toFixed(3)));
  };
  
  return (
    <div className="flex items-center gap-0.5 bg-gray-800 border border-gray-700 rounded px-2 py-1">
      <div className="flex flex-col">
        <button onClick={() => adjustDigit(0, true)} className="text-xs hover:text-yellow-400">▲</button>
        <span className="text-center">{tens}</span>
        <button onClick={() => adjustDigit(0, false)} className="text-xs hover:text-yellow-400">▼</button>
      </div>
      <div className="flex flex-col">
        <button onClick={() => adjustDigit(1, true)} className="text-xs hover:text-yellow-400">▲</button>
        <span className="text-center">{ones}</span>
        <button onClick={() => adjustDigit(1, false)} className="text-xs hover:text-yellow-400">▼</button>
      </div>
      <span>.</span>
      <div className="flex flex-col">
        <button onClick={() => adjustDigit(3, true)} className="text-xs hover:text-yellow-400">▲</button>
        <span className="text-center">{tenths}</span>
        <button onClick={() => adjustDigit(3, false)} className="text-xs hover:text-yellow-400">▼</button>
      </div>
      <div className="flex flex-col">
        <button onClick={() => adjustDigit(4, true)} className="text-xs hover:text-yellow-400">▲</button>
        <span className="text-center">{hundredths}</span>
        <button onClick={() => adjustDigit(4, false)} className="text-xs hover:text-yellow-400">▼</button>
      </div>
      <div className="flex flex-col">
        <button onClick={() => adjustDigit(5, true)} className="text-xs hover:text-yellow-400">▲</button>
        <span className="text-center">{thousandths}</span>
        <button onClick={() => adjustDigit(5, false)} className="text-xs hover:text-yellow-400">▼</button>
      </div>
    </div>
  );
};

export default function SpellDesigner() {
  const [currentSpell, setCurrentSpell] = useState<Spell>({
    id: 'spell_001',
    name: '',
    rarity: 'Common',
    pattern: '',
    patternScale: 1,
    patternOffsetX: 0,
    patternOffsetY: 0,
    essenceRequirements: [],
    fluxMin: 0,
    fluxMax: 0,
    description: '',
    unlockRequirements: {
      gold: 0,
      essences: [],
      specialIngredients: []
    }
  });

  const [savedSpells, setSavedSpells] = useState<Spell[]>([]);
  const [selectedPattern, setSelectedPattern] = useState<string>('');
  const [newEssence, setNewEssence] = useState({ type: '', amount: 0 });
  const [newUnlockEssence, setNewUnlockEssence] = useState({ type: '', amount: 0 });
  const [newIngredient, setNewIngredient] = useState('');
  const [essenceSearch, setEssenceSearch] = useState('');
  const [showEssencePicker, setShowEssencePicker] = useState(false);
  const [unlockEssenceSearch, setUnlockEssenceSearch] = useState('');
  const [showUnlockEssencePicker, setShowUnlockEssencePicker] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [customPath, setCustomPath] = useState<string>('');
  const [drawMode, setDrawMode] = useState<'pen' | 'linear' | 'bezier'>('pen');
  const [showGrid, setShowGrid] = useState(true);
  const [pathPoints, setPathPoints] = useState<{x: number, y: number}[]>([]);
  const [penPoints, setPenPoints] = useState<{x: number, y: number}[]>([]);

  const allVariations = getAllVariations();
  const essenceTypes = allVariations.map(v => v.name + ' Essence');

  const rarityColors = {
    'Common': '#808080',
    'Uncommon': '#00ff00',
    'Rare': '#0099ff',
    'Epic': '#9900ff',
    'Legendary': '#ff8800',
    'God Tier': '#ff0000'
  };

  // Load saved spells from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('savedSpells');
    if (saved) {
      setSavedSpells(JSON.parse(saved));
    }
  }, []);

  const saveSpell = () => {
    const updatedSpells = [...savedSpells.filter(s => s.id !== currentSpell.id), currentSpell];
    setSavedSpells(updatedSpells);
    localStorage.setItem('savedSpells', JSON.stringify(updatedSpells));
    alert('Spell saved!');
  };

  const loadSpell = (spell: Spell) => {
    setCurrentSpell(spell);
    setSelectedPattern(spell.pattern);
    setCustomPath(spell.pattern);
  };

  const addEssenceRequirement = () => {
    if (newEssence.type && newEssence.amount > 0) {
      setCurrentSpell({
        ...currentSpell,
        essenceRequirements: [...currentSpell.essenceRequirements, newEssence]
      });
      setNewEssence({ type: '', amount: 0 });
      setEssenceSearch('');
    }
  };

  const removeEssenceRequirement = (index: number) => {
    setCurrentSpell({
      ...currentSpell,
      essenceRequirements: currentSpell.essenceRequirements.filter((_, i) => i !== index)
    });
  };

  const addUnlockEssence = () => {
    if (newUnlockEssence.type && newUnlockEssence.amount > 0 && currentSpell.unlockRequirements.essences.length < 5) {
      setCurrentSpell({
        ...currentSpell,
        unlockRequirements: {
          ...currentSpell.unlockRequirements,
          essences: [...currentSpell.unlockRequirements.essences, newUnlockEssence]
        }
      });
      setNewUnlockEssence({ type: '', amount: 0 });
      setUnlockEssenceSearch('');
    }
  };

  const removeUnlockEssence = (index: number) => {
    setCurrentSpell({
      ...currentSpell,
      unlockRequirements: {
        ...currentSpell.unlockRequirements,
        essences: currentSpell.unlockRequirements.essences.filter((_, i) => i !== index)
      }
    });
  };

  const addSpecialIngredient = () => {
    if (newIngredient) {
      setCurrentSpell({
        ...currentSpell,
        unlockRequirements: {
          ...currentSpell.unlockRequirements,
          specialIngredients: [...currentSpell.unlockRequirements.specialIngredients, newIngredient]
        }
      });
      setNewIngredient('');
    }
  };

  const removeSpecialIngredient = (index: number) => {
    setCurrentSpell({
      ...currentSpell,
      unlockRequirements: {
        ...currentSpell.unlockRequirements,
        specialIngredients: currentSpell.unlockRequirements.specialIngredients.filter((_, i) => i !== index)
      }
    });
  };

  // Smooth pen strokes
  const smoothPath = (points: {x: number, y: number}[]): string => {
    if (points.length < 2) return '';
    
    let path = `M ${points[0].x} ${points[0].y}`;
    
    if (points.length === 2) {
      path += ` L ${points[1].x} ${points[1].y}`;
    } else {
      // Use quadratic bezier curves for smoothing
      for (let i = 1; i < points.length - 1; i++) {
        const xc = (points[i].x + points[i + 1].x) / 2;
        const yc = (points[i].y + points[i + 1].y) / 2;
        path += ` Q ${points[i].x} ${points[i].y}, ${xc} ${yc}`;
      }
      path += ` L ${points[points.length - 1].x} ${points[points.length - 1].y}`;
    }
    
    return path;
  };

  // Generate random spell pattern
  const generateRandomPattern = () => {
    const types = ['zigzag', 'wave', 'spiral', 'lightning', 'star', 'rune', 'vortex'];
    const type = types[Math.floor(Math.random() * types.length)];
    const points: {x: number, y: number}[] = [];
    const centerX = 200;
    const centerY = 200;
    
    switch(type) {
      case 'zigzag':
        for (let i = 0; i < 5; i++) {
          points.push({
            x: 50 + i * 70,
            y: i % 2 === 0 ? 100 : 300
          });
        }
        break;
      case 'wave':
        for (let i = 0; i <= 20; i++) {
          const t = i / 20;
          points.push({
            x: 50 + t * 300,
            y: 200 + Math.sin(t * Math.PI * 3) * 80
          });
        }
        break;
      case 'spiral':
        for (let i = 0; i <= 30; i++) {
          const angle = (i / 30) * Math.PI * 4;
          const radius = 20 + i * 4;
          points.push({
            x: centerX + Math.cos(angle) * radius,
            y: centerY + Math.sin(angle) * radius
          });
        }
        break;
      case 'lightning':
        for (let i = 0; i < 6; i++) {
          points.push({
            x: 100 + i * 30 + (Math.random() - 0.5) * 40,
            y: 50 + i * 50
          });
        }
        break;
      case 'star':
        const starPoints = 5;
        for (let i = 0; i <= starPoints * 2; i++) {
          const angle = (i / (starPoints * 2)) * Math.PI * 2 - Math.PI / 2;
          const radius = i % 2 === 0 ? 100 : 40;
          points.push({
            x: centerX + Math.cos(angle) * radius,
            y: centerY + Math.sin(angle) * radius
          });
        }
        break;
      case 'rune':
        // Create an intricate rune pattern
        points.push({x: 200, y: 50});
        points.push({x: 200, y: 350});
        points.push({x: 200, y: 200});
        points.push({x: 100, y: 150});
        points.push({x: 300, y: 150});
        points.push({x: 200, y: 200});
        points.push({x: 100, y: 250});
        points.push({x: 300, y: 250});
        break;
      case 'vortex':
        for (let i = 0; i <= 40; i++) {
          const t = i / 40;
          const angle = t * Math.PI * 6;
          const radius = 120 * (1 - t);
          points.push({
            x: centerX + Math.cos(angle) * radius,
            y: centerY + Math.sin(angle) * radius
          });
        }
        break;
    }
    
    const path = smoothPath(points);
    setCustomPath(path);
    setSelectedPattern(path);
    setCurrentSpell({...currentSpell, pattern: path, patternScale: 1, patternOffsetX: 0, patternOffsetY: 0});
  };

  // Handle canvas click based on mode
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    if (drawMode === 'linear') {
      const newPoints = [...pathPoints, {x, y}];
      setPathPoints(newPoints);
      
      // Generate linear path
      let path = '';
      if (newPoints.length > 0) {
        path = `M ${newPoints[0].x} ${newPoints[0].y}`;
        for (let i = 1; i < newPoints.length; i++) {
          path += ` L ${newPoints[i].x} ${newPoints[i].y}`;
        }
      }
      setCustomPath(path);
    } else if (drawMode === 'bezier') {
      const newPoints = [...pathPoints, {x, y}];
      setPathPoints(newPoints);
      
      // Generate smooth bezier path
      if (newPoints.length > 1) {
        const path = smoothPath(newPoints);
        setCustomPath(path);
      }
    }
  };

  // Pen drawing handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (drawMode !== 'pen') return;
    
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setPenPoints([{x, y}]);
    setCustomPath(`M ${x} ${y}`);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || drawMode !== 'pen') return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const newPoints = [...penPoints, {x, y}];
    setPenPoints(newPoints);
    
    // Apply smoothing to pen drawing
    const smoothedPath = smoothPath(newPoints);
    setCustomPath(smoothedPath);
  };

  const stopDrawing = () => {
    if (drawMode !== 'pen') return;
    setIsDrawing(false);
    
    if (customPath) {
      setSelectedPattern(customPath);
      setCurrentSpell({...currentSpell, pattern: customPath, patternScale: 1, patternOffsetX: 0, patternOffsetY: 0});
    }
  };

  const clearCanvas = () => {
    setCustomPath('');
    setSelectedPattern('');
    setPathPoints([]);
    setPenPoints([]);
    setCurrentSpell({...currentSpell, pattern: '', patternScale: 1, patternOffsetX: 0, patternOffsetY: 0});
  };

  // Apply pattern to current spell
  const applyPattern = () => {
    if (customPath) {
      setSelectedPattern(customPath);
      setCurrentSpell({...currentSpell, pattern: customPath});
    }
  };

  const generateSpellPattern = (type: number): string => {
    // Generate different SVG path patterns for spells
    const patterns = [
      // Zigzag
      "M 50 50 L 70 30 L 90 70 L 110 40 L 130 60",
      // Wave
      "M 50 100 Q 75 50, 100 100 T 150 100",
      // Spiral
      "M 100 100 Q 60 60, 60 100 T 100 140 T 140 100 T 100 60",
      // Lightning
      "M 60 40 L 80 80 L 70 90 L 90 130 L 80 135 L 100 170",
      // Circle burst
      "M 100 60 L 100 140 M 60 100 L 140 100 M 70 70 L 130 130 M 130 70 L 70 130",
      // Triangle wave
      "M 40 140 L 60 60 L 80 140 L 100 60 L 120 140 L 140 60 L 160 140",
      // Helix
      "M 50 60 Q 75 100, 100 60 T 150 60 Q 125 100, 100 140 T 50 140",
      // Star
      "M 100 40 L 115 80 L 155 80 L 125 105 L 140 145 L 100 120 L 60 145 L 75 105 L 45 80 L 85 80 Z",
      // Diamond cascade
      "M 70 50 L 100 80 L 70 110 M 100 70 L 130 100 L 100 130",
      // Curved lightning
      "M 50 50 Q 70 90, 90 70 T 130 110 T 170 170",
      // Pentagram
      "M 100 40 L 130 120 L 50 75 L 150 75 L 70 120 Z",
      // Crescent
      "M 70 70 Q 50 100, 70 130 Q 110 100, 70 70",
      // Infinity
      "M 70 100 Q 70 60, 100 100 T 130 100 Q 130 140, 100 100 T 70 100",
      // Flower
      "M 100 100 m -30 0 a 30 30 0 1 0 60 0 a 30 30 0 1 0 -60 0 M 100 100 m 0 -30 a 30 30 0 1 0 0 60 a 30 30 0 1 0 0 -60",
      // Shockwave
      "M 50 100 Q 75 60, 100 100 T 150 100 M 55 100 Q 77 80, 100 100 T 145 100",
      // Rune
      "M 70 40 L 70 160 M 70 75 L 100 50 L 130 75 M 70 125 L 100 150 L 130 125",
      // Vortex
      "M 100 50 Q 150 70, 130 100 T 70 140 Q 50 90, 100 50",
      // Cross blast
      "M 100 40 L 100 160 M 40 100 L 160 100 M 100 100 L 140 60 M 100 100 L 140 140 M 100 100 L 60 60 M 100 100 L 60 140",
      // Meteor
      "M 50 50 L 130 130 M 55 45 L 135 125 M 45 55 L 125 135 M 130 130 Q 135 135, 140 130 T 130 120",
      // Chain
      "M 50 90 Q 65 70, 80 90 T 110 90 T 140 90 Q 125 110, 110 130 T 80 130 T 50 130"
    ];
    
    return patterns[type] || patterns[0];
  };

  const filteredEssences = essenceTypes.filter(e => 
    e.toLowerCase().includes(essenceSearch.toLowerCase())
  );

  const filteredUnlockEssences = essenceTypes.filter(e => 
    e.toLowerCase().includes(unlockEssenceSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-yellow-400 mb-8">Spell Designer</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Spell Editor */}
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Spell Properties</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Spell ID</label>
                <input
                  type="text"
                  value={currentSpell.id}
                  onChange={(e) => setCurrentSpell({...currentSpell, id: e.target.value})}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Name</label>
                <input
                  type="text"
                  value={currentSpell.name}
                  onChange={(e) => setCurrentSpell({...currentSpell, name: e.target.value})}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Rarity</label>
                <select
                  value={currentSpell.rarity}
                  onChange={(e) => setCurrentSpell({...currentSpell, rarity: e.target.value as Spell['rarity']})}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                >
                  {Object.keys(rarityColors).map(rarity => (
                    <option key={rarity} value={rarity}>{rarity}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Description</label>
                <textarea
                  value={currentSpell.description}
                  onChange={(e) => setCurrentSpell({...currentSpell, description: e.target.value})}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white h-20"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-400 mb-1">Flux Range</label>
                <div className="flex gap-2 items-center">
                  <span className="text-gray-400">From</span>
                  <input
                    type="number"
                    value={currentSpell.fluxMin}
                    onChange={(e) => setCurrentSpell({...currentSpell, fluxMin: Number(e.target.value)})}
                    className="w-20 px-2 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                  />
                  <span className="text-gray-400">To</span>
                  <input
                    type="number"
                    value={currentSpell.fluxMax}
                    onChange={(e) => setCurrentSpell({...currentSpell, fluxMax: Number(e.target.value)})}
                    className="w-20 px-2 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                  />
                </div>
              </div>
              
              {/* Essence Requirements for Casting */}
              <div>
                <label className="block text-sm text-gray-400 mb-1">Essence Requirements (for casting)</label>
                <div className="space-y-2">
                  {currentSpell.essenceRequirements.map((req, i) => (
                    <div key={i} className="flex items-center gap-2 bg-gray-800 p-2 rounded">
                      <span className="text-yellow-400">{req.type}</span>
                      <span className="text-gray-400">x{req.amount.toFixed(3)}</span>
                      <button
                        onClick={() => removeEssenceRequirement(i)}
                        className="ml-auto text-red-400 hover:text-red-300"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  
                  <div className="flex gap-2 relative">
                    <div className="flex-1 relative">
                      <input
                        type="text"
                        placeholder="Type essence name..."
                        value={essenceSearch}
                        onChange={(e) => {
                          setEssenceSearch(e.target.value);
                          setNewEssence({...newEssence, type: e.target.value});
                          setShowEssencePicker(true);
                        }}
                        onFocus={() => setShowEssencePicker(true)}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                      />
                      {showEssencePicker && essenceSearch && (
                        <div className="absolute z-10 w-full mt-1 bg-gray-900 border border-gray-600 rounded max-h-40 overflow-y-auto">
                          {filteredEssences.slice(0, 10).map(essence => (
                            <div
                              key={essence}
                              onClick={() => {
                                setNewEssence({...newEssence, type: essence});
                                setEssenceSearch(essence);
                                setShowEssencePicker(false);
                              }}
                              className="px-3 py-2 hover:bg-gray-800 cursor-pointer"
                            >
                              {essence}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <PrecisionNumberInput
                      value={newEssence.amount}
                      onChange={(val) => setNewEssence({...newEssence, amount: val})}
                      min={0.001}
                      max={99.999}
                    />
                    <button
                      onClick={addEssenceRequirement}
                      className="px-4 py-2 bg-yellow-500 text-black rounded hover:bg-yellow-400"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Unlock Requirements & Preview */}
          <div className="space-y-6">
            {/* Unlock Requirements */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Unlock Requirements (Circutree)</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Gold Cost</label>
                  <input
                    type="number"
                    value={currentSpell.unlockRequirements.gold}
                    onChange={(e) => setCurrentSpell({
                      ...currentSpell,
                      unlockRequirements: {...currentSpell.unlockRequirements, gold: Number(e.target.value)}
                    })}
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                  />
                </div>
                
                {/* Unlock Essence Requirements (up to 5) */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">
                    Essence Requirements ({currentSpell.unlockRequirements.essences.length}/5)
                  </label>
                  <div className="space-y-2">
                    {currentSpell.unlockRequirements.essences.map((req, i) => (
                      <div key={i} className="flex items-center gap-2 bg-gray-800 p-2 rounded">
                        <span className="text-purple-400">{req.type}</span>
                        <span className="text-gray-400">x{req.amount.toFixed(3)}</span>
                        <button
                          onClick={() => removeUnlockEssence(i)}
                          className="ml-auto text-red-400 hover:text-red-300"
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    
                    {currentSpell.unlockRequirements.essences.length < 5 && (
                      <div className="flex gap-2 relative">
                        <div className="flex-1 relative">
                          <input
                            type="text"
                            placeholder="Type essence name..."
                            value={unlockEssenceSearch}
                            onChange={(e) => {
                              setUnlockEssenceSearch(e.target.value);
                              setNewUnlockEssence({...newUnlockEssence, type: e.target.value});
                              setShowUnlockEssencePicker(true);
                            }}
                            onFocus={() => setShowUnlockEssencePicker(true)}
                            className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                          />
                          {showUnlockEssencePicker && unlockEssenceSearch && (
                            <div className="absolute z-10 w-full mt-1 bg-gray-900 border border-gray-600 rounded max-h-40 overflow-y-auto">
                              {filteredUnlockEssences.slice(0, 10).map(essence => (
                                <div
                                  key={essence}
                                  onClick={() => {
                                    setNewUnlockEssence({...newUnlockEssence, type: essence});
                                    setUnlockEssenceSearch(essence);
                                    setShowUnlockEssencePicker(false);
                                  }}
                                  className="px-3 py-2 hover:bg-gray-800 cursor-pointer"
                                >
                                  {essence}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        <PrecisionNumberInput
                          value={newUnlockEssence.amount}
                          onChange={(val) => setNewUnlockEssence({...newUnlockEssence, amount: val})}
                          min={0.001}
                          max={99.999}
                        />
                        <button
                          onClick={addUnlockEssence}
                          className="px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-400"
                        >
                          Add
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Special Ingredients */}
                <div>
                  <label className="block text-sm text-gray-400 mb-1">Special Ingredients</label>
                  <div className="space-y-2">
                    {currentSpell.unlockRequirements.specialIngredients.map((ing, i) => (
                      <div key={i} className="flex items-center gap-2 bg-gray-800 p-2 rounded">
                        <span className="text-green-400">{ing}</span>
                        <button
                          onClick={() => removeSpecialIngredient(i)}
                          className="ml-auto text-red-400 hover:text-red-300"
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="e.g., Dragon Scale"
                        value={newIngredient}
                        onChange={(e) => setNewIngredient(e.target.value)}
                        className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white"
                      />
                      <button
                        onClick={addSpecialIngredient}
                        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-500"
                      >
                        Add
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Preview */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Spell Preview</h2>
              
              <div 
                className="border-2 rounded-lg p-4 text-center"
                style={{ borderColor: rarityColors[currentSpell.rarity] }}
              >
                <h3 className="text-2xl font-bold mb-2" style={{ color: rarityColors[currentSpell.rarity] }}>
                  {currentSpell.name || 'Unnamed Spell'}
                </h3>
                
                {selectedPattern && (
                  <svg width="200" height="200" className="mx-auto my-4" viewBox="0 0 400 400">
                    <g transform={`translate(${200 + currentSpell.patternOffsetX}, ${200 + currentSpell.patternOffsetY}) scale(${currentSpell.patternScale})`}>
                      <g transform="translate(-200, -200)">
                        <path 
                          d={selectedPattern} 
                          stroke={rarityColors[currentSpell.rarity]} 
                          strokeWidth="3" 
                          fill="none"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </g>
                    </g>
                  </svg>
                )}
                
                <p className="text-gray-400 mb-4">{currentSpell.description}</p>
                
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-gray-400">
                    Flux: <span className="text-yellow-400">{currentSpell.fluxMin}-{currentSpell.fluxMax}</span>
                  </div>
                  <div className="text-gray-400">
                    Range: <span className="text-green-400">{currentSpell.range}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-2 mt-4">
                <button
                  onClick={saveSpell}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-500"
                >
                  Save Spell
                </button>
                <button
                  onClick={() => {
                    if (confirm('Create a new spell? This will clear your current work.')) {
                      setCurrentSpell({
                        id: `spell_${Date.now()}`,
                        name: '',
                        rarity: 'Common',
                        pattern: '',
                        patternScale: 1,
                        patternOffsetX: 0,
                        patternOffsetY: 0,
                        essenceRequirements: [],
                        fluxMin: 0,
                        fluxMax: 0,
                        description: '',
                        unlockRequirements: { gold: 0, essences: [], specialIngredients: [] }
                      });
                      setSelectedPattern('');
                      setCustomPath('');
                      setPathPoints([]);
                      setPenPoints([]);
                    }
                  }}
                  className="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600"
                >
                  New Spell
                </button>
              </div>
            </div>
            
            {/* Saved Spells */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">Saved Spells</h2>
              
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {savedSpells.map(spell => (
                  <div
                    key={spell.id}
                    onClick={() => loadSpell(spell)}
                    className="flex items-center justify-between p-3 bg-gray-800 rounded hover:bg-gray-700 cursor-pointer"
                  >
                    <div>
                      <span className="font-bold" style={{ color: rarityColors[spell.rarity] }}>
                        {spell.name}
                      </span>
                      <span className="text-gray-400 text-sm ml-2">({spell.id})</span>
                    </div>
                    <div className="text-sm text-gray-400">
                      Flux: {spell.fluxMin}-{spell.fluxMax}
                    </div>
                  </div>
                ))}
                
                {savedSpells.length === 0 && (
                  <div className="text-gray-500 text-center py-4">No saved spells yet</div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Random Spell Generator */}
        <div className="mt-12 bg-gray-900/50 border border-gray-800 rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Random Pattern Generator</h2>
          <p className="text-gray-400 mb-4">Let me generate a random spell pattern for you!</p>
          
          <div className="flex gap-4 items-start">
            <div className="border-2 border-purple-400/50 rounded p-4">
              {customPath && (
                <svg width="400" height="400" viewBox="0 0 400 400">
                  <g transform={`translate(${currentSpell.patternOffsetX}, ${currentSpell.patternOffsetY}) scale(${currentSpell.patternScale})`}>
                    <path 
                      d={customPath} 
                      stroke={rarityColors[currentSpell.rarity]} 
                      strokeWidth="3" 
                      fill="none"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </g>
                </svg>
              )}
              {!customPath && (
                <div className="w-[400px] h-[400px] flex items-center justify-center text-gray-500">
                  Click "Generate Random" to create a pattern
                </div>
              )}
            </div>
            
            <div className="flex flex-col gap-3">
              <button
                onClick={generateRandomPattern}
                className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-500"
              >
                Generate Random Pattern
              </button>
              
              <div className="bg-gray-800 p-3 rounded space-y-2">
                <h3 className="text-sm font-bold text-gray-300">Pattern Controls</h3>
                
                <div>
                  <label className="text-xs text-gray-400">Scale: {currentSpell.patternScale.toFixed(2)}</label>
                  <input
                    type="range"
                    min="0.5"
                    max="2"
                    step="0.1"
                    value={currentSpell.patternScale}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternScale: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="text-xs text-gray-400">X Offset: {currentSpell.patternOffsetX}</label>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={currentSpell.patternOffsetX}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternOffsetX: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="text-xs text-gray-400">Y Offset: {currentSpell.patternOffsetY}</label>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={currentSpell.patternOffsetY}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternOffsetY: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
                
                <button
                  onClick={() => setCurrentSpell({...currentSpell, patternScale: 1, patternOffsetX: 0, patternOffsetY: 0})}
                  className="px-3 py-1 bg-gray-700 text-white text-sm rounded hover:bg-gray-600 w-full"
                >
                  Reset Position
                </button>
              </div>
              
              <button
                onClick={applyPattern}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-500"
              >
                Use This Pattern
              </button>
            </div>
          </div>
        </div>
        
        {/* Custom Spell Line Generator */}
        <div className="mt-12 bg-gray-900/50 border border-gray-800 rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Custom Pattern Designer</h2>
          <p className="text-gray-400 mb-4">Draw your own spell pattern with multiple modes!</p>
          
          <div className="space-y-4">
            {/* Drawing Controls */}
            <div className="flex gap-4 items-center flex-wrap">
              <div className="flex gap-2">
                <button
                  onClick={() => setDrawMode('pen')}
                  className={`px-4 py-2 rounded ${drawMode === 'pen' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
                >
                  ✏️ Pen (Smooth)
                </button>
                <button
                  onClick={() => setDrawMode('linear')}
                  className={`px-4 py-2 rounded ${drawMode === 'linear' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
                >
                  📐 Linear
                </button>
                <button
                  onClick={() => setDrawMode('bezier')}
                  className={`px-4 py-2 rounded ${drawMode === 'bezier' ? 'bg-yellow-500 text-black' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
                >
                  〰️ Bezier
                </button>
              </div>
              
              <button
                onClick={() => setShowGrid(!showGrid)}
                className={`px-4 py-2 rounded ${showGrid ? 'bg-blue-600 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
              >
                {showGrid ? '⊞ Grid ON' : '⊡ Grid OFF'}
              </button>
              
              <button
                onClick={clearCanvas}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-500"
              >
                Clear Canvas
              </button>
              
              <button
                onClick={applyPattern}
                className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-500"
              >
                Apply to Spell
              </button>
              
              <div className="text-sm text-gray-400">
                {drawMode === 'pen' && 'Click and drag to draw smooth lines'}
                {drawMode === 'linear' && 'Click points to connect with straight lines'}
                {drawMode === 'bezier' && 'Click points to create smooth curves'}
              </div>
            </div>
            
            {/* Full-width Canvas */}
            <div className="relative border-2 border-yellow-400/50 rounded overflow-hidden">
              <canvas
                ref={canvasRef}
                width={1200}
                height={400}
                className="bg-gray-900 cursor-crosshair w-full"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onClick={handleCanvasClick}
                style={{ imageRendering: 'crisp-edges' }}
              />
              
              {/* Grid Overlay */}
              {showGrid && (
                <svg width="1200" height="400" className="absolute top-0 left-0 pointer-events-none">
                  <defs>
                    <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5"/>
                    </pattern>
                    <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
                      <rect width="100" height="100" fill="url(#smallGrid)"/>
                      <path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="1"/>
                    </pattern>
                  </defs>
                  <rect width="1200" height="400" fill="url(#grid)" />
                </svg>
              )}
              
              {/* Path Overlay */}
              {customPath && (
                <svg width="1200" height="400" className="absolute top-0 left-0 pointer-events-none">
                  <path 
                    d={customPath} 
                    stroke="#fab617" 
                    strokeWidth="3" 
                    fill="none"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {/* Draw points for linear/bezier modes */}
                  {(drawMode === 'linear' || drawMode === 'bezier') && pathPoints.map((point, i) => (
                    <circle
                      key={i}
                      cx={point.x}
                      cy={point.y}
                      r="5"
                      fill="#fab617"
                      stroke="white"
                      strokeWidth="2"
                    />
                  ))}
                </svg>
              )}
            </div>
            
            {/* Pattern Transform Controls */}
            <div className="bg-gray-800 p-4 rounded">
              <h3 className="text-sm font-bold text-gray-300 mb-3">Transform Pattern</h3>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-xs text-gray-400">Scale: {currentSpell.patternScale.toFixed(2)}</label>
                  <input
                    type="range"
                    min="0.25"
                    max="3"
                    step="0.05"
                    value={currentSpell.patternScale}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternScale: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="text-xs text-gray-400">X Position: {currentSpell.patternOffsetX}</label>
                  <input
                    type="range"
                    min="-200"
                    max="200"
                    value={currentSpell.patternOffsetX}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternOffsetX: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label className="text-xs text-gray-400">Y Position: {currentSpell.patternOffsetY}</label>
                  <input
                    type="range"
                    min="-200"
                    max="200"
                    value={currentSpell.patternOffsetY}
                    onChange={(e) => setCurrentSpell({...currentSpell, patternOffsetY: Number(e.target.value)})}
                    className="w-full"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Pattern Library */}
        <div className="mt-12 bg-gray-900/50 border border-gray-800 rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Spell Pattern Library</h2>
          <p className="text-gray-400 mb-4">Click a pattern to assign it to the current spell</p>
          
          <div className="grid grid-cols-5 gap-4">
            {[...Array(20)].map((_, i) => {
              const pattern = generateSpellPattern(i);
              return (
                <div
                  key={i}
                  onClick={() => {
                    setSelectedPattern(pattern);
                    setCurrentSpell({...currentSpell, pattern});
                  }}
                  className={`bg-gray-800 rounded-lg p-4 cursor-pointer hover:bg-gray-700 transition-all ${
                    selectedPattern === pattern ? 'ring-2 ring-yellow-400' : ''
                  }`}
                >
                  <svg width="100%" height="200" viewBox="0 0 200 200">
                    <path 
                      d={pattern} 
                      stroke="#fab617" 
                      strokeWidth="2" 
                      fill="none"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.8"
                    />
                  </svg>
                  <div className="text-center text-xs text-gray-500 mt-2">Pattern {i + 1}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}