import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

/**
 * Middleware for domain-based routing
 * Enforces separation between public site (meks.mektycoon.com) and game site (play.mektycoon.com)
 */
export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hostname = request.headers.get('host') || '';

  // Public domain (meks.mektycoon.com) - only allow /mek-rate-logging
  if (hostname.includes('meks.')) {
    if (pathname !== '/mek-rate-logging' && !pathname.startsWith('/_next') && !pathname.startsWith('/api')) {
      return NextResponse.redirect(new URL('/mek-rate-logging', request.url));
    }
  }

  // Game domain (play.mektycoon.com) - redirect / to /hub, block /mek-rate-logging
  if (hostname.includes('play.')) {
    if (pathname === '/') {
      return NextResponse.redirect(new URL('/hub', request.url));
    }
    // Optionally block /mek-rate-logging on game domain
    if (pathname === '/mek-rate-logging') {
      return NextResponse.redirect(new URL('/hub', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public files (images, etc.)
     */
    '/((?!api|_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
