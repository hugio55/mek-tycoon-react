"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

interface Chapter {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  nodeCount: number;
  unlocked: boolean;
  completed: boolean;
  progress: number; // 0-100
  image: string;
  rewards: {
    gold: number;
    essence: number;
    powerChips: number;
  };
}

export default function ChaptersPage() {
  const router = useRouter();
  const [hoveredChapter, setHoveredChapter] = useState<number | null>(null);
  const [layoutOption, setLayoutOption] = useState<number>(1);
  const [particles, setParticles] = useState<Array<{id: number, left: string, top: string, delay: string, duration: string}>>([]);
  const [stars, setStars] = useState<Array<{id: number, left: string, top: string, size: number, opacity: number, twinkle: boolean}>>([]);

  // Random mek images for chapters
  const mekImages = [
    "111-111-111.webp",
    "222-222-222.webp", 
    "333-333-333.webp",
    "444-444-444.webp",
    "555-555-555.webp",
    "666-666-666.webp",
    "777-777-777.webp",
    "888-888-888.webp",
    "999-999-999.webp",
    "aa1-aa1-cd1.webp"
  ];

  const chapters: Chapter[] = [
    {
      id: 1,
      title: "The Awakening",
      subtitle: "Chapter I",
      description: "Your journey begins as a Mek collector in the outer colonies",
      nodeCount: 400,
      unlocked: true,
      completed: false,
      progress: 65,
      image: mekImages[0],
      rewards: { gold: 50000, essence: 25, powerChips: 2 }
    },
    {
      id: 2,
      title: "First Contact",
      subtitle: "Chapter II",
      description: "Mysterious signals lead you to an abandoned research station",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[1],
      rewards: { gold: 75000, essence: 35, powerChips: 3 }
    },
    {
      id: 3,
      title: "The Schism",
      subtitle: "Chapter III",
      description: "Choose your allegiance in the great faction war",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[2],
      rewards: { gold: 100000, essence: 50, powerChips: 4 }
    },
    {
      id: 4,
      title: "Into the Void",
      subtitle: "Chapter IV",
      description: "Venture into uncharted space seeking ancient technology",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[3],
      rewards: { gold: 150000, essence: 75, powerChips: 5 }
    },
    {
      id: 5,
      title: "Betrayal",
      subtitle: "Chapter V",
      description: "Uncover a conspiracy that threatens everything you know",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[4],
      rewards: { gold: 200000, essence: 100, powerChips: 6 }
    },
    {
      id: 6,
      title: "The Resistance",
      subtitle: "Chapter VI",
      description: "Lead the rebellion against the oppressive regime",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[5],
      rewards: { gold: 300000, essence: 150, powerChips: 8 }
    },
    {
      id: 7,
      title: "Nexus Point",
      subtitle: "Chapter VII",
      description: "Discover the truth about the Mek origins",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[6],
      rewards: { gold: 400000, essence: 200, powerChips: 10 }
    },
    {
      id: 8,
      title: "Convergence",
      subtitle: "Chapter VIII",
      description: "All paths lead to the central hub world",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[7],
      rewards: { gold: 500000, essence: 300, powerChips: 12 }
    },
    {
      id: 9,
      title: "The Final Stand",
      subtitle: "Chapter IX",
      description: "Unite the factions for one last battle",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[8],
      rewards: { gold: 750000, essence: 400, powerChips: 15 }
    },
    {
      id: 10,
      title: "Ascension",
      subtitle: "Chapter X",
      description: "The ultimate choice that will shape the future",
      nodeCount: 400,
      unlocked: false,
      completed: false,
      progress: 0,
      image: mekImages[9],
      rewards: { gold: 1000000, essence: 500, powerChips: 20 }
    }
  ];

  useEffect(() => {
    // Generate background effects
    const generatedParticles = [...Array(20)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      delay: `${Math.random() * 10}s`,
      duration: `${5 + Math.random() * 5}s`,
    }));
    setParticles(generatedParticles);
    
    const generatedStars = [...Array(60)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() * 3 + 0.5,
      opacity: Math.random() * 0.8 + 0.2,
      twinkle: Math.random() > 0.5,
    }));
    setStars(generatedStars);
  }, []);

  const handleChapterClick = (chapter: Chapter) => {
    if (chapter.unlocked) {
      router.push(`/contracts/chapters/${chapter.id}`);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Gradient orbs */}
        <div 
          className="absolute left-0 top-0 w-full h-full"
          style={{
            background: `
              radial-gradient(ellipse at 20% 30%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 70%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 50%, rgba(250, 182, 23, 0.08) 0%, transparent 70%)
            `
          }}
        />
        
        {/* Pattern overlay */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 35px,
                rgba(250, 182, 23, 0.03) 35px,
                rgba(250, 182, 23, 0.03) 70px
              )
            `,
          }}
        />
        
        {/* Stars */}
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white"
            style={{
              left: star.left,
              top: star.top,
              width: `${star.size}px`,
              height: `${star.size}px`,
              opacity: star.opacity,
              animation: star.twinkle ? `starTwinkle ${2 + Math.random() * 2}s ease-in-out infinite` : 'none',
              animationDelay: star.twinkle ? `${Math.random() * 2}s` : '0s',
            }}
          />
        ))}
        
        {/* Floating particles */}
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute w-1.5 h-1.5 bg-yellow-400 rounded-full"
            style={{
              left: particle.left,
              top: particle.top,
              animation: `floatParticle ${particle.duration} ease-in-out infinite`,
              animationDelay: particle.delay,
              boxShadow: '0 0 6px rgba(250, 182, 23, 0.6)',
            }}
          />
        ))}
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 p-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Header */}
          <div className="text-center mb-8">
            <h1 
              style={{
                fontFamily: "'Orbitron', 'Rajdhani', 'Bebas Neue', sans-serif",
                fontSize: '48px',
                fontWeight: '900',
                letterSpacing: '2px',
                textShadow: '0 0 30px rgba(250, 182, 23, 0.6)',
                background: 'linear-gradient(135deg, #fab617 0%, #ffdd00 50%, #fab617 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                marginBottom: '8px'
              }}
            >
              STORY MODE CHAPTERS
            </h1>
            <p className="text-gray-400">Choose your chapter • 400 nodes each • Progressive unlocking</p>
          </div>

          {/* Layout Options Dropdown */}
          <div className="flex justify-between items-center mb-6">
            <button
              onClick={() => router.push('/contracts')}
              className="px-4 py-2 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded-lg transition-all text-gray-400 hover:text-white"
            >
              ← Back to Mode Selection
            </button>
            
            <select
              value={layoutOption}
              onChange={(e) => setLayoutOption(Number(e.target.value))}
              className="px-4 py-2 bg-black/60 border border-yellow-500/40 rounded-lg text-yellow-400 focus:border-yellow-500 focus:outline-none"
            >
              <option value={1}>Hexagon 1: Honeycomb Connected</option>
              <option value={2}>Hexagon 2: Neural Network</option>
              <option value={3}>Hexagon 3: Vertical Timeline</option>
              <option value={4}>Hexagon 4: Spiral Path</option>
              <option value={5}>Hexagon 5: Tree Branch</option>
            </select>
          </div>

          {/* Layout Option 1: Honeycomb Connected */}
          {layoutOption === 1 && (
            <div className="relative flex justify-center" style={{ minHeight: '700px' }}>
              {/* Connection Lines */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                {/* Draw connecting lines between hexagons */}
                {chapters.map((chapter, index) => {
                  if (index === 0) return null;
                  const row1 = Math.floor((index - 1) / 3);
                  const col1 = (index - 1) % 3;
                  const row2 = Math.floor(index / 3);
                  const col2 = index % 3;
                  
                  const x1 = 200 + col1 * 180 + (row1 % 2 === 1 ? 90 : 0);
                  const y1 = 100 + row1 * 150;
                  const x2 = 200 + col2 * 180 + (row2 % 2 === 1 ? 90 : 0);
                  const y2 = 100 + row2 * 150;
                  
                  return (
                    <line
                      key={`line-${index}`}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke={chapter.unlocked ? '#fab617' : '#333'}
                      strokeWidth="2"
                      strokeDasharray={chapter.unlocked ? "0" : "5,5"}
                      opacity={0.5}
                    />
                  );
                })}
              </svg>
              
              {/* Hexagon Grid */}
              <div className="relative" style={{ width: '700px' }}>
                {chapters.map((chapter, index) => {
                  const row = Math.floor(index / 3);
                  const col = index % 3;
                  const offsetX = row % 2 === 1 ? 90 : 0;
                  
                  return (
                    <div
                      key={chapter.id}
                      className={`absolute ${chapter.unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                      style={{ 
                        left: `${col * 180 + offsetX}px`,
                        top: `${row * 150}px`,
                        zIndex: 2
                      }}
                      onMouseEnter={() => setHoveredChapter(chapter.id)}
                      onMouseLeave={() => setHoveredChapter(null)}
                      onClick={() => handleChapterClick(chapter)}
                    >
                      <div 
                        className={`relative transition-all duration-300 ${
                          chapter.unlocked 
                            ? 'transform hover:scale-110' 
                            : 'opacity-50 grayscale'
                        }`}
                        style={{
                          clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                          background: chapter.unlocked 
                            ? 'linear-gradient(135deg, #2a2a2a 0%, #1a1a1a 100%)'
                            : 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                          width: '160px',
                          height: '180px',
                          border: hoveredChapter === chapter.id && chapter.unlocked ? '3px solid #fab617' : '3px solid #666'
                        }}
                      >
                        {/* Image Background */}
                        <div className="absolute inset-0">
                          <img 
                            src={`/mek-images/150px/${chapter.image}`}
                            alt={chapter.title}
                            className="w-full h-full object-cover"
                            style={{ opacity: 0.3, clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                          />
                        </div>
                        
                        {/* Content */}
                        <div className="relative h-full flex flex-col items-center justify-center p-4 text-center">
                          <div className="text-2xl font-bold text-yellow-400 mb-1">{chapter.id}</div>
                          <h3 className="text-xs font-bold text-white mb-1">{chapter.title}</h3>
                          {chapter.unlocked && (
                            <div className="text-xs text-gray-400">{chapter.progress}%</div>
                          )}
                          {!chapter.unlocked && (
                            <div className="text-2xl mt-1">🔒</div>
                          )}
                        </div>
                      </div>
                      
                      {/* Tooltip */}
                      {hoveredChapter === chapter.id && !chapter.unlocked && (
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-gray-900 border border-yellow-500/50 rounded-lg p-2 text-xs whitespace-nowrap z-20">
                          Complete Chapter {chapter.id - 1} to unlock
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Layout Option 2: Neural Network */}
          {layoutOption === 2 && (
            <div className="relative flex justify-center" style={{ minHeight: '800px' }}>
              {/* Neural Network Connections */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                {/* Draw neural network style connections */}
                {chapters.map((chapter, index) => {
                  const connections = [];
                  // Connect to multiple nodes ahead
                  for (let i = 1; i <= 3; i++) {
                    if (index + i < chapters.length) {
                      const angle1 = (index * 36) * Math.PI / 180;
                      const angle2 = ((index + i) * 36) * Math.PI / 180;
                      const radius = 250;
                      const x1 = 400 + Math.cos(angle1) * radius;
                      const y1 = 400 + Math.sin(angle1) * radius;
                      const x2 = 400 + Math.cos(angle2) * radius;
                      const y2 = 400 + Math.sin(angle2) * radius;
                      
                      connections.push(
                        <line
                          key={`neural-${index}-${i}`}
                          x1={x1}
                          y1={y1}
                          x2={x2}
                          y2={y2}
                          stroke={chapters[index + i].unlocked ? '#fab617' : '#333'}
                          strokeWidth="1"
                          opacity={0.3}
                        />
                      );
                    }
                  }
                  return connections;
                })}
              </svg>
              
              {/* Hexagons in Circle */}
              <div className="relative" style={{ width: '800px', height: '800px' }}>
                {chapters.map((chapter, index) => {
                  const angle = (index * 36) * Math.PI / 180;
                  const radius = 250;
                  const x = 350 + Math.cos(angle) * radius;
                  const y = 350 + Math.sin(angle) * radius;
                  
                  return (
                    <div
                      key={chapter.id}
                      className={`absolute ${chapter.unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                      style={{ 
                        left: `${x}px`,
                        top: `${y}px`,
                        zIndex: 3
                      }}
                      onMouseEnter={() => setHoveredChapter(chapter.id)}
                      onMouseLeave={() => setHoveredChapter(null)}
                      onClick={() => handleChapterClick(chapter)}
                    >
                      <div 
                        className={`relative transition-all duration-300 ${
                          chapter.unlocked 
                            ? 'transform hover:scale-120' 
                            : 'opacity-50 grayscale'
                        }`}
                        style={{
                          clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                          background: hoveredChapter === chapter.id && chapter.unlocked
                            ? 'linear-gradient(135deg, #fab617 0%, #ffdd00 100%)'
                            : chapter.unlocked 
                              ? 'linear-gradient(135deg, #2a2a2a 0%, #1a1a1a 100%)'
                              : 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                          width: '120px',
                          height: '140px',
                          boxShadow: hoveredChapter === chapter.id && chapter.unlocked
                            ? '0 0 30px rgba(250, 182, 23, 0.8)'
                            : '0 0 10px rgba(0, 0, 0, 0.5)'
                        }}
                      >
                        {/* Content */}
                        <div className="relative h-full flex flex-col items-center justify-center p-2 text-center">
                          <div className="text-xl font-bold text-white mb-1">{chapter.id}</div>
                          <h3 className="text-[10px] font-bold text-white">{chapter.title}</h3>
                          {!chapter.unlocked && (
                            <div className="text-xl mt-1">🔒</div>
                          )}
                        </div>
                      </div>
                      
                      {/* Tooltip */}
                      {hoveredChapter === chapter.id && (
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-gray-900 border border-yellow-500/50 rounded-lg p-2 text-xs whitespace-nowrap z-20">
                          {chapter.unlocked ? (
                            <div>
                              <div>{chapter.description}</div>
                              <div className="text-yellow-400 mt-1">Progress: {chapter.progress}%</div>
                            </div>
                          ) : (
                            <div>Complete Chapter {chapter.id - 1} to unlock</div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Layout Option 3: Vertical Timeline */}
          {layoutOption === 3 && (
            <div className="relative flex justify-center" style={{ minHeight: '1200px' }}>
              {/* Vertical Timeline Line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-yellow-500/20 via-yellow-500/60 to-yellow-500/20" style={{ zIndex: 1 }}></div>
              
              {/* Hexagons along timeline */}
              <div className="relative" style={{ width: '600px' }}>
                {chapters.map((chapter, index) => {
                  const isLeft = index % 2 === 0;
                  const xPos = isLeft ? 100 : 340;
                  const yPos = index * 110;
                  
                  return (
                    <div key={chapter.id}>
                      {/* Connection to timeline */}
                      <div 
                        className="absolute"
                        style={{
                          left: isLeft ? '240px' : '290px',
                          top: `${yPos + 60}px`,
                          width: '60px',
                          height: '2px',
                          background: chapter.unlocked ? '#fab617' : '#333',
                          zIndex: 2
                        }}
                      />
                      
                      {/* Timeline Node */}
                      <div 
                        className="absolute"
                        style={{
                          left: '290px',
                          top: `${yPos + 55}px`,
                          width: '12px',
                          height: '12px',
                          borderRadius: '50%',
                          background: chapter.unlocked ? '#fab617' : '#666',
                          border: '3px solid #000',
                          zIndex: 3
                        }}
                      />
                      
                      {/* Hexagon */}
                      <div
                        className={`absolute ${chapter.unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                        style={{ 
                          left: `${xPos}px`,
                          top: `${yPos}px`,
                          zIndex: 4
                        }}
                        onMouseEnter={() => setHoveredChapter(chapter.id)}
                        onMouseLeave={() => setHoveredChapter(null)}
                        onClick={() => handleChapterClick(chapter)}
                      >
                        <div 
                          className={`relative transition-all duration-300 ${
                            chapter.unlocked 
                              ? 'transform hover:scale-110' 
                              : 'opacity-50 grayscale'
                          }`}
                          style={{
                            clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                            background: chapter.unlocked 
                              ? 'linear-gradient(135deg, #2a2a2a 0%, #1a1a1a 100%)'
                              : 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                            width: '140px',
                            height: '160px',
                            border: hoveredChapter === chapter.id && chapter.unlocked ? '3px solid #fab617' : '3px solid #666'
                          }}
                        >
                          {/* Image Background */}
                          <div className="absolute inset-0">
                            <img 
                              src={`/mek-images/150px/${chapter.image}`}
                              alt={chapter.title}
                              className="w-full h-full object-cover"
                              style={{ opacity: 0.3, clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                            />
                          </div>
                          
                          {/* Content */}
                          <div className="relative h-full flex flex-col items-center justify-center p-3 text-center">
                            <div className="text-xl font-bold text-yellow-400">{chapter.id}</div>
                            <h3 className="text-[11px] font-bold text-white mt-1">{chapter.title}</h3>
                            {chapter.unlocked && (
                              <div className="text-[10px] text-gray-400 mt-1">{chapter.progress}%</div>
                            )}
                            {!chapter.unlocked && (
                              <div className="text-xl mt-1">🔒</div>
                            )}
                          </div>
                        </div>
                        
                        {/* Tooltip */}
                        {hoveredChapter === chapter.id && (
                          <div className={`absolute ${isLeft ? 'left-full ml-2' : 'right-full mr-2'} top-1/2 transform -translate-y-1/2 bg-gray-900 border border-yellow-500/50 rounded-lg p-2 text-xs whitespace-nowrap z-20`}>
                            {chapter.unlocked ? (
                              <div>
                                <div className="font-bold text-yellow-400">{chapter.title}</div>
                                <div className="text-gray-400">{chapter.description}</div>
                                <div className="text-yellow-400 mt-1">Progress: {chapter.progress}%</div>
                              </div>
                            ) : (
                              <div>Complete Chapter {chapter.id - 1} to unlock</div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Layout Option 4: Spiral Path */}
          {layoutOption === 4 && (
            <div className="relative flex justify-center" style={{ minHeight: '800px' }}>
              {/* Spiral Path Connections */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                {/* Draw spiral path */}
                <path
                  d="M 400 400 Q 500 400 500 300 T 400 200 Q 300 200 300 300 T 400 400 Q 550 400 550 250 T 400 150 Q 250 150 250 300 T 400 450 Q 600 450 600 250 T 400 100"
                  stroke="#fab617"
                  strokeWidth="2"
                  fill="none"
                  opacity="0.3"
                />
              </svg>
              
              {/* Hexagons in Spiral */}
              <div className="relative" style={{ width: '800px', height: '800px' }}>
                {chapters.map((chapter, index) => {
                  // Spiral coordinates
                  const spiralAngle = index * 0.8;
                  const spiralRadius = 80 + index * 25;
                  const x = 350 + Math.cos(spiralAngle) * spiralRadius;
                  const y = 350 + Math.sin(spiralAngle) * spiralRadius;
                  
                  return (
                    <div
                      key={chapter.id}
                      className={`absolute ${chapter.unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                      style={{ 
                        left: `${x}px`,
                        top: `${y}px`,
                        zIndex: 10 - index
                      }}
                      onMouseEnter={() => setHoveredChapter(chapter.id)}
                      onMouseLeave={() => setHoveredChapter(null)}
                      onClick={() => handleChapterClick(chapter)}
                    >
                      <div 
                        className={`relative transition-all duration-300 ${
                          chapter.unlocked 
                            ? 'transform hover:scale-115 hover:rotate-6' 
                            : 'opacity-50 grayscale'
                        }`}
                        style={{
                          clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                          background: chapter.unlocked 
                            ? `linear-gradient(135deg, hsl(${index * 36}, 70%, 30%) 0%, #1a1a1a 100%)`
                            : 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                          width: '130px',
                          height: '150px',
                          boxShadow: hoveredChapter === chapter.id && chapter.unlocked
                            ? '0 0 40px rgba(250, 182, 23, 0.8)'
                            : '0 0 15px rgba(0, 0, 0, 0.7)'
                        }}
                      >
                        {/* Image Background */}
                        <div className="absolute inset-0">
                          <img 
                            src={`/mek-images/150px/${chapter.image}`}
                            alt={chapter.title}
                            className="w-full h-full object-cover"
                            style={{ opacity: 0.4, clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                          />
                        </div>
                        
                        {/* Content */}
                        <div className="relative h-full flex flex-col items-center justify-center p-2 text-center">
                          <div className="text-2xl font-bold text-yellow-400">{chapter.id}</div>
                          <h3 className="text-[10px] font-bold text-white mt-1">{chapter.title}</h3>
                          {!chapter.unlocked && (
                            <div className="text-xl mt-1">🔒</div>
                          )}
                        </div>
                      </div>
                      
                      {/* Tooltip */}
                      {hoveredChapter === chapter.id && (
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-gray-900 border border-yellow-500/50 rounded-lg p-2 text-xs z-20">
                          {chapter.unlocked ? (
                            <div>
                              <div className="font-bold text-yellow-400">{chapter.title}</div>
                              <div className="text-gray-400">{chapter.description}</div>
                              <div className="text-yellow-400 mt-1">Progress: {chapter.progress}%</div>
                            </div>
                          ) : (
                            <div>Complete Chapter {chapter.id - 1} to unlock</div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Layout Option 5: Tree Branch */}
          {layoutOption === 5 && (
            <div className="relative flex justify-center" style={{ minHeight: '900px' }}>
              {/* Tree Branch Connections */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                {/* Main trunk */}
                <line x1="400" y1="100" x2="400" y2="300" stroke="#fab617" strokeWidth="3" opacity="0.5" />
                {/* Branches */}
                <line x1="400" y1="300" x2="250" y2="400" stroke="#fab617" strokeWidth="2" opacity="0.4" />
                <line x1="400" y1="300" x2="550" y2="400" stroke="#fab617" strokeWidth="2" opacity="0.4" />
                <line x1="250" y1="400" x2="150" y2="500" stroke="#fab617" strokeWidth="2" opacity="0.3" />
                <line x1="250" y1="400" x2="350" y2="500" stroke="#fab617" strokeWidth="2" opacity="0.3" />
                <line x1="550" y1="400" x2="450" y2="500" stroke="#fab617" strokeWidth="2" opacity="0.3" />
                <line x1="550" y1="400" x2="650" y2="500" stroke="#fab617" strokeWidth="2" opacity="0.3" />
                {/* Sub-branches */}
                <line x1="150" y1="500" x2="100" y2="600" stroke="#fab617" strokeWidth="1" opacity="0.2" />
                <line x1="150" y1="500" x2="200" y2="600" stroke="#fab617" strokeWidth="1" opacity="0.2" />
                <line x1="450" y1="500" x2="500" y2="600" stroke="#fab617" strokeWidth="1" opacity="0.2" />
                <line x1="650" y1="500" x2="700" y2="600" stroke="#fab617" strokeWidth="1" opacity="0.2" />
              </svg>
              
              {/* Hexagons positioned on tree branches */}
              <div className="relative" style={{ width: '800px', height: '900px' }}>
                {chapters.map((chapter, index) => {
                  // Tree positions
                  const positions = [
                    { x: 330, y: 50 },   // Chapter 1 - top
                    { x: 180, y: 350 },  // Chapter 2 - left branch
                    { x: 480, y: 350 },  // Chapter 3 - right branch
                    { x: 80, y: 450 },   // Chapter 4
                    { x: 280, y: 450 },  // Chapter 5
                    { x: 380, y: 450 },  // Chapter 6
                    { x: 580, y: 450 },  // Chapter 7
                    { x: 30, y: 550 },   // Chapter 8
                    { x: 130, y: 550 },  // Chapter 9
                    { x: 630, y: 550 }   // Chapter 10
                  ];
                  
                  const pos = positions[index] || { x: 0, y: 0 };
                  
                  return (
                    <div
                      key={chapter.id}
                      className={`absolute ${chapter.unlocked ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                      style={{ 
                        left: `${pos.x}px`,
                        top: `${pos.y}px`,
                        zIndex: 2
                      }}
                      onMouseEnter={() => setHoveredChapter(chapter.id)}
                      onMouseLeave={() => setHoveredChapter(null)}
                      onClick={() => handleChapterClick(chapter)}
                    >
                      <div 
                        className={`relative transition-all duration-300 ${
                          chapter.unlocked 
                            ? 'transform hover:scale-110' 
                            : 'opacity-50 grayscale'
                        }`}
                        style={{
                          clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                          background: chapter.unlocked 
                            ? 'linear-gradient(135deg, #3a3a3a 0%, #2a2a2a 100%)'
                            : 'linear-gradient(135deg, #1a1a1a 0%, #0a0a0a 100%)',
                          width: '140px',
                          height: '160px',
                          boxShadow: hoveredChapter === chapter.id && chapter.unlocked
                            ? '0 0 50px rgba(250, 182, 23, 0.9), inset 0 0 20px rgba(250, 182, 23, 0.3)'
                            : '0 5px 20px rgba(0, 0, 0, 0.8)'
                        }}
                      >
                        {/* Glow Effect */}
                        {hoveredChapter === chapter.id && chapter.unlocked && (
                          <div 
                            className="absolute inset-0"
                            style={{
                              clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)',
                              background: 'radial-gradient(circle, rgba(250, 182, 23, 0.2) 0%, transparent 70%)',
                              animation: 'pulse 2s infinite'
                            }}
                          />
                        )}
                        
                        {/* Image Background */}
                        <div className="absolute inset-0">
                          <img 
                            src={`/mek-images/150px/${chapter.image}`}
                            alt={chapter.title}
                            className="w-full h-full object-cover"
                            style={{ opacity: 0.4, clipPath: 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)' }}
                          />
                        </div>
                        
                        {/* Content */}
                        <div className="relative h-full flex flex-col items-center justify-center p-3 text-center">
                          <div className="text-2xl font-bold text-yellow-400 drop-shadow-lg">{chapter.id}</div>
                          <h3 className="text-[11px] font-bold text-white mt-1 drop-shadow-lg">{chapter.title}</h3>
                          {chapter.unlocked && (
                            <div className="text-[10px] text-green-400 mt-1">{chapter.progress}%</div>
                          )}
                          {!chapter.unlocked && (
                            <div className="text-2xl mt-1">🔒</div>
                          )}
                        </div>
                      </div>
                      
                      {/* Tooltip */}
                      {hoveredChapter === chapter.id && (
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-gray-900 border border-yellow-500/50 rounded-lg p-3 text-xs z-20 min-w-[200px]">
                          {chapter.unlocked ? (
                            <div>
                              <div className="font-bold text-yellow-400 text-sm mb-1">{chapter.title}</div>
                              <div className="text-gray-400 mb-2">{chapter.description}</div>
                              <div className="grid grid-cols-3 gap-2 text-center">
                                <div>
                                  <div className="text-yellow-400">{chapter.progress}%</div>
                                  <div className="text-gray-500 text-[10px]">Progress</div>
                                </div>
                                <div>
                                  <div className="text-green-400">{(chapter.rewards.gold/1000).toFixed(0)}K</div>
                                  <div className="text-gray-500 text-[10px]">Gold</div>
                                </div>
                                <div>
                                  <div className="text-purple-400">{chapter.rewards.powerChips}</div>
                                  <div className="text-gray-500 text-[10px]">Chips</div>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="text-red-400">
                              🔒 Complete Chapter {chapter.id - 1} to unlock
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}