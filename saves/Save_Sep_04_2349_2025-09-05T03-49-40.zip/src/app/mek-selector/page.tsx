'use client';

import React, { useState, useEffect, useRef } from 'react';

interface Mek {
  id: string;
  number: number;
  rank: string;
  goldPerHour: number;
  image: string;
}

// Real mek images from the folder
const mekImages = [
  '000-000-000', '111-111-111', '222-222-222', '333-333-333',
  '444-444-444', '555-555-555', '666-666-666', '777-777-777',
  '888-888-888', '999-999-999', 'aa1-aa1-cd1', 'aa1-aa3-hn1',
  'aa1-aa4-gk1', 'aa1-ak1-bc2', 'aa1-ak1-de1', 'aa1-ak1-ji2',
  'aa1-ak1-kq2', 'aa1-ak1-mo1', 'aa1-ak1-nm1', 'aa1-ak2-lg1',
  'bc2-dm1-ap1', 'bc2-dm1-as3', 'bc2-dm1-aw2', 'bc2-dm1-il2',
  'bc2-dm2-eh2', 'bc2-dm2-fb1', 'bc2-dm2-of1', 'bc2-ds1-as3',
  'bc2-ds1-ji1', 'bc2-ds2-de1', 'bc2-ee1-bc1', 'bc2-ee1-ey1',
  'bc2-ee1-mo1', 'bc2-er1-bc1', 'bc2-er1-mt1', 'bc2-er3-aj2',
  'bc2-er3-eh1', 'bc2-ev1-eh1', 'bc2-ev1-hn1', 'bc2-fd2-lg1',
  'dp2-bf4-il2', 'dp2-bf4-nm1', 'dp2-bi2-fb2', 'dp2-bi2-ji2',
  'dp2-bj1-hn1', 'dp2-bj2-da1', 'dp2-bj2-eh2', 'dp2-bl1-bc1',
  'dp2-bl3-mo1', 'dp2-bl4-br2', 'dp2-bq1-bc1', 'dp2-bq1-nm1',
  'dp2-bq3-de3', 'dp2-bq3-eh1', 'dp2-cb1-fb2', 'dp2-cb2-gk2',
  'dp2-dc2-gk3', 'dp2-dh2-fb2', 'dp2-dh2-lg1', 'dp2-dm1-aw1',
  'hb1-gn1-hn1', 'hb1-gn2-ji1', 'hb1-gn2-nm1', 'hb1-gn2-of1',
  'hb1-hp1-aj1', 'hb1-hp3-ap1', 'hb1-io1-ap1', 'hb1-io1-cd1',
  'hb1-io2-ev1', 'hb1-jg1-il2', 'hb1-jg1-lg1', 'hb1-jg2-bc1',
  'hb1-jg2-br3', 'hb1-jg2-de1', 'hb1-jg3-mo1', 'hb1-jg3-nm1',
  'hb1-ky1-hn3', 'hb1-ky1-nm1', 'hb2-aa1-gk2', 'hb2-aa1-ji1'
];

const generateRandomMeks = (count: number): Mek[] => {
  const ranks = ['Common', 'Rare', 'Epic', 'Legendary', 'Mythic'];
  const shuffledImages = [...mekImages].sort(() => Math.random() - 0.5);
  
  return Array.from({ length: count }, (_, i) => {
    const imageIndex = i % shuffledImages.length;
    return {
      id: `mek-${i}`,
      number: 100 + Math.floor(Math.random() * 9900),
      rank: ranks[Math.floor(Math.random() * ranks.length)],
      goldPerHour: Math.floor(Math.random() * 1000) + 100,
      image: shuffledImages[imageIndex]
    };
  });
};

// Style variations
const STYLE_VARIATIONS = {
  industrial: 'Industrial',
  neon: 'Neon Circuit',
  golden: 'Golden Vault',
  cyber: 'Cyber Matrix',
  shadow: 'Shadow Protocol'
};

export default function MekSelector() {
  const [meks, setMeks] = useState<Mek[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  const [gridSize, setGridSize] = useState(10);
  const [rerollUnits, setRerollUnits] = useState(3);
  const [showTooltip, setShowTooltip] = useState(false);
  const [isZooming, setIsZooming] = useState(false);
  const [showLightbox, setShowLightbox] = useState(true);
  const [styleVariation, setStyleVariation] = useState<keyof typeof STYLE_VARIATIONS>('industrial');
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [backgroundStars, setBackgroundStars] = useState<Array<{id: number, left: string, top: string, size: number, opacity: number}>>([]);
  const [finalMekIndex, setFinalMekIndex] = useState(0);

  useEffect(() => {
    const newMeks = generateRandomMeks(gridSize);
    setMeks(newMeks);
    // Pre-determine the landing mek
    setFinalMekIndex(Math.floor(Math.random() * gridSize));
    
    // Generate background stars
    const stars = [...Array(50)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.6 + 0.2,
    }));
    setBackgroundStars(stars);
  }, [gridSize]);

  const startSelection = () => {
    if (isAnimating) return;
    
    setIsAnimating(true);
    setSelectedIndex(null);
    setIsZooming(false);
    
    // Animation lasts exactly 5 seconds
    const duration = 5000;
    const startTime = Date.now();
    
    // Calculate total steps needed
    const loops = gridSize <= 10 ? 3 : gridSize <= 40 ? 4 : 5;
    const totalPositions = meks.length * loops + finalMekIndex;
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Linear deceleration from fast to stop
      const speedMultiplier = 1 - progress;
      const currentPosition = Math.floor(totalPositions * progress);
      
      setSelectedIndex(currentPosition % meks.length);
      
      if (progress >= 1) {
        setIsAnimating(false);
        setSelectedIndex(finalMekIndex);
        setTimeout(() => setIsZooming(true), 300);
        return;
      }
      
      // Faster at start, linear slowdown
      const delay = 20 + (1 - speedMultiplier) * 180;
      intervalRef.current = setTimeout(animate, delay);
    };
    
    animate();
  };

  const handleReroll = () => {
    if (rerollUnits > 0) {
      setRerollUnits(rerollUnits - 1);
      const newMeks = generateRandomMeks(gridSize);
      setMeks(newMeks);
      setFinalMekIndex(Math.floor(Math.random() * gridSize));
      startSelection();
    }
  };

  const handleConfirm = () => {
    if (selectedIndex !== null) {
      console.log('Selected Mek:', meks[selectedIndex]);
      setShowLightbox(false);
    }
  };

  const handleGridSizeChange = (size: number) => {
    setGridSize(size);
    setSelectedIndex(null);
    setIsZooming(false);
    setIsAnimating(false);
    setFinalMekIndex(Math.floor(Math.random() * size));
  };

  const getGridClass = () => {
    switch(gridSize) {
      case 3: return 'grid-cols-3 gap-1';
      case 10: return 'grid-cols-5 gap-1';
      case 40: return 'grid-cols-8 gap-0.5';
      case 100: return 'grid-cols-10 gap-0.5';
      default: return 'grid-cols-5 gap-1';
    }
  };

  const getCardSize = () => {
    switch(gridSize) {
      case 3: return 'aspect-square';
      case 10: return 'aspect-square';
      case 40: return 'aspect-square h-16';
      case 100: return 'aspect-square h-12';
      default: return 'aspect-square';
    }
  };

  const getStyleClasses = () => {
    switch(styleVariation) {
      case 'neon':
        return {
          bg: 'bg-gradient-to-br from-purple-950 to-black',
          border: 'border-cyan-400',
          shadow: 'shadow-cyan-400/60',
          button: 'from-cyan-500 to-blue-600',
          buttonHover: 'hover:from-cyan-400 hover:to-blue-500'
        };
      case 'golden':
        return {
          bg: 'bg-gradient-to-br from-amber-950 to-black',
          border: 'border-amber-400',
          shadow: 'shadow-amber-400/60',
          button: 'from-amber-500 to-yellow-600',
          buttonHover: 'hover:from-amber-400 hover:to-yellow-500'
        };
      case 'cyber':
        return {
          bg: 'bg-gradient-to-br from-green-950 to-black',
          border: 'border-green-400',
          shadow: 'shadow-green-400/60',
          button: 'from-green-500 to-emerald-600',
          buttonHover: 'hover:from-green-400 hover:to-emerald-500'
        };
      case 'shadow':
        return {
          bg: 'bg-gradient-to-br from-gray-900 to-black',
          border: 'border-purple-500',
          shadow: 'shadow-purple-500/60',
          button: 'from-purple-600 to-pink-600',
          buttonHover: 'hover:from-purple-500 hover:to-pink-500'
        };
      default: // industrial
        return {
          bg: 'bg-gradient-to-br from-gray-900 to-black',
          border: 'border-yellow-400',
          shadow: 'shadow-yellow-400/60',
          button: 'from-yellow-500 to-yellow-600',
          buttonHover: 'hover:from-yellow-400 hover:to-yellow-500'
        };
    }
  };

  const style = getStyleClasses();

  return (
    <div className="min-h-screen bg-black relative">
      
      {/* Background Page Content - Actual site styling */}
      <div className="fixed inset-0 overflow-hidden">
        
        {/* Background gradient orbs */}
        <div 
          className="absolute left-0 top-0 w-full h-full"
          style={{
            background: `
              radial-gradient(ellipse at 20% 30%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 70%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 50%, rgba(250, 182, 23, 0.08) 0%, transparent 70%)
            `
          }}
        />
        
        {/* Pattern overlay */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 35px,
                rgba(250, 182, 23, 0.03) 35px,
                rgba(250, 182, 23, 0.03) 70px
              )
            `,
          }}
        />
        
        {/* Background stars */}
        {backgroundStars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white"
            style={{
              left: star.left,
              top: star.top,
              width: `${star.size}px`,
              height: `${star.size}px`,
              opacity: star.opacity * 0.5,
            }}
          />
        ))}
        
        {/* Simulated Profile Page content */}
        <div className="p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-5xl font-bold text-yellow-400 mb-8" style={{ fontFamily: "'Orbitron', sans-serif" }}>
              PROFILE
            </h1>
            
            <div className="grid grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 border border-yellow-500/20 rounded-xl p-6 backdrop-blur">
                <h2 className="text-xl text-yellow-400 mb-4 font-bold" style={{ fontFamily: "'Orbitron', sans-serif" }}>STATISTICS</h2>
                <div className="space-y-3 text-gray-300">
                  <div className="flex justify-between">
                    <span>Total Meks:</span>
                    <span className="text-yellow-400">145</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Gold per Hour:</span>
                    <span className="text-yellow-400">12,450</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Rank:</span>
                    <span className="text-purple-400">Diamond III</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 border border-yellow-500/20 rounded-xl p-6 backdrop-blur">
                <h2 className="text-xl text-yellow-400 mb-4 font-bold" style={{ fontFamily: "'Orbitron', sans-serif" }}>INVENTORY</h2>
                <div className="space-y-3 text-gray-300">
                  <div className="flex justify-between">
                    <span>Re-roll Units:</span>
                    <span className="text-cyan-400">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Upgrade Tokens:</span>
                    <span className="text-green-400">27</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Mystery Boxes:</span>
                    <span className="text-purple-400">5</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-gray-900/80 to-black/80 border border-yellow-500/20 rounded-xl p-6 backdrop-blur">
                <h2 className="text-xl text-yellow-400 mb-4 font-bold" style={{ fontFamily: "'Orbitron', sans-serif" }}>RECENT ACTIVITY</h2>
                <div className="space-y-3 text-gray-300">
                  <p className="flex items-center gap-2">
                    <span className="text-green-400">✓</span> Completed Mission #42
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="text-yellow-400">★</span> Unlocked New Mek
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="text-purple-400">🏆</span> Achievement Earned
                  </p>
                </div>
              </div>
            </div>
            
            <div className="text-center py-12">
              <button className="px-12 py-4 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-yellow-500 transition-all text-lg" style={{ fontFamily: "'Orbitron', sans-serif" }}>
                SLOT MEK
              </button>
              <p className="text-gray-500 mt-4 text-sm">Click to open Mek Selection Lottery</p>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox Overlay */}
      {showLightbox && (
        <>
          {/* Dark overlay */}
          <div 
            className="fixed inset-0 bg-black/85 backdrop-blur-sm z-40"
            onClick={() => setShowLightbox(false)}
          />
          
          {/* Lightbox Content - Industrial Style like Acid Crisis */}
          <div className="fixed inset-0 flex items-center justify-center z-50 p-8">
            <div 
              className="relative w-full max-w-4xl overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, rgba(26, 26, 26, 0.98) 0%, rgba(42, 42, 42, 0.98) 50%, rgba(26, 26, 26, 0.98) 100%)',
                border: '2px solid rgba(250, 182, 23, 0.6)',
                boxShadow: '0 0 80px rgba(250, 182, 23, 0.3), inset 0 0 40px rgba(0, 0, 0, 0.5)',
              }}
            >
              {/* Style variation dropdown */}
              <div className="absolute top-4 right-4 z-20">
                <select
                  value={styleVariation}
                  onChange={(e) => setStyleVariation(e.target.value as keyof typeof STYLE_VARIATIONS)}
                  className="bg-black/80 text-yellow-400 border border-yellow-400/50 rounded px-3 py-1 text-xs uppercase tracking-wider"
                  style={{ fontFamily: "'Orbitron', sans-serif" }}
                >
                  {Object.entries(STYLE_VARIATIONS).map(([key, name]) => (
                    <option key={key} value={key}>{name}</option>
                  ))}
                </select>
              </div>

              {/* Industrial grunge overlays */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-30"
                style={{
                  background: `
                    repeating-linear-gradient(
                      45deg,
                      transparent,
                      transparent 10px,
                      rgba(0, 0, 0, 0.1) 10px,
                      rgba(0, 0, 0, 0.1) 20px
                    ),
                    repeating-linear-gradient(
                      -45deg,
                      transparent,
                      transparent 10px,
                      rgba(250, 182, 23, 0.03) 10px,
                      rgba(250, 182, 23, 0.03) 20px
                    )
                  `,
                }}
              />
              
              {/* Metal texture noise */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-40"
                style={{
                  backgroundImage: `
                    repeating-linear-gradient(90deg, 
                      transparent, 
                      transparent 2px, 
                      rgba(0, 0, 0, 0.1) 2px, 
                      rgba(0, 0, 0, 0.1) 3px),
                    repeating-linear-gradient(0deg, 
                      transparent, 
                      transparent 2px, 
                      rgba(0, 0, 0, 0.08) 2px, 
                      rgba(0, 0, 0, 0.08) 3px)
                  `,
                }}
              />
              
              {/* Header - Industrial style */}
              <div className="relative p-5 overflow-hidden" style={{
                background: `
                  repeating-linear-gradient(
                    45deg,
                    rgba(0, 0, 0, 0.9),
                    rgba(0, 0, 0, 0.9) 10px,
                    rgba(250, 182, 23, 0.15) 10px,
                    rgba(250, 182, 23, 0.15) 20px
                  ),
                  linear-gradient(to right, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.8))
                `
              }}>
                {/* Close button */}
                <button
                  onClick={() => setShowLightbox(false)}
                  className="absolute top-4 left-4 text-gray-400 hover:text-yellow-400 text-3xl transition-colors z-10"
                >
                  ×
                </button>
                
                {/* Title */}
                <h1 
                  className="text-center"
                  style={{
                    fontFamily: "'Orbitron', sans-serif",
                    fontSize: '36px',
                    fontWeight: '900',
                    letterSpacing: '3px',
                    textShadow: '0 0 30px rgba(250, 182, 23, 0.6)',
                    color: '#fab617'
                  }}
                >
                  MEK SELECTION LOTTERY
                </h1>
                <div className="text-center text-xs text-gray-500 uppercase tracking-wider mt-1">
                  5 Second Random Selection
                </div>
              </div>
              
              <div className="relative p-5">
                {/* Grid Size Selector */}
                <div className="flex justify-center gap-1 mb-4">
                  {[3, 10, 40, 100].map((size) => (
                    <button
                      key={size}
                      onClick={() => handleGridSizeChange(size)}
                      className={`
                        px-5 py-1.5 text-xs font-bold transition-all uppercase tracking-wider
                        ${gridSize === size 
                          ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-400/60' 
                          : 'bg-black/40 text-gray-500 border border-gray-700 hover:border-gray-500'
                        }
                      `}
                      style={{
                        fontFamily: "'Orbitron', sans-serif",
                      }}
                    >
                      {size}
                    </button>
                  ))}
                </div>
                
                {/* Mek Grid */}
                <div className={`${style.bg} p-2 mb-4 border border-gray-800`} style={{ maxHeight: '450px', overflowY: 'auto' }}>
                  <div className={`grid ${getGridClass()}`}>
                    {meks.map((mek, index) => (
                      <div
                        key={mek.id}
                        className={`
                          relative overflow-hidden ${getCardSize()} bg-black
                          border transition-all duration-100
                          ${selectedIndex === index 
                            ? `${style.border} ${style.shadow} shadow-lg scale-105 z-10` 
                            : 'border-gray-800'
                          }
                          ${isZooming && selectedIndex === index ? 'scale-150 z-20' : ''}
                          ${isZooming && selectedIndex !== index ? 'opacity-10 scale-75' : ''}
                        `}
                      >
                        <img 
                          src={`/mek-images/150px/${mek.image}.webp`}
                          alt={`Mek ${mek.number}`}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = '/meks/placeholder.png';
                          }}
                        />
                        {selectedIndex === index && (
                          <div className={`absolute inset-0 border ${style.border} animate-pulse pointer-events-none`} />
                        )}
                        {isZooming && selectedIndex === index && gridSize <= 10 && (
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent flex items-end p-1">
                            <div className="text-white">
                              <p className="font-bold text-[10px]">#{mek.number}</p>
                              <p className="text-yellow-400 text-[8px]">{mek.rank}</p>
                              <p className="text-green-400 text-[8px]">{mek.goldPerHour} G/hr</p>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex justify-center gap-4">
                  <button
                    onClick={handleReroll}
                    disabled={rerollUnits === 0}
                    onMouseEnter={() => setShowTooltip(true)}
                    onMouseLeave={() => setShowTooltip(false)}
                    className={`
                      relative px-6 py-2 text-xs uppercase tracking-wider font-bold
                      ${rerollUnits > 0 
                        ? 'bg-black/60 text-gray-300 border border-gray-600 hover:border-gray-400' 
                        : 'bg-black/40 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }
                    `}
                    style={{
                      fontFamily: "'Orbitron', sans-serif",
                    }}
                  >
                    <span className="opacity-60">RE-ROLL</span>
                    <span className="ml-2 text-yellow-400">[{rerollUnits}]</span>
                    {showTooltip && rerollUnits === 0 && (
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-1 bg-gray-900 text-white text-[10px] whitespace-nowrap border border-gray-700">
                        No Re-roll Units
                      </div>
                    )}
                  </button>
                  
                  <button
                    onClick={handleConfirm}
                    disabled={!isZooming}
                    className={`
                      px-6 py-2 text-xs uppercase tracking-wider font-bold
                      ${isZooming 
                        ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-400/60 hover:bg-yellow-500/30' 
                        : 'bg-black/40 text-gray-600 border border-gray-800 cursor-not-allowed'
                      }
                    `}
                    style={{
                      fontFamily: "'Orbitron', sans-serif",
                    }}
                  >
                    CONFIRM SELECTION
                  </button>
                </div>

                {!isAnimating && !isZooming && (
                  <button
                    onClick={startSelection}
                    className={`mt-4 w-full py-3 font-bold text-black text-sm bg-gradient-to-r ${style.button} ${style.buttonHover} transition-all uppercase tracking-wider`}
                    style={{
                      fontFamily: "'Orbitron', sans-serif",
                      letterSpacing: '2px',
                    }}
                  >
                    START 5-SECOND LOTTERY
                  </button>
                )}

                {isAnimating && (
                  <div className="mt-4 text-center">
                    <p className="text-yellow-400 text-xs uppercase tracking-wider animate-pulse">Selecting...</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}