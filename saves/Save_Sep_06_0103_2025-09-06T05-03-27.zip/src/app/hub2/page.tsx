"use client";

import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../../convex/_generated/api";
import { Id } from "../../../convex/_generated/dataModel";
import Link from "next/link";
import { GAME_CONSTANTS } from "@/lib/constants";
import UsernameModal from "@/components/UsernameModal";

export default function Hub2Page() {
  
  const [liveGold, setLiveGold] = useState(0);
  const [totalGold, setTotalGold] = useState(0);
  const [userId, setUserId] = useState<Id<"users"> | null>(null);
  const [goldPerSecond, setGoldPerSecond] = useState(0);
  const [lastGoldFetch, setLastGoldFetch] = useState(Date.now());
  const [cachedGoldData, setCachedGoldData] = useState<{goldPerHour: number; goldPerSecond: number} | null>(null);
  const [stars, setStars] = useState<Array<{id: number, left: string, top: string, size: number, opacity: number, twinkle: boolean}>>([]);
  const [initError, setInitError] = useState<string | null>(null);
  const [showUsernameModal, setShowUsernameModal] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState<string | null>(null);
  const [employees, setEmployees] = useState([
    { id: 1234, level: 5, rate: 15.5, gold: 968, maxGold: 968, progress: 100, buffed: false, hourCap: '72h' },
    { id: 3691, level: 7, rate: 22.8, gold: 1644, maxGold: 1644, progress: 100, buffed: true, hourCap: '96h' },
    { id: 9052, level: 6, rate: 18.7, gold: 1346, maxGold: 1346, progress: 100, buffed: false, hourCap: '72h' },
    { id: 7231, level: 2, rate: 9.5, gold: 684, maxGold: 684, progress: 100, buffed: true, hourCap: '120h' },
    { id: 5612, level: 8, rate: 25.3, gold: 1820, maxGold: 1820, progress: 100, buffed: false, hourCap: '72h' },
    { id: 2468, level: 3, rate: 12.2, gold: 523, maxGold: 878, progress: 60, buffed: false, hourCap: '72h' },
    { id: 1847, level: 4, rate: 14.1, gold: 340, maxGold: 1015, progress: 33, buffed: true, hourCap: '96h' },
    { id: 4089, level: 3, rate: 11.8, gold: 425, maxGold: 850, progress: 50, buffed: false, hourCap: '72h' },
    { id: null, level: 0, rate: 0, gold: 0, maxGold: 0, progress: 0, buffed: false, hourCap: '72h' },
  ]);
  
  // Get or create user
  const getOrCreateUser = useMutation(api.users.getOrCreateUser);
  const getInitialGold = useMutation(api.goldTrackingOptimized.getInitialGoldData);
  const getUserDisplayName = useQuery(api.usernames.getUserDisplayName, 
    walletAddress ? { walletAddress } : "skip"
  );
  
  useEffect(() => {
    const initUser = async () => {
      try {
        const storedWallet = localStorage.getItem('walletAddress') || localStorage.getItem('stakeAddress') || "demo_wallet_123";
        setWalletAddress(storedWallet);
        
        const user = await getOrCreateUser({ 
          walletAddress: storedWallet 
        });
        if (user) {
          setUserId(user._id as Id<"users">);
          setTotalGold(user.gold);
          
          try {
            const goldData = await getInitialGold({ userId: user._id as Id<"users"> });
            setCachedGoldData(goldData);
            setGoldPerSecond(goldData.goldPerSecond);
            setLiveGold(goldData.pendingGold);
            setLastGoldFetch(Date.now());
          } catch (error) {
            console.error("Failed to fetch initial gold data:", error);
            setGoldPerSecond(50 / 3600);
            setLiveGold(0);
          }
        }
      } catch (error) {
        console.error("Failed to initialize user:", error);
        setInitError("Failed to connect to server");
      }
    };
    initUser();
  }, [getOrCreateUser, getInitialGold]);
  
  // Update displayName when getUserDisplayName changes
  useEffect(() => {
    if (getUserDisplayName) {
      // Handle if getUserDisplayName is an object with displayNameSet property
      if (typeof getUserDisplayName === 'object' && getUserDisplayName.displayNameSet) {
        setDisplayName(getUserDisplayName.displayNameSet);
      } else if (typeof getUserDisplayName === 'string') {
        setDisplayName(getUserDisplayName);
      }
    }
  }, [getUserDisplayName]);
  
  // Live gold updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveGold((prev) => {
        const newAmount = prev + goldPerSecond;
        return newAmount;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [goldPerSecond]);
  
  // Generate stars on mount
  useEffect(() => {
    const newStars = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() * 3 + 0.5,
      opacity: Math.random() * 0.8 + 0.2,
      twinkle: Math.random() > 0.5,
    }));
    setStars(newStars);
  }, []);
  
  const formatGoldAmount = (amount: number): string => {
    return amount.toLocaleString();
  };
  
  const collectGold = useMutation(api.goldTrackingOptimized.collectGoldForce);
  
  const handleCollectAll = async () => {
    if (!userId) return;
    
    try {
      const result = await collectGold({ userId });
      if (result) {
        setTotalGold(result.totalGold);
        setLiveGold(0);
        setLastGoldFetch(Date.now());
      }
    } catch (error) {
      console.error("Failed to collect gold:", error);
    }
  };

  // Grid helper to create sections
  const renderSection = (title: string, content: React.ReactNode, epicTitle?: string) => {
    return (
      <div className="relative">
        <div 
          className="relative rounded-lg overflow-hidden"
          style={{
            background: `
              linear-gradient(135deg, 
                rgba(250, 182, 23, 0.02) 0%, 
                rgba(250, 182, 23, 0.05) 50%, 
                rgba(250, 182, 23, 0.02) 100%)`,
            backdropFilter: 'blur(6px)',
            boxShadow: 'inset 0 0 40px rgba(250, 182, 23, 0.03)',
          }}
        >
          {/* Glass effect overlays */}
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `
                radial-gradient(circle at 20% 30%, rgba(250, 182, 23, 0.08) 0%, transparent 30%),
                radial-gradient(circle at 80% 70%, rgba(250, 182, 23, 0.06) 0%, transparent 25%),
                radial-gradient(circle at 50% 50%, rgba(255, 255, 255, 0.02) 0%, transparent 40%)`,
              mixBlendMode: 'screen',
            }}
          />
          {/* Dirty glass smudge pattern */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-30"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
            }}
          />
          
          {/* Frame border with golden edges */}
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{
              border: '1px solid rgba(250, 182, 23, 0.2)',
              borderRadius: '8px',
              boxShadow: `
                inset 0 0 0 1px rgba(250, 182, 23, 0.1),
                inset 0 0 20px rgba(250, 182, 23, 0.05)`,
            }}
          />
          
          {/* Content */}
          <div className="relative z-10 p-6">
            {/* Industrial header */}
            <div 
              className="flex items-center justify-between mb-4 pb-3"
              style={{
                borderBottom: '1px solid rgba(250, 182, 23, 0.15)'
              }}
            >
              <div>
                <h2 
                  className="text-xs uppercase tracking-[0.3em] text-gray-500 mb-1"
                  style={{ fontFamily: "'Inter', 'Segoe UI', sans-serif" }}
                >
                  {title}
                </h2>
                {epicTitle && (
                  <h3 
                    className="text-xl font-bold"
                    style={{
                      fontFamily: "'Orbitron', 'Bebas Neue', sans-serif",
                      color: '#fab617',
                      textShadow: '0 0 20px rgba(250, 182, 23, 0.4)',
                      letterSpacing: '0.05em'
                    }}
                  >
                    {epicTitle}
                  </h3>
                )}
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
                <span className="text-xs text-gray-500 uppercase">ACTIVE</span>
              </div>
            </div>
            
            {content}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Gradient orbs */}
        <div 
          className="absolute left-0 top-0 w-full h-full"
          style={{
            background: `
              radial-gradient(ellipse at 20% 30%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 70%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 50%, rgba(250, 182, 23, 0.08) 0%, transparent 70%)
            `
          }}
        />
        
        {/* Pattern overlay */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 35px,
                rgba(250, 182, 23, 0.03) 35px,
                rgba(250, 182, 23, 0.03) 70px
              )
            `,
          }}
        />
        
        {/* Stars */}
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white"
            style={{
              left: star.left,
              top: star.top,
              width: `${star.size}px`,
              height: `${star.size}px`,
              opacity: star.opacity,
              animation: star.twinkle ? `starTwinkle ${2 + Math.random() * 2}s ease-in-out infinite` : 'none',
              animationDelay: star.twinkle ? `${Math.random() * 2}s` : '0s',
            }}
          />
        ))}
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 min-h-screen p-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Title */}
          <div className="text-center mb-12">
            <h1 
              style={{
                fontFamily: "'Orbitron', 'Rajdhani', 'Bebas Neue', sans-serif",
                fontSize: '56px',
                fontWeight: '900',
                letterSpacing: '2px',
                textShadow: '0 0 30px rgba(250, 182, 23, 0.6)',
                background: 'linear-gradient(135deg, #fab617 0%, #ffdd00 50%, #fab617 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                marginBottom: '16px'
              }}
            >
              COMMAND CENTER
            </h1>
            <p className="text-gray-400 text-lg">Hub 2 - Industrial Operations</p>
          </div>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Gold Collection Section */}
            {renderSection("RESOURCE MANAGEMENT", (
              <div>
                {/* Gold Display */}
                <div className="bg-gradient-to-r from-yellow-900/20 to-orange-900/20 rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-yellow-300/70 uppercase tracking-wider">Total Gold</span>
                    <span className="text-2xl font-bold text-yellow-400">
                      {formatGoldAmount(Math.floor(totalGold + liveGold))}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">Live Collection</span>
                    <span className="text-sm text-yellow-300">
                      +{formatGoldAmount(Math.floor(liveGold))}
                    </span>
                  </div>
                </div>
                
                {/* Gold Per Hour */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-black/30 rounded-lg p-3 border border-gray-800/50">
                    <div className="text-xs text-gray-500 mb-1">Gold/Hour</div>
                    <div className="text-lg font-medium text-yellow-400">
                      {cachedGoldData ? formatGoldAmount(Math.floor(cachedGoldData.goldPerHour)) : '0'}
                    </div>
                  </div>
                  <div className="bg-black/30 rounded-lg p-3 border border-gray-800/50">
                    <div className="text-xs text-gray-500 mb-1">Gold/Second</div>
                    <div className="text-lg font-medium text-green-400">
                      {goldPerSecond.toFixed(3)}
                    </div>
                  </div>
                </div>
                
                {/* Collect Button */}
                <button 
                  onClick={handleCollectAll}
                  className="w-full relative py-3 bg-gradient-to-r from-yellow-600 to-orange-500 text-black rounded-lg font-bold text-base uppercase tracking-wider overflow-hidden group shadow-lg hover:shadow-yellow-500/30 transition-all"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-300 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <span className="relative">COLLECT ALL GOLD</span>
                </button>
              </div>
            ), "GOLD EXTRACTION FACILITY")}
            
            {/* Employee Meks Section */}
            {renderSection("WORKFORCE DEPLOYMENT", (
              <div>
                {/* Employee Grid */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  {employees.slice(0, 9).map((emp, i) => (
                    <div 
                      key={i} 
                      className="aspect-square"
                    >
                      <div 
                        className={`w-full h-full ${emp.id ? 'bg-gradient-to-br from-gray-800/60 to-gray-900/60' : 'bg-gradient-to-br from-gray-900/50 to-black/50'} rounded-lg border ${emp.id ? 'border-yellow-500/20' : 'border-gray-800'} flex flex-col items-center justify-center transition-all hover:scale-105`}
                      >
                        {emp.id ? (
                          <>
                            <span className="text-2xl mb-1">🤖</span>
                            <span className="text-xs text-yellow-400">#{emp.id}</span>
                            <div className="text-xs text-gray-500 mt-1">
                              {emp.progress}%
                            </div>
                          </>
                        ) : (
                          <>
                            <span className="text-2xl text-gray-700">+</span>
                            <span className="text-xs text-gray-700">Empty</span>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Stats Summary */}
                <div className="bg-black/30 rounded-lg p-3 border border-gray-800/50">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Active Meks</span>
                    <span className="text-lg font-medium text-yellow-400">
                      {employees.filter(e => e.id).length}/9
                    </span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-gray-400">Total Rate</span>
                    <span className="text-lg font-medium text-green-400">
                      {employees.reduce((sum, e) => sum + e.rate, 0).toFixed(1)} g/h
                    </span>
                  </div>
                </div>
              </div>
            ), "MEK WORKFORCE ALPHA")}
            
            {/* Quick Actions Section */}
            {renderSection("OPERATIONS CONTROL", (
              <div className="grid grid-cols-2 gap-3">
                <Link href="/inventory" className="block">
                  <div className="bg-black/30 rounded-lg p-4 border border-gray-800/50 hover:border-yellow-500/30 transition-all">
                    <div className="text-2xl mb-2">📦</div>
                    <div className="text-sm font-medium text-gray-300">Inventory</div>
                    <div className="text-xs text-gray-500 mt-1">Manage Items</div>
                  </div>
                </Link>
                <Link href="/crafting" className="block">
                  <div className="bg-black/30 rounded-lg p-4 border border-gray-800/50 hover:border-yellow-500/30 transition-all">
                    <div className="text-2xl mb-2">🔨</div>
                    <div className="text-sm font-medium text-gray-300">Crafting</div>
                    <div className="text-xs text-gray-500 mt-1">Create Meks</div>
                  </div>
                </Link>
                <Link href="/shop" className="block">
                  <div className="bg-black/30 rounded-lg p-4 border border-gray-800/50 hover:border-yellow-500/30 transition-all">
                    <div className="text-2xl mb-2">🛒</div>
                    <div className="text-sm font-medium text-gray-300">Shop</div>
                    <div className="text-xs text-gray-500 mt-1">Buy & Sell</div>
                  </div>
                </Link>
                <Link href="/profile" className="block">
                  <div className="bg-black/30 rounded-lg p-4 border border-gray-800/50 hover:border-yellow-500/30 transition-all">
                    <div className="text-2xl mb-2">👤</div>
                    <div className="text-sm font-medium text-gray-300">Profile</div>
                    <div className="text-xs text-gray-500 mt-1">Your Stats</div>
                  </div>
                </Link>
              </div>
            ), "COMMAND MODULES")}
            
            {/* User Info Section */}
            {renderSection("OPERATOR STATUS", (
              <div>
                {/* Username Display */}
                <div className="bg-black/30 rounded-lg p-4 border border-gray-800/50 mb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Commander</div>
                      <div className="text-lg font-medium text-yellow-400">
                        {(typeof displayName === 'string' ? displayName : displayName?.displayNameSet) || 'Anonymous Operator'}
                      </div>
                    </div>
                    <button
                      onClick={() => setShowUsernameModal(true)}
                      className="px-3 py-1 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded text-xs transition-all"
                    >
                      Edit
                    </button>
                  </div>
                </div>
                
                {/* Connection Status */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-black/30 rounded-lg p-3 border border-gray-800/50">
                    <div className="text-xs text-gray-500 mb-1">Status</div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                      <span className="text-sm text-green-400">Online</span>
                    </div>
                  </div>
                  <div className="bg-black/30 rounded-lg p-3 border border-gray-800/50">
                    <div className="text-xs text-gray-500 mb-1">Session</div>
                    <div className="text-sm text-gray-400">
                      {userId ? 'Connected' : 'Initializing...'}
                    </div>
                  </div>
                </div>
              </div>
            ), "IDENTIFICATION MODULE")}
            
          </div>
          
          {/* Back Button */}
          <div className="text-center mt-12">
            <Link href="/">
              <button className="px-6 py-2 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded-lg transition-all text-gray-400 hover:text-white">
                Back to Main Menu
              </button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Username Modal */}
      {showUsernameModal && walletAddress && (
        <UsernameModal
          walletAddress={walletAddress}
          onClose={() => setShowUsernameModal(false)}
        />
      )}
      
      {/* CSS for animations */}
      <style jsx global>{`
        @keyframes starTwinkle {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 1; }
        }
        
        @keyframes floatParticle {
          0%, 100% { 
            transform: translateY(0) translateX(0);
            opacity: 0.6;
          }
          50% { 
            transform: translateY(-20px) translateX(10px);
            opacity: 1;
          }
        }
        
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}</style>
    </div>
  );
}