"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

// Node types
type NodeType = "battle" | "boss" | "event" | "treasure" | "rest" | "shop";

interface StoryNode {
  id: number;
  level: number;
  type: NodeType;
  x: number;
  y: number;
  connections: number[];
  completed?: boolean;
  available?: boolean;
  current?: boolean;
  name?: string;
  difficulty?: number;
  rewards?: {
    gold?: number;
    xp?: number;
    items?: string[];
  };
  enemy?: {
    name: string;
    image: string;
    power: number;
  };
}

// Generate Chapter 1 Test tree (400 nodes climbing upward)
const generateChapter1Tree = (): StoryNode[] => {
  const nodes: StoryNode[] = [];
  const nodesPerLevel = 8;
  const totalLevels = 50; // 50 levels * 8 nodes = 400 nodes
  
  for (let level = 0; level < totalLevels; level++) {
    const isBossLevel = (level + 1) % 10 === 0;
    const isRestLevel = (level + 1) % 5 === 0 && !isBossLevel;
    
    for (let i = 0; i < nodesPerLevel; i++) {
      const nodeId = level * nodesPerLevel + i;
      let nodeType: NodeType = "battle";
      
      // Determine node type based on level and position
      if (isBossLevel && i === Math.floor(nodesPerLevel / 2)) {
        nodeType = "boss";
      } else if (isRestLevel && (i === 2 || i === 5)) {
        nodeType = "rest";
      } else if (Math.random() < 0.15) {
        nodeType = ["event", "treasure", "shop"][Math.floor(Math.random() * 3)] as NodeType;
      }
      
      // Calculate connections to next level
      const connections: number[] = [];
      if (level < totalLevels - 1) {
        // Connect to 1-3 nodes in the next level
        const nextLevelStart = (level + 1) * nodesPerLevel;
        const numConnections = nodeType === "boss" ? nodesPerLevel : Math.min(3, Math.floor(Math.random() * 3) + 1);
        
        if (nodeType === "boss") {
          // Boss connects to all nodes in next level
          for (let j = 0; j < nodesPerLevel; j++) {
            connections.push(nextLevelStart + j);
          }
        } else {
          // Regular nodes connect to nearby nodes
          const baseConnection = Math.min(i, nodesPerLevel - 2);
          for (let j = 0; j < numConnections; j++) {
            const targetNode = nextLevelStart + Math.min(baseConnection + j, nodesPerLevel - 1);
            if (!connections.includes(targetNode)) {
              connections.push(targetNode);
            }
          }
        }
      }
      
      nodes.push({
        id: nodeId,
        level: level,
        type: nodeType,
        x: (i - (nodesPerLevel - 1) / 2) * 120, // Horizontal spacing
        y: level * 150, // Vertical spacing (climb upward)
        connections,
        completed: level < 3 || (level === 3 && i < 3), // First 3 levels + part of 4th completed
        available: level === 3 && i >= 3 && i <= 5, // Next available nodes
        current: level === 3 && i === 3, // Current position
        name: nodeType === "boss" ? `Boss: Guardian ${Math.floor(level / 10) + 1}` : 
              nodeType === "event" ? "Mysterious Encounter" :
              nodeType === "treasure" ? "Hidden Cache" :
              nodeType === "shop" ? "Merchant" :
              nodeType === "rest" ? "Rest Point" :
              `Battle ${nodeId + 1}`,
        difficulty: level + 1,
        rewards: {
          gold: (level + 1) * (nodeType === "boss" ? 500 : nodeType === "treasure" ? 300 : 100),
          xp: (level + 1) * (nodeType === "boss" ? 200 : 50),
        },
        enemy: nodeType === "battle" || nodeType === "boss" ? {
          name: nodeType === "boss" ? `Mek Guardian ${Math.floor(level / 10) + 1}` : `Wild Mek #${(nodeId * 37 % 1000) + 1}`,
          image: `/mek-images/150px/mek${String((nodeId * 37 % 1000) + 1).padStart(4, '0')}.png`,
          power: (level + 1) * (nodeType === "boss" ? 50 : 10)
        } : undefined
      });
    }
  }
  
  return nodes;
};

// Node icon based on type
const getNodeIcon = (type: NodeType): string => {
  switch (type) {
    case "battle": return "⚔️";
    case "boss": return "👹";
    case "event": return "❓";
    case "treasure": return "💎";
    case "rest": return "🏕️";
    case "shop": return "🛒";
    default: return "🔷";
  }
};

// Node color based on type
const getNodeColor = (type: NodeType): string => {
  switch (type) {
    case "battle": return "from-red-600 to-red-700";
    case "boss": return "from-purple-600 to-pink-600";
    case "event": return "from-blue-600 to-indigo-600";
    case "treasure": return "from-yellow-500 to-amber-600";
    case "rest": return "from-green-600 to-teal-600";
    case "shop": return "from-cyan-600 to-blue-600";
    default: return "from-gray-600 to-gray-700";
  }
};

export default function StoryClimbPage() {
  const router = useRouter();
  const [nodes, setNodes] = useState<StoryNode[]>([]);
  const [selectedNode, setSelectedNode] = useState<StoryNode | null>(null);
  const [currentLevel, setCurrentLevel] = useState(3); // Player's current level
  const [particles, setParticles] = useState<Array<{id: number, left: string, top: string, delay: string, duration: string}>>([]);
  const [stars, setStars] = useState<Array<{id: number, left: string, top: string, size: number, opacity: number, twinkle: boolean}>>([]);
  
  useEffect(() => {
    // Generate the story tree
    const tree = generateChapter1Tree();
    setNodes(tree);
    
    // Find and select the current node
    const current = tree.find(n => n.current);
    if (current) {
      setSelectedNode(current);
    }
    
    // Generate background effects (matching contracts page)
    const generatedParticles = [...Array(20)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      delay: `${Math.random() * 10}s`,
      duration: `${5 + Math.random() * 5}s`,
    }));
    setParticles(generatedParticles);
    
    const generatedStars = [...Array(60)].map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      size: Math.random() * 3 + 0.5,
      opacity: Math.random() * 0.8 + 0.2,
      twinkle: Math.random() > 0.5,
    }));
    setStars(generatedStars);
  }, []);
  
  const handleNodeClick = (node: StoryNode) => {
    if (node.available || node.completed || node.current) {
      setSelectedNode(node);
    }
  };
  
  const handleStartBattle = () => {
    if (selectedNode?.available) {
      // In production, this would start the battle
      console.log("Starting battle at node", selectedNode.id);
      // router.push(`/battle?nodeId=${selectedNode.id}`);
    }
  };
  
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      
      {/* Background Effects (matching contracts page) */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Gradient orbs */}
        <div 
          className="absolute left-0 top-0 w-full h-full"
          style={{
            background: `
              radial-gradient(ellipse at 20% 30%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 70%, rgba(250, 182, 23, 0.15) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 50%, rgba(250, 182, 23, 0.08) 0%, transparent 70%)
            `
          }}
        />
        
        {/* Pattern overlay */}
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 35px,
                rgba(250, 182, 23, 0.03) 35px,
                rgba(250, 182, 23, 0.03) 70px
              )
            `,
          }}
        />
        
        {/* Stars */}
        {stars.map((star) => (
          <div
            key={star.id}
            className="absolute rounded-full bg-white"
            style={{
              left: star.left,
              top: star.top,
              width: `${star.size}px`,
              height: `${star.size}px`,
              opacity: star.opacity,
              animation: star.twinkle ? `starTwinkle ${2 + Math.random() * 2}s ease-in-out infinite` : 'none',
              animationDelay: star.twinkle ? `${Math.random() * 2}s` : '0s',
            }}
          />
        ))}
        
        {/* Floating particles */}
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute w-1.5 h-1.5 bg-yellow-400 rounded-full"
            style={{
              left: particle.left,
              top: particle.top,
              animation: `floatParticle ${particle.duration} ease-in-out infinite`,
              animationDelay: particle.delay,
              boxShadow: '0 0 6px rgba(250, 182, 23, 0.6)',
            }}
          />
        ))}
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        
        {/* Header */}
        <div className="flex-shrink-0 bg-black/90 backdrop-blur-md border-b border-gray-800 p-4">
          <div className="flex items-center justify-between max-w-7xl mx-auto">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push('/scrap-yard')}
                className="px-4 py-2 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-yellow-400 rounded-lg transition-all text-gray-400 hover:text-white group"
              >
                <span className="mr-2 group-hover:translate-x--1 inline-block transition-transform">←</span>
                Back
              </button>
              <div>
                <h1 
                  style={{
                    fontFamily: "'Orbitron', 'Rajdhani', 'Bebas Neue', sans-serif",
                    fontSize: '28px',
                    fontWeight: '900',
                    letterSpacing: '1px',
                    textShadow: '0 0 30px rgba(250, 182, 23, 0.6)',
                    background: 'linear-gradient(135deg, #fab617 0%, #ffdd00 50%, #fab617 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                  }}
                >
                  CHAPTER 1: THE ASCENT
                </h1>
                <p className="text-gray-400 text-sm">Level {currentLevel + 1} of 50</p>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="flex items-center gap-6">
              <div className="w-64 h-3 bg-gray-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600 transition-all duration-500"
                  style={{ width: `${((currentLevel + 1) / 50) * 100}%` }}
                />
              </div>
              <div className="text-yellow-400 font-bold">
                {Math.floor(((currentLevel + 1) / 50) * 100)}% Complete
              </div>
            </div>
          </div>
        </div>
        
        {/* Story Content */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-6xl mx-auto w-full">
            
            {/* Title */}
            <div className="text-center mb-12">
              <h2
                style={{
                  fontFamily: "'Orbitron', 'Rajdhani', 'Bebas Neue', sans-serif",
                  fontSize: '48px',
                  fontWeight: '900',
                  letterSpacing: '2px',
                  textShadow: '0 0 30px rgba(250, 182, 23, 0.6)',
                  background: 'linear-gradient(135deg, #fab617 0%, #ffdd00 50%, #fab617 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  marginBottom: '16px'
                }}
              >
                STORY CLIMB
              </h2>
              <p className="text-gray-400 text-lg">Navigate through {nodes.length} story nodes</p>
            </div>
            
            {/* Node Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 px-4 max-h-96 overflow-y-auto" style={{ scrollbarWidth: 'thin' }}>
              {/* Display current level nodes */}
              {nodes.filter(node => 
                node.level >= Math.max(0, currentLevel - 2) && 
                node.level <= currentLevel + 5
              ).map(node => {
                const isSelected = selectedNode?.id === node.id;
                const canInteract = node.completed || node.available || node.current;
                
                return (
                  <div
                    key={node.id}
                    className={`relative group cursor-pointer transform transition-all duration-300 ${
                      canInteract ? 'hover:scale-105' : 'cursor-not-allowed opacity-50'
                    }`}
                    onClick={() => handleNodeClick(node)}
                  >
                    <div 
                      className="relative rounded-xl overflow-hidden p-6 h-48"
                      style={{
                        background: isSelected 
                          ? 'linear-gradient(135deg, #2a2a2a 0%, #3a3a3a 50%, #2a2a2a 100%)'
                          : 'linear-gradient(135deg, #1a1a1a 0%, #2a2a2a 50%, #1a1a1a 100%)',
                        border: '2px solid',
                        borderColor: isSelected ? '#fab617' : canInteract ? '#666' : '#333',
                        boxShadow: isSelected 
                          ? '0 0 40px rgba(250, 182, 23, 0.6)' 
                          : canInteract ? '0 0 20px rgba(250, 182, 23, 0.2)' : 'none',
                        transition: 'all 0.3s ease',
                      }}
                    >
                      {/* Animated border glow */}
                      {isSelected && (
                        <div 
                          className="absolute inset-0 opacity-30 pointer-events-none"
                          style={{
                            background: 'linear-gradient(105deg, transparent 40%, rgba(250, 182, 23, 0.3) 50%, transparent 60%)',
                            animation: 'shimmer 2s infinite',
                          }}
                        />
                      )}
                      
                      <div className="relative z-10 h-full flex flex-col">
                        {/* Node Icon */}
                        <div className="text-4xl mb-3 text-center">{getNodeIcon(node.type)}</div>
                        
                        {/* Node Info */}
                        <h3 
                          className="text-lg font-bold mb-2 text-center"
                          style={{
                            fontFamily: "'Orbitron', sans-serif",
                            color: isSelected ? '#fab617' : canInteract ? '#fff' : '#666',
                            textShadow: isSelected ? '0 0 20px rgba(250, 182, 23, 0.6)' : 'none',
                          }}
                        >
                          {node.name}
                        </h3>
                        
                        <p className="text-gray-400 text-sm text-center mb-3 flex-grow">
                          Level {node.level + 1} • {node.type.charAt(0).toUpperCase() + node.type.slice(1)}
                        </p>
                        
                        {/* Status Indicators */}
                        <div className="flex justify-center">
                          {node.completed && (
                            <span className="px-2 py-1 bg-green-600/20 text-green-400 rounded-full text-xs font-bold">
                              ✓ Done
                            </span>
                          )}
                          {node.current && (
                            <span className="px-2 py-1 bg-blue-600/20 text-blue-400 rounded-full text-xs font-bold animate-pulse">
                              Current
                            </span>
                          )}
                          {node.available && !node.current && (
                            <span className="px-2 py-1 bg-yellow-600/20 text-yellow-400 rounded-full text-xs font-bold">
                              Available
                            </span>
                          )}
                          {!node.completed && !node.available && !node.current && (
                            <span className="px-2 py-1 bg-gray-600/20 text-gray-400 rounded-full text-xs font-bold">
                              Locked
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Selected Node Details */}
            {selectedNode && (
              <div className="mt-8 bg-gray-900/50 backdrop-blur-md border border-gray-800 rounded-lg p-6 max-w-2xl mx-auto">
                <div className="space-y-6">
                  {/* Node Header */}
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-3xl">{getNodeIcon(selectedNode.type)}</span>
                      <div>
                        <h2 className="text-xl font-bold text-yellow-400">
                          {selectedNode.name}
                        </h2>
                        <p className="text-gray-400 text-sm">
                          Level {selectedNode.level + 1} • Node #{selectedNode.id + 1}
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Enemy Preview (for battle/boss nodes) */}
                  {selectedNode.enemy && (
                    <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">ENEMY</h3>
                      <div className="flex items-center gap-4">
                        <div className="w-20 h-20 bg-gray-900 rounded-lg overflow-hidden">
                          <Image
                            src={selectedNode.enemy.image}
                            alt={selectedNode.enemy.name}
                            width={80}
                            height={80}
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-bold text-white">{selectedNode.enemy.name}</p>
                          <p className="text-sm text-gray-400">Power: {selectedNode.enemy.power}</p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Rewards */}
                  {selectedNode.rewards && (
                    <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">REWARDS</h3>
                      <div className="space-y-2">
                        {selectedNode.rewards.gold && (
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Gold</span>
                            <span className="text-yellow-400 font-bold">
                              {selectedNode.rewards.gold.toLocaleString()}
                            </span>
                          </div>
                        )}
                        {selectedNode.rewards.xp && (
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Experience</span>
                            <span className="text-blue-400 font-bold">
                              +{selectedNode.rewards.xp} XP
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Node Status */}
                  <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                    <h3 className="text-sm font-bold text-gray-400 mb-3">STATUS</h3>
                    <div className="flex items-center gap-2">
                      {selectedNode.completed && (
                        <span className="px-3 py-1 bg-green-600/20 text-green-400 rounded-full text-sm font-bold">
                          ✓ Completed
                        </span>
                      )}
                      {selectedNode.current && (
                        <span className="px-3 py-1 bg-blue-600/20 text-blue-400 rounded-full text-sm font-bold animate-pulse">
                          Current Position
                        </span>
                      )}
                      {selectedNode.available && !selectedNode.current && (
                        <span className="px-3 py-1 bg-yellow-600/20 text-yellow-400 rounded-full text-sm font-bold">
                          Available
                        </span>
                      )}
                      {!selectedNode.completed && !selectedNode.available && !selectedNode.current && (
                        <span className="px-3 py-1 bg-gray-600/20 text-gray-400 rounded-full text-sm font-bold">
                          Locked
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Action Button */}
                  {selectedNode.available && !selectedNode.current && (
                    <button
                      onClick={handleStartBattle}
                      className="w-full py-3 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-black font-bold rounded-lg transition-all transform hover:scale-105"
                    >
                      {selectedNode.type === "battle" || selectedNode.type === "boss" ? "Start Battle" :
                       selectedNode.type === "shop" ? "Visit Shop" :
                       selectedNode.type === "rest" ? "Rest Here" :
                       selectedNode.type === "event" ? "Investigate" :
                       selectedNode.type === "treasure" ? "Open Treasure" :
                       "Enter Node"}
                    </button>
                  )}
                  
                  {/* Path Connections */}
                  {selectedNode.connections.length > 0 && (
                    <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
                      <h3 className="text-sm font-bold text-gray-400 mb-3">
                        PATHS ({selectedNode.connections.length})
                      </h3>
                      <div className="space-y-2">
                        {selectedNode.connections.map(connId => {
                          const connNode = nodes.find(n => n.id === connId);
                          if (!connNode) return null;
                          return (
                            <div 
                              key={connId}
                              className="flex items-center gap-2 text-sm cursor-pointer hover:text-yellow-400 transition-colors"
                              onClick={() => handleNodeClick(connNode)}
                            >
                              <span>{getNodeIcon(connNode.type)}</span>
                              <span>{connNode.name}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}