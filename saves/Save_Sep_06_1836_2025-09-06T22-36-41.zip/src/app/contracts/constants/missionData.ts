export const successMultipliers = {
  common: [
    { id: "sword", name: "Sword", image: "/item-images/sword.png", bonus: "+5%", rarity: "common" as const },
    { id: "plating", name: "Plating", image: "/item-images/plating.png", bonus: "+10%", rarity: "common" as const },
    { id: "energy", name: "Energy", image: "/item-images/energy.png", bonus: "+5%", rarity: "common" as const },
    { id: "circuit", name: "Circuit", image: "/item-images/circuit.png", bonus: "+10%", rarity: "common" as const },
    { id: "crystal", name: "Crystal", image: "/item-images/crystal.png", bonus: "+10%", rarity: "common" as const },
    { id: "relic", name: "Relic", image: "/item-images/relic.png", bonus: "+15%", rarity: "common" as const },
  ],
  uncommon: [
    { id: "shield", name: "Shield", image: "/item-images/shield.png", bonus: "+10%", rarity: "uncommon" as const },
    { id: "carbon", name: "Carbon", image: "/item-images/carbon.png", bonus: "+10%", rarity: "uncommon" as const },
    { id: "fragment", name: "Fragment", image: "/item-images/fragment.png", bonus: "+15%", rarity: "uncommon" as const },
    { id: "quantum", name: "Quantum", image: "/item-images/quantum.png", bonus: "+15%", rarity: "uncommon" as const },
    { id: "dark", name: "Dark", image: "/item-images/dark.png", bonus: "+20%", rarity: "uncommon" as const },
  ],
  rare: [
    { id: "celestial", name: "Celestial", image: "/item-images/celestial.png", bonus: "+20%", rarity: "rare" as const },
    { id: "singularity", name: "Singularity", image: "/item-images/singularity.png", bonus: "+25%", rarity: "rare" as const },
    { id: "void", name: "Void", image: "/item-images/void.png", bonus: "+25%", rarity: "rare" as const },
    { id: "essence", name: "Essence", image: "/item-images/essence.png", bonus: "+20%", rarity: "rare" as const },
    { id: "prism", name: "Prism", image: "/item-images/prism.png", bonus: "+30%", rarity: "rare" as const },
    { id: "nexus", name: "Nexus", image: "/item-images/nexus.png", bonus: "+25%", rarity: "rare" as const },
  ],
  legendary: [
    { id: "infinity", name: "Infinity", image: "/item-images/infinity.png", bonus: "+35%", rarity: "legendary" as const },
    { id: "omega", name: "Omega", image: "/item-images/omega.png", bonus: "+40%", rarity: "legendary" as const },
    { id: "genesis", name: "Genesis", image: "/item-images/genesis.png", bonus: "+50%", rarity: "legendary" as const },
  ],
};

export const sampleRewardsWithRates = {
  common: [
    { name: "Basic Scrap", dropChance: 100, amount: "5-10" },
    { name: "Common Ore", dropChance: 75, amount: "3-5" },
    { name: "Energy Cell", dropChance: 50, amount: "1-3" },
  ],
  uncommon: [
    { name: "Rare Metal", dropChance: 30, amount: "1-2" },
    { name: "Circuit Board", dropChance: 25, amount: "1" },
  ],
  rare: [
    { name: "Quantum Core", dropChance: 10, amount: "1" },
    { name: "Plasma Crystal", dropChance: 5, amount: "1" },
  ],
  legendary: [
    { name: "Void Essence", dropChance: 1, amount: "1" },
  ],
};

export const missionAilments = {
  fire: { name: "Inferno", icon: "🔥", counters: ["water", "ice", "shield"] },
  poison: { name: "Toxic", icon: "☠️", counters: ["heal", "purify", "antidote"] },
  electric: { name: "Shock", icon: "⚡", counters: ["ground", "insulate", "rubber"] },
  freeze: { name: "Cryo", icon: "❄️", counters: ["fire", "heat", "thaw"] },
  psychic: { name: "Mind", icon: "🧠", counters: ["focus", "clarity", "will"] },
  void: { name: "Null", icon: "⚫", counters: ["light", "energy", "matter"] },
  radiation: { name: "Rad", icon: "☢️", counters: ["lead", "shield", "decontaminate"] },
  gravity: { name: "Grav", icon: "🌌", counters: ["anti-grav", "levitate", "repulse"] },
  temporal: { name: "Time", icon: "⏳", counters: ["stabilize", "anchor", "chronos"] },
};

export const missionWeaknesses = ["fire", "poison", "electric"];

export const variations = [
  "sword", "shield", "plating", "energy", "circuit", "relic", "crystal", "carbon", 
  "fragment", "quantum", "dark", "celestial", "singularity", "void", "essence", 
  "prism", "nexus", "infinity", "omega", "genesis"
];

export const styles = [
  "Warrior", "Guardian", "Technician", "Mystic", "Ranger", "Berserker", 
  "Sage", "Assassin", "Paladin", "Architect"
];

export const globalMissionTypes = [
  "Acid", "Radioactive", "Electromagnetic", "Plasma", "Quantum", "Temporal",
  "Dimensional", "Gravitational", "Viral", "Nano", "Crystal", "Shadow",
  "Solar", "Lunar", "Void", "Chaos", "Neural", "Frost", "Inferno", "Storm"
];

export const regularMissionTitles = [
  "Resource Extraction Alpha", "Perimeter Defense Omega", "Supply Run Delta",
  "Research Station Protection", "Artifact Recovery", "System Diagnostics",
  "Energy Core Stabilization", "Communications Relay Repair", "Scout Mission Theta",
  "Mining Operation Guard", "Transport Escort Service", "Laboratory Defense",
  "Power Grid Maintenance", "Security Patrol Epsilon", "Data Recovery Mission"
];