import LayoutOption11 from '../layout-option-11';

export default function SingleMissionsPage() {
  return <LayoutOption11 />;
}