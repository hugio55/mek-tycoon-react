export const formatGoldAmount = (amount: number): string => {
  if (amount >= 1000000) {
    return `${(amount / 1000000).toFixed(1)}M`;
  } else if (amount >= 1000) {
    return `${(amount / 1000).toFixed(0)}K`;
  }
  return amount.toLocaleString();
};

export const formatCountdown = (endTime: number): string => {
  const now = Date.now();
  const diff = endTime - now;
  
  if (diff <= 0) return "Expired";
  
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  } else if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  } else {
    return `${seconds}s`;
  }
};

export const getRewardColor = (dropChance: number): string => {
  if (dropChance >= 75) return "text-green-400";
  if (dropChance >= 50) return "text-blue-400";
  if (dropChance >= 25) return "text-purple-400";
  if (dropChance >= 10) return "text-yellow-400";
  return "text-orange-400";
};

export const generateSampleMeks = (count: number) => {
  const variations = [
    "sword", "shield", "plating", "energy", "circuit", "relic", "crystal", "carbon", 
    "fragment", "quantum", "dark", "celestial", "singularity", "void", "essence", 
    "prism", "nexus", "infinity", "omega", "genesis"
  ];
  
  const styles = [
    "Warrior", "Guardian", "Technician", "Mystic", "Ranger", "Berserker", 
    "Sage", "Assassin", "Paladin", "Architect"
  ];

  return Array.from({ length: count }, (_, i) => {
    const mekImageNumber = (i % 1000) + 1;
    const variationIndices = [(i * 7) % variations.length, (i * 13) % variations.length, (i * 23) % variations.length];
    const styleIndex = i % styles.length;
    
    return {
      id: `mek-${i}`,
      name: `Mek #${mekImageNumber}`,
      style: styles[styleIndex],
      image: `/mek-images/150px/mek${String(mekImageNumber).padStart(4, '0')}.png`,
      traits: variationIndices.map(idx => variations[idx]),
      power: 50 + ((i * 37) % 100),
      level: Math.floor(Math.random() * 50) + 1,
      rarity: i < count * 0.05 ? "legendary" : i < count * 0.15 ? "rare" : i < count * 0.4 ? "uncommon" : "common",
    };
  });
};