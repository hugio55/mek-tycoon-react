import SingleMissions from '../single-missions';

export default function SingleMissionsPage() {
  return <SingleMissions />;
}