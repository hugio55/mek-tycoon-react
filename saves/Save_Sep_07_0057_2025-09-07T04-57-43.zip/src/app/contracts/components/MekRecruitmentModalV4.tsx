'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { successMultipliers } from '../constants/missionData';
import { generateSampleMeks } from '../utils/helpers';
import ModalPortal from './ModalPortal';

interface MekRecruitmentModalV4Props {
  showMekModal: string | null;
  selectedMekSlot: { missionId: string; slotIndex: number } | null;
  onClose: () => void;
  onMekSelection: (mek: any, matchedTraits: any[], hasMatch: boolean) => void;
  mekCount: number;
  mekCardStyle: number;
  traitCircleStyle: number;
  mekFrameStyle: number;
}

// 5 UI Style Variations
const uiStyles = {
  minimal: {
    name: "Minimal Clean",
    borderWidth: "border",
    borderColor: "border-gray-600",
    matchBorderColor: "border-yellow-400",
    matchBorderWidth: "border",
    bgCard: "bg-gray-950",
    bgCardMatch: "bg-gray-900",
    chipBg: "bg-gray-800",
    chipBgMatch: "bg-yellow-400",
    spacing: "gap-3",
  },
  thin: {
    name: "Thin Lines",
    borderWidth: "border",
    borderColor: "border-gray-700/50",
    matchBorderColor: "border-yellow-400/70",
    matchBorderWidth: "border",
    bgCard: "bg-black",
    bgCardMatch: "bg-black",
    chipBg: "bg-gray-900",
    chipBgMatch: "bg-yellow-500",
    spacing: "gap-2",
  },
  thick: {
    name: "Bold Frames",
    borderWidth: "border-2",
    borderColor: "border-gray-700",
    matchBorderColor: "border-yellow-400",
    matchBorderWidth: "border-4",
    bgCard: "bg-gray-950",
    bgCardMatch: "bg-gray-900",
    chipBg: "bg-gray-800",
    chipBgMatch: "bg-yellow-400",
    spacing: "gap-4",
  },
  gradient: {
    name: "Gradient Borders",
    borderWidth: "border",
    borderColor: "border-gray-700/50",
    matchBorderColor: "border-gray-600",
    matchBorderWidth: "border-2",
    bgCard: "bg-gradient-to-br from-gray-950 to-black",
    bgCardMatch: "bg-gradient-to-br from-yellow-950/20 to-black",
    chipBg: "bg-gray-800",
    chipBgMatch: "bg-gradient-to-br from-yellow-400 to-yellow-600",
    spacing: "gap-3",
  },
  double: {
    name: "Double Lines",
    borderWidth: "ring-1 ring-gray-600",
    borderColor: "border border-gray-800",
    matchBorderColor: "border-yellow-400 ring-yellow-500",
    matchBorderWidth: "border ring-2",
    bgCard: "bg-black",
    bgCardMatch: "bg-black",
    chipBg: "bg-gray-900",
    chipBgMatch: "bg-yellow-400",
    spacing: "gap-4",
  },
};

export default function MekRecruitmentModalV4({
  showMekModal,
  selectedMekSlot,
  onClose,
  onMekSelection,
  mekCount,
}: MekRecruitmentModalV4Props) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeBuffFilters, setActiveBuffFilters] = useState<string[]>([]);
  const [showOnlyMatches, setShowOnlyMatches] = useState(false);
  const [allMeks] = useState(() => generateSampleMeks(mekCount));
  const [hoveredMekIndex, setHoveredMekIndex] = useState<number | null>(null);
  const [hoveredVariation, setHoveredVariation] = useState<string | null>(null);
  const [currentStyle, setCurrentStyle] = useState<keyof typeof uiStyles>('gradient');
  const [variationCount, setVariationCount] = useState<1 | 5 | 10>(10);

  if (!showMekModal || !selectedMekSlot) return null;

  const style = uiStyles[currentStyle];
  const missionId = selectedMekSlot.missionId;
  const isGlobal = missionId === 'global';
  
  // Variable variation count (1, 5, or 10)
  const missionMultipliers = successMultipliers.slice(0, variationCount);

  const toggleBuffFilter = (buffId: string) => {
    setActiveBuffFilters(prev => 
      prev.includes(buffId) 
        ? prev.filter(id => id !== buffId)
        : [...prev, buffId]
    );
  };

  // Filter meks
  const filteredMeks = allMeks.filter(mek => {
    if (activeBuffFilters.length > 0) {
      const hasFilteredBuff = mek.traits.some((trait: string) => 
        activeBuffFilters.includes(trait)
      );
      if (!hasFilteredBuff) return false;
    }
    
    if (searchTerm) {
      const query = searchTerm.toLowerCase();
      const matchesNumber = mek.name.toLowerCase().includes(query);
      const matchesStyle = mek.style.toLowerCase().includes(query);
      const matchesVariation = mek.traits.some((t: string) => t.toLowerCase().includes(query));
      
      if (!matchesNumber && !matchesStyle && !matchesVariation) return false;
    }
    
    return true;
  });

  const displayMeks = filteredMeks.map((mek: any, index: number) => {
    const matchedTraits = mek.traits.filter((t: string) => 
      missionMultipliers.some(m => m.id === t)
    ).map((t: string) => missionMultipliers.find(m => m.id === t));
    
    const hasMatch = matchedTraits.length > 0;
    const totalBonus = matchedTraits.reduce((sum: number, trait: any) => 
      sum + parseInt(trait?.bonus?.replace('+', '').replace('%', '') || '0'), 0
    );
    
    if (showOnlyMatches && !hasMatch) return null;
    
    return { mek, matchedTraits, hasMatch, totalBonus, index };
  }).filter(Boolean);

  // Sort matched meks first
  displayMeks.sort((a: any, b: any) => {
    if (a.hasMatch && !b.hasMatch) return -1;
    if (!a.hasMatch && b.hasMatch) return 1;
    return b.totalBonus - a.totalBonus;
  });

  return (
    <ModalPortal>
      <div 
        className="fixed inset-0 bg-black/95 backdrop-blur-sm z-[9999] flex items-center justify-center"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <div 
          className="w-full max-w-7xl mx-4 my-8 bg-black border-2 border-yellow-400/50 shadow-2xl"
          style={{ minWidth: '900px', maxHeight: '85vh' }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header with black/yellow stripes */}
          <div className="bg-black p-4">
            <div 
              className="p-1"
              style={{
                background: `repeating-linear-gradient(
                  45deg,
                  #000,
                  #000 10px,
                  #fab617 10px,
                  #fab617 20px
                )`
              }}
            >
              <div className="bg-black p-3">
              <div className="flex justify-between items-center">
                <div style={{ maxWidth: '500px' }}>
                  <h2 className="text-2xl font-black text-yellow-400 tracking-wider" 
                      style={{ fontFamily: "'Orbitron', 'Bebas Neue', sans-serif" }}>
                    MEK RECRUITMENT INTERFACE
                  </h2>
                  <p className="text-gray-400 text-sm mt-1">
                    {displayMeks.filter((m: any) => m.hasMatch).length} MATCHES FOUND | {displayMeks.length} TOTAL MEKS
                  </p>
                  <p className="text-gray-300 text-xs mt-2">
                    Select a Mek from your collection to assign to this contract slot. Meks with matching variation buffs 
                    <span className="text-yellow-400 font-bold"> increase success chance</span>. 
                    Power chips below each Mek indicate: 
                    <span className="text-yellow-400"> ● Active</span>,
                    <span className="text-gray-500"> ● Buffed</span>,
                    <span className="text-gray-600"> ● Empty</span>.
                  </p>
                </div>
                
                {/* UI Style and Variation Count Selectors */}
                <div className="flex items-center gap-4">
                  <select
                    value={variationCount}
                    onChange={(e) => setVariationCount(Number(e.target.value) as 1 | 5 | 10)}
                    className="bg-black border border-yellow-400/50 text-yellow-400 px-3 py-1 text-sm"
                  >
                    <option value={1}>1 Variation</option>
                    <option value={5}>5 Variations</option>
                    <option value={10}>10 Variations</option>
                  </select>
                  
                  <select
                    value={currentStyle}
                    onChange={(e) => setCurrentStyle(e.target.value as keyof typeof uiStyles)}
                    className="bg-black border border-yellow-400/50 text-yellow-400 px-3 py-1 text-sm"
                  >
                    {Object.entries(uiStyles).map(([key, style]) => (
                      <option key={key} value={key}>{style.name}</option>
                    ))}
                  </select>
                  
                  <button 
                    onClick={onClose} 
                    className="w-10 h-10 bg-red-900/50 hover:bg-red-600 border border-red-500 text-white transition-all flex items-center justify-center"
                  >
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="square" strokeLinejoin="miter" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

          {/* Scrollable Content */}
          <div className="overflow-y-auto" style={{ maxHeight: 'calc(85vh - 120px)' }}>

            {/* Variation Bubbles - Full width with translucent frame */}
            <div className="p-4 mx-4 my-2 bg-gradient-to-b from-gray-900/20 to-black/30 border border-gray-700/30 backdrop-blur-sm">
              <div className="flex justify-center">
                <div className={`grid ${variationCount === 1 ? 'grid-cols-1' : variationCount === 5 ? 'grid-cols-5' : 'grid-cols-10'} gap-4 w-full max-w-6xl`}>
                  {missionMultipliers.map((mult) => {
                    const isActive = activeBuffFilters.includes(mult.id);
                    const isHovered = hoveredVariation === mult.id;
                    
                    return (
                      <button
                        key={mult.id}
                        onClick={() => toggleBuffFilter(mult.id)}
                        className="group transition-all hover:scale-110"
                      >
                        <div className="flex flex-col items-center">
                          <div className={`
                            relative w-[90px] h-[90px] rounded-full bg-black/60 border-2 overflow-hidden
                            ${isActive || isHovered ? 'border-yellow-400 shadow-lg shadow-yellow-400/30' : 'border-gray-700'}
                            transition-all
                          `}>
                            <Image
                              src="/variation-images/acid.jpg"
                              alt={mult.id}
                              fill
                              className="rounded-full object-cover"
                              sizes="90px"
                            />
                          </div>
                          <div className={`text-xs font-medium mt-1 ${isActive || isHovered ? 'text-white' : 'text-gray-400'} uppercase tracking-wider text-center`}>
                            {mult.name}
                          </div>
                          <div className={`text-sm font-bold ${isActive || isHovered ? 'text-yellow-400' : 'text-gray-500'}`}>
                            {mult.bonus}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Search Bar - Above mek grid, narrower */}
            <div className="px-6 pb-2">
              <div className="flex justify-center gap-2">
                <input
                  type="text"
                  placeholder="Search meks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-80 bg-gray-900/80 border border-gray-700 text-yellow-400 px-3 py-2 text-sm focus:border-yellow-500 focus:outline-none"
                />
                <button
                  onClick={() => setShowOnlyMatches(!showOnlyMatches)}
                  className={`px-4 py-2 text-sm font-medium transition-all ${
                    showOnlyMatches 
                      ? 'bg-yellow-500 text-black' 
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  Show Matches Only
                </button>
              </div>
            </div>

            {/* Mek Grid */}
            <div className="p-6">
              <div className={`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 ${style.spacing}`}>
                {displayMeks.map(({ mek, matchedTraits, hasMatch, totalBonus, index }: any) => (
                  <div
                    key={mek.name}
                    onClick={() => onMekSelection(mek, matchedTraits, hasMatch)}
                    onMouseEnter={() => {
                      setHoveredMekIndex(index);
                      if (matchedTraits.length > 0) {
                        setHoveredVariation(matchedTraits[0].id);
                      }
                    }}
                    onMouseLeave={() => {
                      setHoveredMekIndex(null);
                      setHoveredVariation(null);
                    }}
                    className={`
                      relative cursor-pointer transition-all duration-200
                      ${hasMatch 
                        ? `${style.bgCardMatch} ${style.matchBorderWidth} ${style.matchBorderColor} shadow-lg scale-105 z-10` 
                        : `${style.bgCard} ${style.borderWidth} ${style.borderColor} opacity-75 hover:opacity-100`
                      }
                      hover:scale-110 hover:z-20
                    `}
                    style={{ minWidth: '180px' }}
                  >
                    {/* Mek Image - No yellow gradient overlay */}
                    <div className="relative w-full aspect-square bg-black/50 overflow-hidden">
                      <Image
                        src={mek.image}
                        alt={mek.name}
                        width={200}
                        height={200}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    {/* Mek Info */}
                    <div className="p-2 bg-black/80">
                      <div className="flex justify-between items-center mb-2 px-1">
                        <span className={`text-sm font-bold ${hasMatch ? 'text-yellow-400' : 'text-gray-400'}`}>
                          {mek.name}
                        </span>
                        <span className="text-white text-sm font-bold">Lv.{mek.level || 1}</span>
                      </div>
                      
                      {/* Bottom row with boost and chips */}
                      <div className="flex items-center justify-between">
                        {/* Boost indicator on left */}
                        {hasMatch ? (
                          <div className="text-yellow-400 font-light" style={{ fontFamily: "'Helvetica Neue', 'Arial', sans-serif", fontSize: '14px', fontWeight: 300 }}>
                            +{totalBonus}%
                          </div>
                        ) : (
                          <div />
                        )}
                        
                        {/* Chip Slots with images - centered and bigger */}
                        <div className="flex gap-1 justify-center">
                          {mek.traits.slice(0, 3).map((trait: string, i: number) => {
                            const isMatched = matchedTraits.some((mt: any) => mt?.id === trait);
                            const traitData = successMultipliers.find(m => m.id === trait);
                            
                            return (
                              <div 
                                key={i}
                                className="relative group"
                              >
                                <div className={`
                                  w-10 h-10 rounded-full border-2 overflow-hidden
                                  ${isMatched 
                                    ? `bg-yellow-400 border-yellow-600` 
                                    : `bg-gray-800 border-gray-700`
                                  }
                                `}>
                                  <Image
                                    src="/variation-images/acid.jpg"
                                    alt={trait}
                                    width={40}
                                    height={40}
                                    className="w-full h-full object-cover rounded-full"
                                  />
                                </div>
                                
                                {/* Tooltip on hover */}
                                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-black border border-yellow-400 text-yellow-400 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none z-50">
                                  {trait}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
}