import ContractsLayoutOption2 from '../layout-option-2';

export default function LayoutOption2Page() {
  return <ContractsLayoutOption2 />;
}