import ContractsLayoutOption5 from '../layout-option-5';

export default function LayoutOption5Page() {
  return <ContractsLayoutOption5 />;
}