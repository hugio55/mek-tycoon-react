import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { Id } from "./_generated/dataModel";

// Create a new chip definition
export const createChipDefinition = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    category: v.union(
      v.literal("attack"),
      v.literal("defense"),
      v.literal("utility"),
      v.literal("economy"),
      v.literal("special")
    ),
    tier: v.number(), // 1-7
    imageUrl: v.optional(v.string()),
    possibleBuffs: v.array(v.object({
      buffType: v.string(),
      minValue: v.number(),
      maxValue: v.number(),
      weight: v.number(),
    })),
    rankScaling: v.record(v.string(), v.object({
      buffMultiplier: v.number(),
      rollChances: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    const chipId = await ctx.db.insert("chipDefinitions", {
      ...args,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
    return chipId;
  },
});

// Update an existing chip definition
export const updateChipDefinition = mutation({
  args: {
    id: v.id("chipDefinitions"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    category: v.optional(v.union(
      v.literal("attack"),
      v.literal("defense"),
      v.literal("utility"),
      v.literal("economy"),
      v.literal("special")
    )),
    tier: v.optional(v.number()),
    imageUrl: v.optional(v.string()),
    possibleBuffs: v.optional(v.array(v.object({
      buffType: v.string(),
      minValue: v.number(),
      maxValue: v.number(),
      weight: v.number(),
    }))),
    rankScaling: v.optional(v.record(v.string(), v.object({
      buffMultiplier: v.number(),
      rollChances: v.number(),
    }))),
  },
  handler: async (ctx, args) => {
    const { id, ...updates } = args;
    await ctx.db.patch(id, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

// Delete a chip definition
export const deleteChipDefinition = mutation({
  args: {
    id: v.id("chipDefinitions"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.id);
  },
});

// Get all chip definitions
export const getAllChipDefinitions = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("chipDefinitions").collect();
  },
});

// Get chip definitions by tier
export const getChipDefinitionsByTier = query({
  args: {
    tier: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("chipDefinitions")
      .filter((q) => q.eq(q.field("tier"), args.tier))
      .collect();
  },
});

// Get chip definitions by category
export const getChipDefinitionsByCategory = query({
  args: {
    category: v.union(
      v.literal("attack"),
      v.literal("defense"),
      v.literal("utility"),
      v.literal("economy"),
      v.literal("special")
    ),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("chipDefinitions")
      .filter((q) => q.eq(q.field("category"), args.category))
      .collect();
  },
});

// Create a chip instance for a user (when they craft/obtain a chip)
export const createChipInstance = mutation({
  args: {
    userId: v.id("users"),
    chipDefinitionId: v.id("chipDefinitions"),
    rank: v.string(), // D, C, B, A, S, SS, SSS, X, XX, XXX
    rolledBuffs: v.array(v.object({
      buffType: v.string(),
      value: v.number(),
    })),
  },
  handler: async (ctx, args) => {
    const instanceId = await ctx.db.insert("chipInstances", {
      ...args,
      equipped: false,
      equippedToMek: undefined,
      createdAt: Date.now(),
    });
    return instanceId;
  },
});

// Equip a chip to a Mek
export const equipChip = mutation({
  args: {
    chipInstanceId: v.id("chipInstances"),
    mekId: v.id("meks"),
    slot: v.number(), // Slot number (1-3 for example)
  },
  handler: async (ctx, args) => {
    // First, unequip any chip currently in this slot
    const existingChips = await ctx.db
      .query("chipInstances")
      .filter((q) => 
        q.and(
          q.eq(q.field("equippedToMek"), args.mekId),
          q.eq(q.field("equipmentSlot"), args.slot)
        )
      )
      .collect();
    
    for (const chip of existingChips) {
      await ctx.db.patch(chip._id, {
        equipped: false,
        equippedToMek: undefined,
        equipmentSlot: undefined,
      });
    }
    
    // Now equip the new chip
    await ctx.db.patch(args.chipInstanceId, {
      equipped: true,
      equippedToMek: args.mekId,
      equipmentSlot: args.slot,
    });
  },
});

// Unequip a chip
export const unequipChip = mutation({
  args: {
    chipInstanceId: v.id("chipInstances"),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.chipInstanceId, {
      equipped: false,
      equippedToMek: undefined,
      equipmentSlot: undefined,
    });
  },
});

// Get all chips owned by a user
export const getUserChips = query({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const chips = await ctx.db
      .query("chipInstances")
      .filter((q) => q.eq(q.field("userId"), args.userId))
      .collect();
    
    // Fetch the definitions for each chip
    const chipsWithDefinitions = await Promise.all(
      chips.map(async (chip) => {
        const definition = await ctx.db.get(chip.chipDefinitionId);
        return {
          ...chip,
          definition,
        };
      })
    );
    
    return chipsWithDefinitions;
  },
});

// Get chips equipped to a specific Mek
export const getMekChips = query({
  args: {
    mekId: v.id("meks"),
  },
  handler: async (ctx, args) => {
    const chips = await ctx.db
      .query("chipInstances")
      .filter((q) => q.eq(q.field("equippedToMek"), args.mekId))
      .collect();
    
    // Fetch the definitions for each chip
    const chipsWithDefinitions = await Promise.all(
      chips.map(async (chip) => {
        const definition = await ctx.db.get(chip.chipDefinitionId);
        return {
          ...chip,
          definition,
        };
      })
    );
    
    return chipsWithDefinitions.sort((a, b) => 
      (a.equipmentSlot || 0) - (b.equipmentSlot || 0)
    );
  },
});

// Destroy/sell a chip instance
export const destroyChip = mutation({
  args: {
    chipInstanceId: v.id("chipInstances"),
  },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.chipInstanceId);
  },
});

// Seed function to populate chip definitions
export const seedChipDefinitions = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if chips already exist
    const existingChips = await ctx.db.query("chipDefinitions").collect();
    if (existingChips.length > 0) {
      return { message: "Chip definitions already exist", count: existingChips.length };
    }

    // Initial chip definitions with proper categorization
    const chipDefinitions = [
      // Attack Chips (T1-T7)
      { name: "Acid Chip", category: "attack" as const, tier: 3, imageUrl: "/chips/Acid.webp", description: "Corrosive damage over time" },
      { name: "Blasters", category: "attack" as const, tier: 2, imageUrl: "/chips/Blasters.webp", description: "Rapid fire energy blasts" },
      { name: "Cannon", category: "attack" as const, tier: 4, imageUrl: "/chips/Cannon.webp", description: "Heavy impact damage" },
      { name: "Cannon Ultimate", category: "attack" as const, tier: 6, imageUrl: "/chips/Cannon Ultimate.webp", description: "Devastating cannon barrage" },
      { name: "Lightning", category: "attack" as const, tier: 5, imageUrl: "/chips/Lightning.webp", description: "Chain lightning strikes" },
      { name: "Nuclear", category: "attack" as const, tier: 7, imageUrl: "/chips/Nuclear.webp", description: "Nuclear devastation" },
      { name: "Nuke", category: "attack" as const, tier: 6, imageUrl: "/chips/Nuke.webp", description: "Explosive area damage" },
      { name: "Lazer", category: "attack" as const, tier: 3, imageUrl: "/chips/Lazer.webp", description: "Precision laser beam" },
      { name: "Firebird", category: "attack" as const, tier: 4, imageUrl: "/chips/Firebird.webp", description: "Phoenix flame burst" },
      { name: "Obliterator", category: "attack" as const, tier: 7, imageUrl: "/chips/Obliterator.webp", description: "Total annihilation" },
      
      // Defense Chips
      { name: "Kevlar", category: "defense" as const, tier: 2, imageUrl: "/chips/Kevlar.webp", description: "Ballistic protection" },
      { name: "Carbon", category: "defense" as const, tier: 3, imageUrl: "/chips/Carbon.webp", description: "Lightweight armor" },
      { name: "Carbonite", category: "defense" as const, tier: 4, imageUrl: "/chips/Carbonite.webp", description: "Advanced carbon shielding" },
      { name: "Iron", category: "defense" as const, tier: 1, imageUrl: "/chips/Iron.webp", description: "Basic metal plating" },
      { name: "Titanium", category: "defense" as const, tier: 5, imageUrl: "/chips/Titanium.webp", description: "Ultra-strong titanium alloy" },
      { name: "Frost Cage", category: "defense" as const, tier: 4, imageUrl: "/chips/Frost Cage.webp", description: "Ice barrier protection" },
      { name: "Granite", category: "defense" as const, tier: 3, imageUrl: "/chips/Granite.webp", description: "Stone-solid defense" },
      
      // Economy Chips
      { name: "Gold", category: "economy" as const, tier: 3, imageUrl: "/chips/Gold.webp", description: "Increased gold generation" },
      { name: "24K", category: "economy" as const, tier: 5, imageUrl: "/chips/24K.webp", description: "Premium gold multiplier" },
      { name: "Coin", category: "economy" as const, tier: 1, imageUrl: "/chips/Coin.webp", description: "Basic resource boost" },
      { name: "Luxury", category: "economy" as const, tier: 4, imageUrl: "/chips/Luxury.webp", description: "Luxury goods production" },
      { name: "Luxury Ultimate", category: "economy" as const, tier: 6, imageUrl: "/chips/Luxury Ultimate.webp", description: "Maximum wealth generation" },
      { name: "Golden Guns", category: "economy" as const, tier: 5, imageUrl: "/chips/Golden Guns.webp", description: "Combat rewards boost" },
      { name: "Golden Guns Ultimate", category: "economy" as const, tier: 7, imageUrl: "/chips/Golden Guns Ultimate.webp", description: "Ultimate reward multiplier" },
      
      // Utility Chips
      { name: "Hacker", category: "utility" as const, tier: 3, imageUrl: "/chips/Hacker.webp", description: "System manipulation" },
      { name: "Night Vision", category: "utility" as const, tier: 2, imageUrl: "/chips/Night Vision.webp", description: "Enhanced visibility" },
      { name: "X Ray", category: "utility" as const, tier: 4, imageUrl: "/chips/X Ray.webp", description: "See through obstacles" },
      { name: "X Ray Ultimate", category: "utility" as const, tier: 6, imageUrl: "/chips/X Ray Ultimate.webp", description: "Complete transparency vision" },
      { name: "Radar", category: "utility" as const, tier: 3, imageUrl: "/chips/Radar.webp", description: "Enemy detection" },
      { name: "Satellite", category: "utility" as const, tier: 5, imageUrl: "/chips/Satellite.webp", description: "Global positioning" },
      { name: "Taser", category: "utility" as const, tier: 2, imageUrl: "/chips/Taser.webp", description: "Stun capabilities" },
      
      // Special Chips
      { name: "Holographic", category: "special" as const, tier: 5, imageUrl: "/chips/Holographic.webp", description: "Reality distortion field" },
      { name: "Chrome Ultimate", category: "special" as const, tier: 7, imageUrl: "/chips/Chrome Ultimate.webp", description: "Mirror dimension access" },
      { name: "Rainbow Morpho", category: "special" as const, tier: 6, imageUrl: "/chips/Rainbow Morpho.webp", description: "Prismatic transformation" },
      { name: "Phoenix", category: "special" as const, tier: 7, imageUrl: "/chips/Phoenix.webp", description: "Resurrection protocol" },
      { name: "Terminator", category: "special" as const, tier: 6, imageUrl: "/chips/Terminator.webp", description: "Relentless pursuit mode" },
      { name: "Vampire", category: "special" as const, tier: 5, imageUrl: "/chips/Vampire.webp", description: "Life steal abilities" },
      { name: "The Lethal Dimension", category: "special" as const, tier: 7, imageUrl: "/chips/The Lethal Dimension.webp", description: "Dimensional rift powers" },
    ];

    // Add possible buffs based on category
    const buffsByCategory = {
      attack: [
        { buffType: "damage", minValue: 5, maxValue: 50, weight: 1 },
        { buffType: "critChance", minValue: 2, maxValue: 20, weight: 0.8 },
        { buffType: "attackSpeed", minValue: 5, maxValue: 30, weight: 0.7 },
      ],
      defense: [
        { buffType: "armor", minValue: 10, maxValue: 100, weight: 1 },
        { buffType: "health", minValue: 50, maxValue: 500, weight: 0.9 },
        { buffType: "regeneration", minValue: 1, maxValue: 10, weight: 0.6 },
      ],
      economy: [
        { buffType: "goldMultiplier", minValue: 1.1, maxValue: 3.0, weight: 1 },
        { buffType: "resourceGain", minValue: 10, maxValue: 100, weight: 0.8 },
        { buffType: "luckBonus", minValue: 5, maxValue: 50, weight: 0.7 },
      ],
      utility: [
        { buffType: "moveSpeed", minValue: 5, maxValue: 30, weight: 1 },
        { buffType: "cooldownReduction", minValue: 5, maxValue: 25, weight: 0.9 },
        { buffType: "range", minValue: 10, maxValue: 50, weight: 0.7 },
      ],
      special: [
        { buffType: "allStats", minValue: 5, maxValue: 25, weight: 1 },
        { buffType: "uniqueEffect", minValue: 1, maxValue: 1, weight: 0.5 },
        { buffType: "powerBoost", minValue: 10, maxValue: 100, weight: 0.8 },
      ],
    };

    // Rank scaling multipliers
    const rankScaling = {
      "D": { buffMultiplier: 0.5, rollChances: 1 },
      "C": { buffMultiplier: 0.7, rollChances: 1 },
      "B": { buffMultiplier: 0.85, rollChances: 2 },
      "A": { buffMultiplier: 1.0, rollChances: 2 },
      "S": { buffMultiplier: 1.2, rollChances: 3 },
      "SS": { buffMultiplier: 1.4, rollChances: 3 },
      "SSS": { buffMultiplier: 1.6, rollChances: 4 },
      "X": { buffMultiplier: 2.0, rollChances: 4 },
      "XX": { buffMultiplier: 2.5, rollChances: 5 },
      "XXX": { buffMultiplier: 3.0, rollChances: 6 },
    };

    // Insert all chip definitions
    let insertedCount = 0;
    for (const chip of chipDefinitions) {
      await ctx.db.insert("chipDefinitions", {
        ...chip,
        possibleBuffs: buffsByCategory[chip.category],
        rankScaling,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
      insertedCount++;
    }

    return { message: "Chip definitions seeded successfully", count: insertedCount };
  },
});

// Get a single chip definition by ID
export const getChipDefinition = query({
  args: {
    id: v.id("chipDefinitions"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});