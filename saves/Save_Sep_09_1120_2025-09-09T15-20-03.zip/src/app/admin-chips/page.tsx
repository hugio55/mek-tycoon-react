'use client';

import { useQuery, useMutation } from 'convex/react';
import { api } from '../../../convex/_generated/api';
import { useState } from 'react';

export default function AdminChips() {
  const [seedResult, setSeedResult] = useState<string>('');
  const chipDefinitions = useQuery(api.chips.getAllChipDefinitions);
  const seedChips = useMutation(api.chips.seedChipDefinitions);

  const handleSeed = async () => {
    try {
      const result = await seedChips();
      setSeedResult(`${result.message} - ${result.count} chips added`);
    } catch (error) {
      setSeedResult(`Error: ${error}`);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 text-yellow-500">Chip Definitions Admin</h1>
        
        <div className="mb-8 p-6 bg-gray-900 rounded-lg border border-yellow-500/30">
          <h2 className="text-2xl mb-4">Database Seeding</h2>
          <button
            onClick={handleSeed}
            className="px-6 py-3 bg-yellow-500 text-black font-bold rounded hover:bg-yellow-400 transition-colors"
          >
            Seed Chip Definitions
          </button>
          {seedResult && (
            <p className="mt-4 text-green-400">{seedResult}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {chipDefinitions?.map((chip) => (
            <div
              key={chip._id}
              className="bg-gray-900 rounded-lg border border-gray-700 p-4 hover:border-yellow-500/50 transition-colors"
            >
              <div className="flex items-center mb-2">
                {chip.imageUrl && (
                  <img
                    src={chip.imageUrl}
                    alt={chip.name}
                    className="w-16 h-16 object-contain mr-3"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                )}
                <div>
                  <h3 className="font-bold text-yellow-400">{chip.name}</h3>
                  <p className="text-xs text-gray-400">Tier {chip.tier}</p>
                </div>
              </div>
              <p className="text-sm text-gray-300 mb-2">{chip.description}</p>
              <div className="flex justify-between items-center">
                <span className={`text-xs px-2 py-1 rounded ${
                  chip.category === 'attack' ? 'bg-red-900 text-red-200' :
                  chip.category === 'defense' ? 'bg-blue-900 text-blue-200' :
                  chip.category === 'economy' ? 'bg-yellow-900 text-yellow-200' :
                  chip.category === 'utility' ? 'bg-green-900 text-green-200' :
                  'bg-purple-900 text-purple-200'
                }`}>
                  {chip.category}
                </span>
              </div>
            </div>
          ))}
        </div>

        {!chipDefinitions?.length && (
          <div className="text-center py-12 text-gray-500">
            No chip definitions found. Click "Seed Chip Definitions" to populate the database.
          </div>
        )}
      </div>
    </div>
  );
}