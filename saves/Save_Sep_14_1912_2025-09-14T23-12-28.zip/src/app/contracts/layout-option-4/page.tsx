import ContractsLayoutOption4 from '../layout-option-4';

export default function LayoutOption4Page() {
  return <ContractsLayoutOption4 />;
}