import ContractsLayoutOption1 from '../layout-option-1';

export default function LayoutOption1Page() {
  return <ContractsLayoutOption1 />;
}