"use client";

export default function TestStory() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-yellow-500 text-xl">Test Story Page - This should work!</div>
    </div>
  );
}