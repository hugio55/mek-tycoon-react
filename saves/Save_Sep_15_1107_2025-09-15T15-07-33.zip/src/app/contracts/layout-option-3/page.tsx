import ContractsLayoutOption3 from '../layout-option-3';

export default function LayoutOption3Page() {
  return <ContractsLayoutOption3 />;
}