'use client';

import React from 'react';

interface GameConstant {
  category: string;
  setting: string;
  value: string | number;
  description: string;
  configurable: boolean;
}

const gameConstants: GameConstant[] = [
  // Inventory System
  { category: 'Inventory', setting: 'Max Stack Size', value: 99, description: 'Maximum quantity per stackable item slot', configurable: false },
  { category: 'Inventory', setting: 'Slots Per Tab', value: 20, description: 'Number of inventory slots in each tab', configurable: false },
  { category: 'Inventory', setting: 'Max Tabs', value: 5, description: 'Maximum inventory tabs a player can unlock', configurable: false },
  { category: 'Inventory', setting: 'Tab 2 Cost', value: 100, description: 'Gold cost to unlock second tab', configurable: true },
  { category: 'Inventory', setting: 'Tab 3 Cost', value: 500, description: 'Gold cost to unlock third tab', configurable: true },
  { category: 'Inventory', setting: 'Tab 4 Cost', value: 2000, description: 'Gold cost to unlock fourth tab', configurable: true },
  { category: 'Inventory', setting: 'Tab 5 Cost', value: 10000, description: 'Gold cost to unlock fifth tab', configurable: true },

  // Starting Resources
  { category: 'New Player', setting: 'Starting Gold', value: 100, description: 'Gold given to new players', configurable: true },
  { category: 'New Player', setting: 'Starting Gold/Hour', value: 50, description: 'Initial passive gold generation rate', configurable: true },
  { category: 'New Player', setting: 'Starting Contract Slots', value: 2, description: 'Number of contracts new players can run', configurable: true },
  { category: 'New Player', setting: 'Starting Crafting Slots', value: 1, description: 'Simultaneous crafts for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Chip Slots/Mek', value: 3, description: 'Chip slots per Mek for new players', configurable: true },

  // Starting Essence
  { category: 'New Player', setting: 'Starting Stone Essence', value: 10, description: 'Stone essence for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Disco Essence', value: 5, description: 'Disco essence for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Cartoon Essence', value: 5, description: 'Cartoon essence for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Candy Essence', value: 5, description: 'Candy essence for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Tiles Essence', value: 5, description: 'Tiles essence for new players', configurable: true },
  { category: 'New Player', setting: 'Starting Moss Essence', value: 5, description: 'Moss essence for new players', configurable: true },

  // Crafting System
  { category: 'Crafting', setting: 'Base Craft Time', value: '5 min', description: 'Default crafting duration', configurable: true },
  { category: 'Crafting', setting: 'Max Crafting Slots', value: 5, description: 'Maximum crafting slots purchasable', configurable: false },
  { category: 'Crafting', setting: 'Slot Cost Multiplier', value: 2, description: 'Cost multiplies by this for each new slot', configurable: true },
  { category: 'Crafting', setting: 'Success Rate Base', value: '80%', description: 'Base chance for successful craft', configurable: true },

  // Contracts System
  { category: 'Contracts', setting: 'Max Contract Slots', value: 10, description: 'Maximum contract slots with buffs', configurable: false },
  { category: 'Contracts', setting: 'Min Contract Duration', value: '15 min', description: 'Shortest contract time', configurable: true },
  { category: 'Contracts', setting: 'Max Contract Duration', value: '24 hours', description: 'Longest contract time', configurable: true },
  { category: 'Contracts', setting: 'Contract Refresh Rate', value: '1 hour', description: 'New contracts appear every', configurable: true },

  // Mek System
  { category: 'Meks', setting: 'Max Level', value: 100, description: 'Maximum Mek level', configurable: false },
  { category: 'Meks', setting: 'XP Per Level', value: 1000, description: 'Base XP required per level', configurable: true },
  { category: 'Meks', setting: 'Level Scaling', value: 1.15, description: 'XP requirement multiplier per level', configurable: true },
  { category: 'Meks', setting: 'Max Chips Per Mek', value: 6, description: 'Maximum chips with all upgrades', configurable: false },
  { category: 'Meks', setting: 'Employee Gold Rate', value: '10/hr', description: 'Base gold per employee Mek', configurable: true },

  // Chip System
  { category: 'Chips', setting: 'Rank Tiers', value: 'D,C,B,A,S,SS,SSS,X,XX,XXX', description: 'Available chip ranks', configurable: false },
  { category: 'Chips', setting: 'Rank Multipliers', value: '1x,1.5x,2x,3x,5x,7x,10x,15x,20x,30x', description: 'Buff multiplier per rank', configurable: true },
  { category: 'Chips', setting: 'Universal Chip Chance', value: '5%', description: 'Chance to craft universal chip', configurable: true },
  { category: 'Chips', setting: 'Chip Removal Cost', value: 100, description: 'Gold to remove chip without destroying', configurable: true },

  // Banking System
  { category: 'Banking', setting: 'Base Interest Rate', value: '1%', description: 'Daily interest rate', configurable: true },
  { category: 'Banking', setting: 'Silver Account Rate', value: '2%', description: 'Silver tier interest', configurable: true },
  { category: 'Banking', setting: 'Gold Account Rate', value: '3%', description: 'Gold tier interest', configurable: true },
  { category: 'Banking', setting: 'Max Loan Amount', value: 10000, description: 'Maximum borrowable gold', configurable: true },
  { category: 'Banking', setting: 'Loan Interest', value: '5%', description: 'Daily loan interest', configurable: true },

  // Market System
  { category: 'Market', setting: 'Listing Fee', value: '5%', description: 'Fee to list items', configurable: true },
  { category: 'Market', setting: 'Sale Tax', value: '10%', description: 'Tax on successful sales', configurable: true },
  { category: 'Market', setting: 'Max Listings', value: 20, description: 'Max simultaneous listings', configurable: true },
  { category: 'Market', setting: 'Listing Duration', value: '7 days', description: 'How long listings stay active', configurable: true },

  // Achievement System
  { category: 'Achievements', setting: 'Total Achievements', value: 250, description: 'Number of achievements in game', configurable: false },
  { category: 'Achievements', setting: 'Achievement Points', value: 10000, description: 'Total points available', configurable: false },
  { category: 'Achievements', setting: 'Hidden Achievements', value: 25, description: 'Secret achievements', configurable: false },

  // Essence System
  { category: 'Essence', setting: 'Essence Types', value: 15, description: 'Number of essence varieties', configurable: false },
  { category: 'Essence', setting: 'Essence Cap Base', value: 1000, description: 'Base storage limit per essence', configurable: true },
  { category: 'Essence', setting: 'Cap Upgrade Cost', value: 500, description: 'Gold to increase cap by 100', configurable: true },
  { category: 'Essence', setting: 'Essence Drop Rate', value: '30%', description: 'Base chance from activities', configurable: true },

  // Story Mode
  { category: 'Story', setting: 'Total Chapters', value: 12, description: 'Number of story chapters', configurable: false },
  { category: 'Story', setting: 'Nodes Per Chapter', value: 20, description: 'Average missions per chapter', configurable: false },
  { category: 'Story', setting: 'Boss Difficulty Scaling', value: 1.5, description: 'Boss power multiplier per chapter', configurable: true },
  { category: 'Story', setting: 'Story Reset Cost', value: 1000, description: 'Gold to reset story progress', configurable: true },
];

interface GameDataLightboxProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function GameDataLightbox({ isOpen, onClose }: GameDataLightboxProps) {
  let currentCategory = '';

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative max-w-6xl w-full max-h-[90vh] overflow-hidden bg-black border-2 border-yellow-500/50 rounded-lg">
        {/* Header */}
        <div className="sticky top-0 bg-black border-b-2 border-yellow-500/50 p-6 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-yellow-500 font-orbitron uppercase">
              Global Game Data
            </h2>
            <p className="text-gray-400 text-sm mt-1">
              Global constants and configuration values that apply to all players
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-yellow-500 hover:text-yellow-400 text-2xl font-bold"
          >
            ×
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-120px)] p-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b-2 border-yellow-500/50 sticky top-0 bg-black">
                <tr>
                  <th className="py-2 px-3 text-yellow-500 font-orbitron uppercase w-[20%]">Setting</th>
                  <th className="py-2 px-3 text-yellow-500 font-orbitron uppercase w-[15%]">Value</th>
                  <th className="py-2 px-3 text-yellow-500 font-orbitron uppercase w-[50%]">Description</th>
                  <th className="py-2 px-3 text-yellow-500 font-orbitron uppercase w-[15%]">Configurable</th>
                </tr>
              </thead>
              <tbody>
                {gameConstants.map((constant, index) => {
                  const isNewCategory = constant.category !== currentCategory;
                  if (isNewCategory) {
                    currentCategory = constant.category;
                  }

                  return (
                    <React.Fragment key={`constant-${index}`}>
                      {isNewCategory && (
                        <tr className="border-t-2 border-yellow-500/30">
                          <td colSpan={4} className="py-2 px-3 text-yellow-500 font-bold uppercase bg-yellow-500/5">
                            {constant.category}
                          </td>
                        </tr>
                      )}
                      <tr className="border-b border-gray-900 hover:bg-yellow-500/5 transition-colors">
                        <td className="py-2 px-3 font-medium">{constant.setting}</td>
                        <td className="py-2 px-3">
                          <span className="text-blue-400 font-mono font-bold">
                            {typeof constant.value === 'number' ? constant.value.toLocaleString() : constant.value}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-gray-400">{constant.description}</td>
                        <td className="py-2 px-3">
                          {constant.configurable ? (
                            <span className="text-green-400">✓ Yes</span>
                          ) : (
                            <span className="text-gray-500">— No</span>
                          )}
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="mt-6 pt-4 border-t border-yellow-500/20">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-bold text-yellow-500/80 mb-2">Configuration Notes</h3>
                <ul className="text-xs text-gray-400 space-y-1">
                  <li>• Configurable values can be adjusted via environment variables</li>
                  <li>• Non-configurable values are core game mechanics</li>
                  <li>• Changes require server restart to take effect</li>
                  <li>• Some values affect game balance significantly</li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-bold text-yellow-500/80 mb-2">Important Limits</h3>
                <ul className="text-xs text-gray-400 space-y-1">
                  <li>• <span className="text-yellow-500/60">Stack Size:</span> Max 99 items per inventory slot</li>
                  <li>• <span className="text-yellow-500/60">Inventory:</span> 5 tabs × 20 slots = 100 total slots</li>
                  <li>• <span className="text-yellow-500/60">Contracts:</span> No limit on Meks per contract</li>
                  <li>• <span className="text-yellow-500/60">Market:</span> No limit on market slots</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}