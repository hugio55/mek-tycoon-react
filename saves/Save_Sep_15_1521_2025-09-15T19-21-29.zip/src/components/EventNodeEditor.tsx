'use client';

import { useState, useEffect } from 'react';
import { useConvex, useMutation, useQuery } from 'convex/react';
import { api } from '@/convex/_generated/api';
import { Id } from '@/convex/_generated/dataModel';

interface EventNode {
  eventNumber: number;
  name: string;
  goldReward: number;
  xpReward: number;
  items?: Array<{
    id: string;
    name: string;
    type: string;
    category?: string;
  }>;
}

interface ChapterData {
  chapter: number;
  minGold: number;
  maxGold: number;
  minXP: number;
  maxXP: number;
  events: EventNode[];
}

export default function EventNodeEditor() {
  const [selectedChapter, setSelectedChapter] = useState(1);
  const [itemSearchTerms, setItemSearchTerms] = useState<{ [key: number]: string }>({});
  const [showItemSearch, setShowItemSearch] = useState<{ [key: number]: boolean }>({});
  const [activeSearchIndex, setActiveSearchIndex] = useState<number | null>(null);
  const [selectedSaveId, setSelectedSaveId] = useState<Id<"eventNodeConfigs"> | null>(null);
  const [saveName, setSaveName] = useState('');

  const saveConfiguration = useMutation(api.eventNodeRewards.saveConfiguration);
  const deleteConfiguration = useMutation(api.eventNodeRewards.deleteConfiguration);
  const savedConfigs = useQuery(api.eventNodeRewards.getConfigurations);
  const selectedConfig = useQuery(
    api.eventNodeRewards.loadConfiguration,
    selectedSaveId ? { configId: selectedSaveId } : "skip"
  );

  // Get search results for the active search
  const activeSearchTerm = activeSearchIndex !== null ? (itemSearchTerms[activeSearchIndex] || '') : '';
  const searchResults = useQuery(
    api.gameItemsSearch.searchGameItems,
    activeSearchTerm.length >= 2 ? { searchTerm: activeSearchTerm } : "skip"
  );

  const [chaptersData, setChaptersData] = useState<ChapterData[]>(() => {
    // Initialize with 10 chapters, each with 20 events
    const initialData: ChapterData[] = [];
    for (let chapter = 1; chapter <= 10; chapter++) {
      const events: EventNode[] = [];
      const startEvent = (chapter - 1) * 20 + 1;
      for (let i = 0; i < 20; i++) {
        events.push({
          eventNumber: startEvent + i,
          name: `Event ${startEvent + i}`,
          goldReward: 100 + (i * 45),
          xpReward: 10 + (i * 5),
          items: []
        });
      }
      initialData.push({
        chapter,
        minGold: 100,
        maxGold: 1000,
        minXP: 10,
        maxXP: 105,
        events
      });
    }
    return initialData;
  });

  // Load selected configuration
  useEffect(() => {
    if (selectedConfig?.data) {
      try {
        const loadedData = JSON.parse(selectedConfig.data);
        setChaptersData(loadedData);
      } catch (error) {
        console.error('Failed to parse configuration data:', error);
      }
    }
  }, [selectedConfig]);

  // Calculate linear distribution of rewards
  const calculateRewards = (min: number, max: number): number[] => {
    const rewards: number[] = [];
    const step = (max - min) / 19;
    for (let i = 0; i < 20; i++) {
      if (i === 19) {
        rewards.push(max);
      } else {
        rewards.push(Math.floor(min + (step * i)));
      }
    }
    return rewards;
  };

  // Update gold range for current chapter
  const updateGoldRange = (minGold: number, maxGold: number) => {
    const newChaptersData = [...chaptersData];
    const chapterIndex = selectedChapter - 1;
    const goldRewards = calculateRewards(minGold, maxGold);

    newChaptersData[chapterIndex] = {
      ...newChaptersData[chapterIndex],
      minGold,
      maxGold,
      events: newChaptersData[chapterIndex].events.map((event, index) => ({
        ...event,
        goldReward: goldRewards[index]
      }))
    };

    setChaptersData(newChaptersData);
  };

  // Update XP range for current chapter
  const updateXPRange = (minXP: number, maxXP: number) => {
    const newChaptersData = [...chaptersData];
    const chapterIndex = selectedChapter - 1;
    const xpRewards = calculateRewards(minXP, maxXP);

    newChaptersData[chapterIndex] = {
      ...newChaptersData[chapterIndex],
      minXP,
      maxXP,
      events: newChaptersData[chapterIndex].events.map((event, index) => ({
        ...event,
        xpReward: xpRewards[index]
      }))
    };

    setChaptersData(newChaptersData);
  };

  // Update event name
  const updateEventName = (eventIndex: number, name: string) => {
    const newChaptersData = [...chaptersData];
    const chapterIndex = selectedChapter - 1;
    newChaptersData[chapterIndex].events[eventIndex].name = name;
    setChaptersData(newChaptersData);
  };

  // Add item to event
  const addItemToEvent = (eventIndex: number, item: any) => {
    const newChaptersData = [...chaptersData];
    const chapterIndex = selectedChapter - 1;
    if (!newChaptersData[chapterIndex].events[eventIndex].items) {
      newChaptersData[chapterIndex].events[eventIndex].items = [];
    }
    const exists = newChaptersData[chapterIndex].events[eventIndex].items?.some(
      i => i.id === item.id
    );
    if (!exists) {
      newChaptersData[chapterIndex].events[eventIndex].items?.push(item);
      setChaptersData(newChaptersData);
    }
    setItemSearchTerms(prev => ({ ...prev, [eventIndex]: '' }));
    setShowItemSearch(prev => ({ ...prev, [eventIndex]: false }));
  };

  // Remove item from event
  const removeItemFromEvent = (eventIndex: number, itemId: string) => {
    const newChaptersData = [...chaptersData];
    const chapterIndex = selectedChapter - 1;
    newChaptersData[chapterIndex].events[eventIndex].items =
      newChaptersData[chapterIndex].events[eventIndex].items?.filter(
        item => item.id !== itemId
      ) || [];
    setChaptersData(newChaptersData);
  };

  // Save configuration
  const handleSave = async () => {
    if (!saveName.trim()) {
      alert('Please enter a save name');
      return;
    }

    try {
      await saveConfiguration({
        name: saveName,
        data: JSON.stringify(chaptersData),
        timestamp: Date.now(),
      });
      alert('Event configuration saved successfully!');
      setSaveName('');
    } catch (error) {
      console.error('Failed to save configuration:', error);
      alert('Failed to save configuration');
    }
  };

  const currentChapter = chaptersData[selectedChapter - 1];

  return (
    <div className="mt-6 space-y-6">
      <div className="bg-gray-800/30 rounded-lg p-4">
        <h4 className="text-sm font-bold text-purple-500/80 mb-3">Event Node Configuration</h4>

        {/* Save/Load Controls */}
        <div className="mb-4 space-y-2">
          <div className="flex gap-2">
            <input
              type="text"
              value={saveName}
              onChange={(e) => setSaveName(e.target.value)}
              placeholder="Configuration name..."
              className="flex-1 px-3 py-2 bg-black/50 border border-purple-500/30 rounded text-sm text-gray-300"
            />
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded text-sm transition-colors"
            >
              Save Config
            </button>
          </div>

          {savedConfigs && savedConfigs.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {savedConfigs.map((config) => (
                <button
                  key={config._id}
                  onClick={() => setSelectedSaveId(config._id)}
                  className={`px-3 py-1 rounded text-xs transition-colors ${
                    selectedSaveId === config._id
                      ? 'bg-purple-600 text-white'
                      : 'bg-black/30 text-purple-400 border border-purple-500/30 hover:bg-purple-500/20'
                  }`}
                >
                  {config.name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Chapter Selector */}
        <div className="mb-4">
          <label className="block text-purple-400 mb-1 text-sm">Select Chapter</label>
          <select
            value={selectedChapter}
            onChange={(e) => setSelectedChapter(Number(e.target.value))}
            className="w-full px-3 py-2 bg-black/50 border border-purple-500/30 rounded text-sm text-gray-300"
          >
            {[...Array(10)].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                Chapter {i + 1} (Events {i * 20 + 1}-{(i + 1) * 20})
              </option>
            ))}
          </select>
        </div>

        {/* Gold and XP Range Controls */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-black/30 rounded p-3">
            <h5 className="text-yellow-400 text-sm font-bold mb-2">Gold Range</h5>
            <div className="flex gap-2">
              <input
                type="number"
                value={currentChapter.minGold}
                onChange={(e) => updateGoldRange(Number(e.target.value), currentChapter.maxGold)}
                className="w-24 px-2 py-1 bg-black/50 border border-yellow-400/30 rounded text-xs text-yellow-400"
                placeholder="Min"
              />
              <span className="text-gray-500">to</span>
              <input
                type="number"
                value={currentChapter.maxGold}
                onChange={(e) => updateGoldRange(currentChapter.minGold, Number(e.target.value))}
                className="w-24 px-2 py-1 bg-black/50 border border-yellow-400/30 rounded text-xs text-yellow-400"
                placeholder="Max"
              />
            </div>
          </div>

          <div className="bg-black/30 rounded p-3">
            <h5 className="text-blue-400 text-sm font-bold mb-2">XP Range</h5>
            <div className="flex gap-2">
              <input
                type="number"
                value={currentChapter.minXP}
                onChange={(e) => updateXPRange(Number(e.target.value), currentChapter.maxXP)}
                className="w-24 px-2 py-1 bg-black/50 border border-blue-400/30 rounded text-xs text-blue-400"
                placeholder="Min"
              />
              <span className="text-gray-500">to</span>
              <input
                type="number"
                value={currentChapter.maxXP}
                onChange={(e) => updateXPRange(currentChapter.minXP, Number(e.target.value))}
                className="w-24 px-2 py-1 bg-black/50 border border-blue-400/30 rounded text-xs text-blue-400"
                placeholder="Max"
              />
            </div>
          </div>
        </div>

        {/* Event Grid - Compact View */}
        <div className="max-h-96 overflow-y-auto">
          <div className="grid grid-cols-2 gap-2">
            {currentChapter.events.map((event, index) => {
              const isActiveSearch = activeSearchIndex === index;
              const currentSearchResults = isActiveSearch ? searchResults : null;

              return (
                <div
                  key={event.eventNumber}
                  className="bg-black/30 border border-purple-500/20 rounded p-2"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-purple-400/60 text-xs">#{event.eventNumber}</span>
                    <input
                      type="text"
                      value={event.name}
                      onChange={(e) => updateEventName(index, e.target.value)}
                      className="flex-1 px-1 py-0.5 bg-black/30 border border-purple-500/20 rounded text-xs text-gray-300"
                      placeholder="Event name..."
                    />
                  </div>

                  <div className="flex gap-2 text-xs mb-1">
                    <span className="text-yellow-400">{event.goldReward}G</span>
                    <span className="text-blue-400">{event.xpReward}XP</span>
                  </div>

                  {/* Items */}
                  {event.items && event.items.length > 0 && (
                    <div className="text-xs text-purple-300/60 mb-1">
                      +{event.items.length} item{event.items.length > 1 ? 's' : ''}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary */}
        <div className="mt-4 pt-4 border-t border-purple-500/20 grid grid-cols-3 gap-4 text-xs">
          <div>
            <span className="text-purple-400/60">Total Gold: </span>
            <span className="text-yellow-400 font-bold">
              {currentChapter.events.reduce((sum, event) => sum + event.goldReward, 0).toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-purple-400/60">Total XP: </span>
            <span className="text-blue-400 font-bold">
              {currentChapter.events.reduce((sum, event) => sum + event.xpReward, 0).toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-purple-400/60">Events: </span>
            <span className="text-purple-400 font-bold">20</span>
          </div>
        </div>

        {/* Link to Full Editor */}
        <div className="mt-4 pt-4 border-t border-purple-500/20">
          <a
            href="/event-node-rewards"
            target="_blank"
            className="text-purple-400 hover:text-purple-300 text-sm underline"
          >
            Open Full Event Editor →
          </a>
        </div>
      </div>
    </div>
  );
}