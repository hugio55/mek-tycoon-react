"use client";

import { useGlobalClickSound } from '@/lib/useClickSound';

export const GlobalClickSound = () => {
  useGlobalClickSound();
  return null;
};