'use client';

import React, { useState, useEffect } from 'react';

// Chip modifiers in order of rarity
const MODIFIERS = ['D', 'C', 'B', 'A', 'S', 'SS', 'SSS', 'X', 'XX', 'XXX'] as const;
type Modifier = typeof MODIFIERS[number];

// Colors for each modifier (matching the rarity bias chart)
const MODIFIER_COLORS: Record<Modifier, string> = {
  'D': '#999999',
  'C': '#90EE90',
  'B': '#87CEEB',
  'A': '#FFF700',
  'S': '#FFB6C1',
  'SS': '#DA70D6',
  'SSS': '#9370DB',
  'X': '#FF8C00',
  'XX': '#DC143C',
  'XXX': '#8B0000'
};

// Tier colors for visual distinction
const TIER_COLORS = [
  '#4B5563', // Tier 1 - Gray
  '#10B981', // Tier 2 - Green
  '#3B82F6', // Tier 3 - Blue
  '#8B5CF6', // Tier 4 - Purple
  '#EC4899', // Tier 5 - Pink
  '#F59E0B', // Tier 6 - Amber
  '#EF4444', // Tier 7 - Red
  '#DC2626', // Tier 8 - Dark Red
  '#7C3AED', // Tier 9 - Violet
  '#FBBF24', // Tier 10 - Gold
];

interface ChipReward {
  tier: number;
  modifier: Modifier;
  probability: number; // percentage
}

interface EventChips {
  eventNumber: number;
  chapterNumber: number;
  rewards: ChipReward[];
}

// Calculate chip distribution for all 200 events
function calculateChipDistribution(): EventChips[] {
  const events: EventChips[] = [];

  for (let chapter = 1; chapter <= 10; chapter++) {
    for (let eventInChapter = 1; eventInChapter <= 20; eventInChapter++) {
      const globalEventNumber = (chapter - 1) * 20 + eventInChapter;

      // Progressive tier scaling based on chapter and event position
      const baseTier = Math.ceil(chapter * 0.8); // Chapters 1-2 = Tier 1, etc.
      const eventBonus = eventInChapter / 20; // 0.05 to 1.0

      // Define the 4 reward slots with probabilities
      const rewards: ChipReward[] = [];

      // Slot 1 (75% chance) - Base tier, common modifier
      const slot1Tier = baseTier;
      const slot1ModifierIndex = Math.floor(eventBonus * 2); // D, C, or B
      rewards.push({
        tier: slot1Tier,
        modifier: MODIFIERS[slot1ModifierIndex],
        probability: 75
      });

      // Slot 2 (20% chance) - Same tier, better modifier
      const slot2Tier = baseTier;
      const slot2ModifierIndex = Math.min(3 + Math.floor(eventBonus * 3), 6); // A, S, SS, or SSS
      rewards.push({
        tier: slot2Tier,
        modifier: MODIFIERS[slot2ModifierIndex],
        probability: 20
      });

      // Slot 3 (4% chance) - Next tier or high modifier
      if (eventBonus > 0.5 && baseTier < 10) {
        // Later events: next tier with mid modifier
        rewards.push({
          tier: baseTier + 1,
          modifier: MODIFIERS[Math.floor(2 + eventBonus * 2)], // B, A, or S
          probability: 4
        });
      } else {
        // Early events: same tier with X modifier
        rewards.push({
          tier: baseTier,
          modifier: 'X',
          probability: 4
        });
      }

      // Slot 4 (1% chance) - Jackpot reward
      if (chapter === 10 && eventInChapter === 20) {
        // Final event: Tier 10 SSS!
        rewards.push({
          tier: 10,
          modifier: 'SSS',
          probability: 1
        });
      } else if (chapter >= 8) {
        // Late game: Jump 2 tiers with good modifier
        rewards.push({
          tier: Math.min(baseTier + 2, 10),
          modifier: MODIFIERS[Math.min(5 + Math.floor(eventBonus * 2), 9)], // SS to XXX
          probability: 1
        });
      } else {
        // Early-mid game: Jump 1 tier with great modifier or same tier XXX
        if (baseTier < 9) {
          rewards.push({
            tier: baseTier + 1,
            modifier: MODIFIERS[Math.min(6 + Math.floor(eventBonus * 2), 9)], // SSS to XXX
            probability: 1
          });
        } else {
          rewards.push({
            tier: baseTier,
            modifier: 'XXX',
            probability: 1
          });
        }
      }

      events.push({
        eventNumber: globalEventNumber,
        chapterNumber: chapter,
        rewards
      });
    }
  }

  return events;
}

export default function EventChipDistribution() {
  const [distributions, setDistributions] = useState<EventChips[]>([]);
  const [selectedChapter, setSelectedChapter] = useState<number>(1);
  const [viewMode, setViewMode] = useState<'overview' | 'detail'>('overview');

  useEffect(() => {
    setDistributions(calculateChipDistribution());
  }, []);

  const currentChapterEvents = distributions.filter(d => d.chapterNumber === selectedChapter);

  if (viewMode === 'overview') {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-yellow-500">Universal Chip Distribution by Chapter</h3>
          <button
            onClick={() => setViewMode('detail')}
            className="px-4 py-2 bg-yellow-500 hover:bg-yellow-400 text-black font-semibold rounded text-sm transition-colors"
          >
            View Details
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-gray-400 border-b border-gray-700">
                <th className="text-left py-2">Chapter</th>
                <th className="text-left py-2">Base Tier</th>
                <th className="text-left py-2">Common Reward (75%)</th>
                <th className="text-left py-2">Uncommon (20%)</th>
                <th className="text-left py-2">Rare (4%)</th>
                <th className="text-left py-2">Legendary (1%)</th>
              </tr>
            </thead>
            <tbody>
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(chapter => {
                const firstEvent = distributions.find(d => d.chapterNumber === chapter && d.eventNumber === (chapter - 1) * 20 + 1);
                const lastEvent = distributions.find(d => d.chapterNumber === chapter && d.eventNumber === chapter * 20);

                if (!firstEvent || !lastEvent) return null;

                return (
                  <tr key={chapter} className="border-b border-gray-800 hover:bg-gray-800/20">
                    <td className="py-2 font-bold text-yellow-500">Chapter {chapter}</td>
                    <td className="py-2">
                      <span style={{ color: TIER_COLORS[firstEvent.rewards[0].tier - 1] }}>
                        Tier {firstEvent.rewards[0].tier}
                      </span>
                    </td>
                    <td className="py-2">
                      <span style={{ color: TIER_COLORS[firstEvent.rewards[0].tier - 1] }}>
                        T{firstEvent.rewards[0].tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[firstEvent.rewards[0].modifier] }} className="ml-1">
                        {firstEvent.rewards[0].modifier}
                      </span>
                      {' → '}
                      <span style={{ color: TIER_COLORS[lastEvent.rewards[0].tier - 1] }}>
                        T{lastEvent.rewards[0].tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[lastEvent.rewards[0].modifier] }} className="ml-1">
                        {lastEvent.rewards[0].modifier}
                      </span>
                    </td>
                    <td className="py-2">
                      <span style={{ color: TIER_COLORS[lastEvent.rewards[1].tier - 1] }}>
                        T{lastEvent.rewards[1].tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[lastEvent.rewards[1].modifier] }} className="ml-1">
                        {lastEvent.rewards[1].modifier}
                      </span>
                    </td>
                    <td className="py-2">
                      <span style={{ color: TIER_COLORS[lastEvent.rewards[2].tier - 1] }}>
                        T{lastEvent.rewards[2].tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[lastEvent.rewards[2].modifier] }} className="ml-1">
                        {lastEvent.rewards[2].modifier}
                      </span>
                    </td>
                    <td className="py-2">
                      <span style={{ color: TIER_COLORS[lastEvent.rewards[3].tier - 1] }}>
                        T{lastEvent.rewards[3].tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[lastEvent.rewards[3].modifier] }} className="ml-1 font-bold">
                        {lastEvent.rewards[3].modifier}
                      </span>
                      {chapter === 10 && ' 🏆'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-yellow-500">Chapter {selectedChapter} Chip Rewards</h3>
        <div className="flex gap-2">
          <select
            value={selectedChapter}
            onChange={(e) => setSelectedChapter(Number(e.target.value))}
            className="px-3 py-1 bg-black/50 border border-gray-700 rounded text-sm text-gray-300"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(ch => (
              <option key={ch} value={ch}>Chapter {ch}</option>
            ))}
          </select>
          <button
            onClick={() => setViewMode('overview')}
            className="px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white font-semibold rounded text-sm transition-colors"
          >
            Back to Overview
          </button>
        </div>
      </div>

      {/* Event Grid */}
      <div className="grid grid-cols-4 gap-3">
        {currentChapterEvents.map(event => (
          <div key={event.eventNumber} className="bg-black/30 rounded p-3 border border-purple-500/20">
            <div className="font-bold text-purple-400 mb-2">
              Event {(event.eventNumber - 1) % 20 + 1}
            </div>
            <div className="space-y-1">
              {event.rewards.map((reward, idx) => {
                const probabilityColors = ['text-gray-400', 'text-green-400', 'text-blue-400', 'text-yellow-400'];
                const probabilityLabels = ['Common', 'Uncommon', 'Rare', 'Legendary'];

                return (
                  <div key={idx} className="flex justify-between items-center text-xs">
                    <span className={probabilityColors[idx] + ' text-[10px]'}>
                      {reward.probability}%
                    </span>
                    <span className="flex items-center gap-1">
                      <span style={{ color: TIER_COLORS[reward.tier - 1] }} className="font-bold">
                        T{reward.tier}
                      </span>
                      <span style={{ color: MODIFIER_COLORS[reward.modifier] }} className="font-bold">
                        {reward.modifier}
                      </span>
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="bg-gray-800/30 rounded-lg p-4">
        <h4 className="text-sm font-bold text-yellow-500/80 mb-3">Universal Chip System</h4>
        <div className="grid grid-cols-2 gap-4 text-xs">
          <div>
            <div className="text-gray-500 mb-2">Tiers (1-10):</div>
            <div className="flex flex-wrap gap-2">
              {TIER_COLORS.map((color, idx) => (
                <div key={idx} className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: color }}></div>
                  <span className="text-gray-400">T{idx + 1}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-gray-500 mb-2">Modifiers (D-XXX):</div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(MODIFIER_COLORS).map(([mod, color]) => (
                <div key={mod} className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: color }}></div>
                  <span className="text-gray-400">{mod}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-gray-700 text-xs text-gray-400">
          <div>• Higher tiers = more powerful chips</div>
          <div>• Better modifiers = enhanced effects within the tier</div>
          <div>• Tier X SSS ≈ Tier X+1 D (crossover point)</div>
          <div>• Event 20 of Chapter 10 has the ultimate reward: Tier 10 SSS!</div>
        </div>
      </div>
    </div>
  );
}