import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

// Deploy event node configuration to Story Climb
export const deployEventNodes = mutation({
  args: {
    configurationId: v.optional(v.id("eventNodeConfigs")),
    configurationName: v.optional(v.string()),
    eventData: v.string(), // JSON string of EventNode[] from EventNodeEditor
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    const userId = identity?.subject || "anonymous";

    try {
      // Parse the event data
      const events = JSON.parse(args.eventData);

      // Validate the data structure
      if (!Array.isArray(events) || events.length === 0) {
        throw new Error("Invalid event data: must be a non-empty array");
      }

      // Enhance event data - chip rewards will be calculated client-side
      const enhancedEvents = events.map((event: any) => {
        return {
          eventNumber: event.eventNumber,
          name: event.name || `Event ${event.eventNumber}`,
          goldReward: event.goldReward || 0,
          xpReward: event.xpReward || 0,
          chipRewards: event.chipRewards || [], // Will be calculated client-side
          essenceRewards: event.essenceRewards || [],
          customRewards: event.customRewards || [],
          imageReference: `/event-images/${event.eventNumber}.webp`,
        };
      });

      // Archive any currently active deployments
      const activeDeployments = await ctx.db
        .query("deployedStoryClimbData")
        .filter((q) => q.eq(q.field("status"), "active"))
        .collect();

      for (const deployment of activeDeployments) {
        await ctx.db.patch(deployment._id, { status: "archived" });
      }

      // Generate deployment ID
      const deploymentId = `deploy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      // Get the next version number
      const allDeployments = await ctx.db
        .query("deployedStoryClimbData")
        .order("desc")
        .take(1);

      const latestVersion = allDeployments.length > 0 ? (allDeployments[0].version || 0) : 0;
      const newVersion = latestVersion + 1;

      // Create new deployment
      const deploymentRecord = await ctx.db.insert("deployedStoryClimbData", {
        deploymentId,
        deployedAt: Date.now(),
        deployedBy: userId,
        version: newVersion,
        status: "active",
        eventNodes: JSON.stringify(enhancedEvents),
        configurationName: args.configurationName,
        configurationId: args.configurationId,
        notes: args.notes,
      });

      return {
        success: true,
        deploymentId,
        version: newVersion,
        eventCount: enhancedEvents.length,
        message: `Successfully deployed ${enhancedEvents.length} event nodes (Version ${newVersion})`,
      };
    } catch (error) {
      console.error("Deployment error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      };
    }
  },
});

// Get the currently active deployment
export const getActiveDeployment = query({
  args: {},
  handler: async (ctx) => {
    const activeDeployment = await ctx.db
      .query("deployedStoryClimbData")
      .filter((q) => q.eq(q.field("status"), "active"))
      .first();

    if (!activeDeployment) {
      return null;
    }

    // Parse the JSON data
    try {
      return {
        deploymentId: activeDeployment.deploymentId,
        deployedAt: activeDeployment.deployedAt,
        deployedBy: activeDeployment.deployedBy,
        version: activeDeployment.version,
        status: activeDeployment.status,
        eventNodes: JSON.parse(activeDeployment.eventNodes),
        normalNodes: activeDeployment.normalNodes ? JSON.parse(activeDeployment.normalNodes) : null,
        challengerNodes: activeDeployment.challengerNodes ? JSON.parse(activeDeployment.challengerNodes) : null,
        miniBossNodes: activeDeployment.miniBossNodes ? JSON.parse(activeDeployment.miniBossNodes) : null,
        finalBossNodes: activeDeployment.finalBossNodes ? JSON.parse(activeDeployment.finalBossNodes) : null,
        configurationName: activeDeployment.configurationName,
        notes: activeDeployment.notes,
      };
    } catch (error) {
      console.error("Error parsing deployment data:", error);
      return null;
    }
  },
});

// Get deployment history
export const getDeploymentHistory = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;

    const deployments = await ctx.db
      .query("deployedStoryClimbData")
      .order("desc")
      .take(limit);

    return deployments.map(d => ({
      _id: d._id,
      deploymentId: d.deploymentId,
      deployedAt: d.deployedAt,
      deployedBy: d.deployedBy,
      version: d.version,
      status: d.status,
      configurationName: d.configurationName,
      eventCount: JSON.parse(d.eventNodes).length,
    }));
  },
});

// Rollback to a previous deployment
export const rollbackDeployment = mutation({
  args: {
    deploymentId: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    const userId = identity?.subject || "anonymous";

    try {
      // Find the deployment to rollback to
      const targetDeployment = await ctx.db
        .query("deployedStoryClimbData")
        .filter((q) => q.eq(q.field("deploymentId"), args.deploymentId))
        .first();

      if (!targetDeployment) {
        throw new Error("Deployment not found");
      }

      // Archive current active deployment
      const activeDeployments = await ctx.db
        .query("deployedStoryClimbData")
        .filter((q) => q.eq(q.field("status"), "active"))
        .collect();

      for (const deployment of activeDeployments) {
        await ctx.db.patch(deployment._id, { status: "archived" });
      }

      // Create a new deployment as a copy of the target
      const newDeploymentId = `rollback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

      const allDeployments = await ctx.db
        .query("deployedStoryClimbData")
        .order("desc")
        .take(1);

      const latestVersion = allDeployments.length > 0 ? (allDeployments[0].version || 0) : 0;
      const newVersion = latestVersion + 1;

      await ctx.db.insert("deployedStoryClimbData", {
        deploymentId: newDeploymentId,
        deployedAt: Date.now(),
        deployedBy: userId,
        version: newVersion,
        status: "active",
        eventNodes: targetDeployment.eventNodes,
        normalNodes: targetDeployment.normalNodes,
        challengerNodes: targetDeployment.challengerNodes,
        miniBossNodes: targetDeployment.miniBossNodes,
        finalBossNodes: targetDeployment.finalBossNodes,
        configurationName: targetDeployment.configurationName,
        configurationId: targetDeployment.configurationId,
        notes: `Rollback to version ${targetDeployment.version} (${targetDeployment.deploymentId})`,
      });

      return {
        success: true,
        message: `Successfully rolled back to version ${targetDeployment.version}`,
        newDeploymentId,
        newVersion,
      };
    } catch (error) {
      console.error("Rollback error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred",
      };
    }
  },
});

// Validate deployment data before deploying
export const validateDeploymentData = query({
  args: {
    eventData: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      const events = JSON.parse(args.eventData);

      const errors: string[] = [];
      const warnings: string[] = [];

      // Validate structure
      if (!Array.isArray(events)) {
        errors.push("Event data must be an array");
        return {
          isValid: false,
          errors,
          warnings,
          summary: {
            totalEvents: 0,
            totalGold: 0,
            totalXP: 0,
            hasAllEventNames: false,
            hasAllRewards: false,
          },
        };
      }

      let totalGold = 0;
      let totalXP = 0;
      let unnamedEvents = 0;
      let zeroRewardEvents = 0;

      events.forEach((event: any, index: number) => {
        // Check required fields
        if (typeof event.eventNumber !== 'number') {
          errors.push(`Event at index ${index} missing eventNumber`);
        }

        if (!event.name || event.name === `Event ${event.eventNumber}`) {
          unnamedEvents++;
        }

        if (event.goldReward === 0 && event.xpReward === 0) {
          zeroRewardEvents++;
        }

        totalGold += event.goldReward || 0;
        totalXP += event.xpReward || 0;
      });

      if (unnamedEvents > 0) {
        warnings.push(`${unnamedEvents} events have default names`);
      }

      if (zeroRewardEvents > 0) {
        warnings.push(`${zeroRewardEvents} events have no gold or XP rewards`);
      }

      if (events.length !== 200) {
        warnings.push(`Expected 200 events, found ${events.length}`);
      }

      return {
        isValid: errors.length === 0,
        errors,
        warnings,
        summary: {
          totalEvents: events.length,
          totalGold,
          totalXP,
          hasAllEventNames: unnamedEvents === 0,
          hasAllRewards: zeroRewardEvents === 0,
        },
      };
    } catch (error) {
      return {
        isValid: false,
        errors: ["Failed to parse event data: " + (error instanceof Error ? error.message : "Unknown error")],
        warnings: [],
        summary: {
          totalEvents: 0,
          totalGold: 0,
          totalXP: 0,
          hasAllEventNames: false,
          hasAllRewards: false,
        },
      };
    }
  },
});