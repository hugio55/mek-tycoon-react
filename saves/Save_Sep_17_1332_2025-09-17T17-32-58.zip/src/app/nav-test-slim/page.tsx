'use client'

import React, { useState } from 'react'
import { ChevronDown } from 'lucide-react'

export default function NavTestSlim() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)

  const navItems = [
    [
      { id: 'hub', label: 'HUB', isMain: true },
      { id: 'operations', label: 'OPERATIONS', dropdown: ['Missions', 'Contracts', 'Research'] },
      { id: 'production', label: 'PRODUCTION', dropdown: ['Factory', 'Assembly', 'Resources'] }
    ],
    [
      { id: 'meks', label: 'MEKS', dropdown: ['Collection', 'Upgrade', 'Trade'] },
      { id: 'management', label: 'MANAGEMENT', dropdown: ['Stats', 'Inventory', 'Settings'] },
      { id: 'scrapyard', label: 'SCRAP YARD', dropdown: ['Salvage', 'Parts', 'Recycle'] }
    ]
  ]

  const adminButton = { id: 'admin', label: 'ADMIN', dropdown: ['Dashboard', 'Logs', 'Config'] }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-8">
      {/* Title */}
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-orbitron uppercase tracking-wider text-yellow-500 mb-2">
          Ultra Thin Grid Navigation
        </h1>
        <p className="text-gray-400 text-xs">Super slim vertical spacing - 2 rows × 3 columns</p>
      </div>

      <div className="space-y-12">

        {/* Version 1: Ultra Thin Lines */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center">Version 1: Ultra Thin Lines</h3>
          <div className="max-w-xl mx-auto">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-1.5 mb-0.5">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full relative px-2 py-0.5
                      ${item.isMain
                        ? 'bg-black/60 border-b-2 border-yellow-400 text-yellow-300 font-bold'
                        : 'bg-black/40 border-b border-yellow-500/50 text-yellow-400/80'
                      }
                      hover:border-yellow-300 hover:text-yellow-200 hover:bg-black/70
                      transition-all duration-200
                      font-orbitron text-[10px] uppercase tracking-wider
                    `}
                  >
                    {item.label}
                    {item.dropdown && (
                      <span className="ml-0.5 text-[6px] opacity-50">▼</span>
                    )}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-1.5">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full relative px-2 py-0.5 bg-black/40 border-b border-yellow-500/50 text-yellow-400/80 hover:border-yellow-300 hover:text-yellow-200 hover:bg-black/70 transition-all duration-200 font-orbitron text-[10px] uppercase tracking-wider"
                >
                  {adminButton.label}
                  <span className="ml-0.5 text-[6px] opacity-50">▼</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Version 2: Minimal Boxes */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center">Version 2: Minimal Boxes</h3>
          <div className="max-w-lg mx-auto">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-1 mb-1">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full px-3 py-[3px]
                      ${item.isMain
                        ? 'bg-black/70 border border-yellow-400/80 text-yellow-300 font-semibold shadow-md'
                        : 'bg-black/50 border border-yellow-500/40 text-yellow-400/70'
                      }
                      hover:border-yellow-300 hover:bg-black/80 hover:text-yellow-200
                      transition-all duration-150
                      font-mono text-[9px] uppercase
                    `}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-1">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full px-3 py-[3px] bg-black/50 border border-yellow-500/40 text-yellow-400/70 hover:border-yellow-300 hover:bg-black/80 hover:text-yellow-200 transition-all duration-150 font-mono text-[9px] uppercase"
                >
                  {adminButton.label}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Version 3: Razor Thin */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center">Version 3: Razor Thin</h3>
          <div className="max-w-md mx-auto bg-black/60 backdrop-blur-sm p-1 border border-yellow-500/40 shadow-lg">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-[2px] mb-[2px]">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full px-2 h-5 flex items-center justify-center
                      ${item.isMain
                        ? 'bg-gradient-to-r from-yellow-400/30 to-orange-400/30 text-yellow-300 font-black'
                        : 'bg-black/60 text-yellow-400/80'
                      }
                      hover:bg-yellow-400/20 hover:text-yellow-200
                      transition-colors duration-150
                      text-[9px] font-bold uppercase tracking-wide
                    `}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-[2px]">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full px-2 h-5 flex items-center justify-center bg-black/60 text-yellow-400/80 hover:bg-yellow-400/20 hover:text-yellow-200 transition-colors duration-150 text-[9px] font-bold uppercase tracking-wide"
                >
                  {adminButton.label}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Version 4: Side Accent (RECOMMENDED) */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center font-bold">Version 4: Side Accent (RECOMMENDED)</h3>
          <div className="max-w-xl mx-auto">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-2 mb-1">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full relative px-3 py-[2px] text-left
                      ${item.isMain
                        ? 'bg-black/70 border-l-3 border-yellow-400 text-yellow-300 font-semibold shadow-md'
                        : 'bg-black/50 border-l-2 border-yellow-500/50 text-yellow-400/90'
                      }
                      hover:bg-black/80 hover:text-yellow-200 hover:border-yellow-300
                      transition-all duration-200
                      font-orbitron text-[10px] uppercase tracking-[0.12em]
                    `}
                  >
                    {item.label}
                    {item.dropdown && (
                      <span className="float-right text-[6px] mt-0.5 opacity-40">▼</span>
                    )}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-2">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full relative px-3 py-[2px] text-left bg-black/50 border-l-2 border-yellow-500/50 text-yellow-400/90 hover:bg-black/80 hover:text-yellow-200 hover:border-yellow-300 transition-all duration-200 font-orbitron text-[10px] uppercase tracking-[0.12em]"
                >
                  {adminButton.label}
                  <span className="float-right text-[6px] mt-0.5 opacity-40">▼</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Version 5: Flat Pills */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center">Version 5: Flat Pills</h3>
          <div className="max-w-lg mx-auto">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-1.5 mb-1">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full px-2 h-[18px] flex items-center justify-center
                      ${item.isMain
                        ? 'bg-black/70 text-yellow-300 rounded-full border-2 border-yellow-400/60 font-bold'
                        : 'bg-black/50 text-yellow-400/80 rounded-full border border-yellow-500/40'
                      }
                      hover:bg-black/80 hover:text-yellow-200 hover:border-yellow-300
                      transition-all duration-200
                      font-sans text-[9px] font-medium uppercase tracking-wider
                    `}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-1.5">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full px-2 h-[18px] flex items-center justify-center bg-black/50 text-yellow-400/80 rounded-full border border-yellow-500/40 hover:bg-black/80 hover:text-yellow-200 hover:border-yellow-300 transition-all duration-200 font-sans text-[9px] font-medium uppercase tracking-wider"
                >
                  {adminButton.label}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Version 6: Ghost Buttons */}
        <div>
          <h3 className="text-[10px] uppercase text-yellow-500/50 mb-2 text-center">Version 6: Ghost Buttons</h3>
          <div className="max-w-lg mx-auto">
            {navItems.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-3 gap-3 mb-1.5">
                {row.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveDropdown(activeDropdown === item.id ? null : item.id)}
                    className={`
                      w-full py-1 px-2 relative group
                      ${item.isMain
                        ? 'text-yellow-300 bg-black/60 font-bold'
                        : 'text-yellow-400/70 bg-black/40'
                      }
                      hover:text-yellow-200 hover:bg-black/70
                      transition-all duration-200
                      font-orbitron text-[10px] uppercase tracking-[0.15em]
                    `}
                  >
                    {item.label}
                    {/* Underline on hover */}
                    <div className={`absolute bottom-0 left-0 right-0 h-[1px] ${
                      item.isMain ? 'bg-yellow-400' : 'bg-yellow-600/0'
                    } group-hover:bg-yellow-300 transition-all duration-200`} />
                  </button>
                ))}
              </div>
            ))}
            <div className="grid grid-cols-3 gap-3">
              <div className="col-start-3">
                <button
                  onClick={() => setActiveDropdown(activeDropdown === adminButton.id ? null : adminButton.id)}
                  className="w-full py-1 px-2 relative group text-yellow-400/70 bg-black/40 hover:text-yellow-200 hover:bg-black/70 transition-all duration-200 font-orbitron text-[10px] uppercase tracking-[0.15em]"
                >
                  {adminButton.label}
                  <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-yellow-600/0 group-hover:bg-yellow-300 transition-all duration-200" />
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}