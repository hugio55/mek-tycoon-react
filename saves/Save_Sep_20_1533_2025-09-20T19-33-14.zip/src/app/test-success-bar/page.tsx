'use client';

import React, { useState } from 'react';
import SuccessBar from '@/components/SuccessBar';
import { DifficultyConfig } from '@/lib/difficultyModifiers';

export default function TestSuccessBar() {
  const [layoutStyle, setLayoutStyle] = useState<1 | 2 | 3 | 4 | 5>(1);
  const [successRate, setSuccessRate] = useState(65);
  const [greenLine, setGreenLine] = useState(50);

  // Sample difficulty config
  const difficultyConfig: DifficultyConfig = {
    nodeType: 'normal',
    difficulty: 'medium',
    displayName: 'Medium',
    successGreenLine: greenLine,
    goldMultiplier: 1.5,
    xpMultiplier: 1.5,
    deploymentCostMultiplier: 1.5,
    overshootBonusRate: 1,
    maxOvershootBonus: 50,
    essenceAmountMultiplier: 1.5,
    requiredSuccess: 50
  };

  const layoutDescriptions = [
    'Vertical Stacked Card - Success on top with large display, rewards stacked below',
    'Two-Row Horizontal - Success spanning full width, rewards in grid below',
    'Grid Modular 2x2 - Success takes hero spot, rewards in modular cells',
    'Asymmetric Hero - Success prominent on left, compact rewards on right',
    'Compact Badge/Pills - Minimal horizontal layout with pill-shaped elements'
  ];

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-yellow-400 mb-8">Success Bar Layout Testing</h1>

        {/* Controls */}
        <div className="bg-gray-900 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Controls</h2>

          <div className="grid grid-cols-2 gap-6">
            {/* Success Rate Control */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Success Rate: {successRate}%</label>
              <input
                type="range"
                min="0"
                max="100"
                value={successRate}
                onChange={(e) => setSuccessRate(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Green Line Control */}
            <div>
              <label className="text-sm text-gray-400 block mb-2">Green Line: {greenLine}%</label>
              <input
                type="range"
                min="0"
                max="100"
                value={greenLine}
                onChange={(e) => setGreenLine(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0%</span>
                <span>50%</span>
                <span>100%</span>
              </div>
            </div>
          </div>

          {/* Quick Set Buttons */}
          <div className="mt-4 flex gap-2">
            <button
              onClick={() => { setSuccessRate(25); setGreenLine(50); }}
              className="px-3 py-1 bg-red-800 text-white rounded text-sm"
            >
              Below Green
            </button>
            <button
              onClick={() => { setSuccessRate(50); setGreenLine(50); }}
              className="px-3 py-1 bg-yellow-800 text-white rounded text-sm"
            >
              At Green Line
            </button>
            <button
              onClick={() => { setSuccessRate(75); setGreenLine(50); }}
              className="px-3 py-1 bg-green-800 text-white rounded text-sm"
            >
              Overshoot +25%
            </button>
            <button
              onClick={() => { setSuccessRate(100); setGreenLine(50); }}
              className="px-3 py-1 bg-blue-800 text-white rounded text-sm"
            >
              Max Overshoot
            </button>
          </div>
        </div>

        {/* Layout Selector */}
        <div className="bg-gray-900 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Select Layout Variation</h2>
          <div className="grid grid-cols-5 gap-3">
            {[1, 2, 3, 4, 5].map((layout) => (
              <button
                key={layout}
                onClick={() => setLayoutStyle(layout as 1 | 2 | 3 | 4 | 5)}
                className={`
                  p-4 rounded-lg border-2 transition-all
                  ${layoutStyle === layout
                    ? 'bg-yellow-500/20 border-yellow-400 text-yellow-400'
                    : 'bg-black/40 border-gray-600 text-gray-400 hover:border-gray-400'
                  }
                `}
              >
                <div className="text-2xl font-bold mb-2">Layout {layout}</div>
                <div className="text-xs">
                  {['Vertical', 'Two-Row', 'Grid', 'Asymmetric', 'Compact'][layout - 1]}
                </div>
              </button>
            ))}
          </div>
          <div className="mt-4 text-sm text-gray-400 bg-black/40 p-3 rounded">
            <strong>Current:</strong> {layoutDescriptions[layoutStyle - 1]}
          </div>
        </div>

        {/* Success Bar Display */}
        <div className="bg-gray-900 rounded-lg p-6">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Success Bar Preview</h2>
          <div className="bg-black p-6 rounded">
            <SuccessBar
              currentSuccess={successRate}
              difficultyConfig={difficultyConfig}
              layoutStyle={layoutStyle}
              baseRewards={{ gold: 1000, xp: 500 }}
              mekContributions={[
                { mekId: '1', name: 'MEK #1234', rank: 5, contribution: 15 },
                { mekId: '2', name: 'MEK #5678', rank: 3, contribution: 10 },
                { mekId: '3', name: 'MEK #9012', rank: 7, contribution: 20 }
              ]}
              showDetails={false}
            />
          </div>
        </div>

        {/* Side by Side Comparison */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">All Layouts Side by Side</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[1, 2, 3, 4, 5].map((layout) => (
              <div key={layout} className="bg-gray-900 rounded-lg p-4">
                <h3 className="text-sm font-bold text-yellow-400 mb-3">
                  Layout {layout}: {['Vertical Stack', 'Two-Row', 'Grid', 'Asymmetric', 'Compact'][layout - 1]}
                </h3>
                <div className="bg-black p-4 rounded">
                  <SuccessBar
                    currentSuccess={successRate}
                    difficultyConfig={difficultyConfig}
                    layoutStyle={layout as 1 | 2 | 3 | 4 | 5}
                    baseRewards={{ gold: 1000, xp: 500 }}
                    showDetails={false}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}