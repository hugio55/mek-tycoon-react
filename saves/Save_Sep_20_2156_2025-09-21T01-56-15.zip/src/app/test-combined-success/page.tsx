'use client';

import React, { useState } from 'react';
import { DifficultyConfig } from '@/lib/difficultyModifiers';

export default function TestCombinedSuccess() {
  const [successRate, setSuccessRate] = useState(52);
  const [greenLine, setGreenLine] = useState(31);
  const [selectedVariation, setSelectedVariation] = useState<1 | 2 | 3 | 4>(1);

  // Sample difficulty config
  const difficultyConfig: DifficultyConfig = {
    nodeType: 'normal',
    difficulty: 'medium',
    displayName: 'Medium',
    successGreenLine: greenLine,
    goldMultiplier: 1.5,
    xpMultiplier: 1.5,
    deploymentCostMultiplier: 1.5,
    overshootBonusRate: 1,
    maxOvershootBonus: 50,
    essenceAmountMultiplier: 1.5,
    requiredSuccess: 50
  };

  const baseRewards = { gold: 1000, xp: 500 };

  // Calculate overshoot bonus
  const overshootBonus = successRate > greenLine
    ? Math.min((successRate - greenLine) * difficultyConfig.overshootBonusRate, difficultyConfig.maxOvershootBonus)
    : 0;

  // Determine success likelihood term
  const getSuccessLikelihood = (currentPercent: number, greenLinePercent: number) => {
    if (currentPercent >= greenLinePercent) return 'Certain';
    if (greenLinePercent === 0) return 'Certain';
    const relativePercent = (currentPercent / greenLinePercent) * 100;

    if (relativePercent === 0) return 'Impossible';
    if (relativePercent <= 5) return 'Extremely Unlikely';
    if (relativePercent < 20) return 'Very Unlikely';
    if (relativePercent < 35) return 'Unlikely';
    if (relativePercent < 45) return 'Doubtful';
    if (relativePercent < 55) return 'Uncertain';
    if (relativePercent < 65) return 'Possible';
    if (relativePercent < 80) return 'Likely';
    if (relativePercent < 90) return 'Very Likely';
    if (relativePercent < 95) return 'Highly Likely';
    return 'Extremely Likely';
  };

  const renderCombinedSuccess = (variant: number) => {
    return (
      <div className="w-full max-w-md mx-auto">
        {/* Cinematic Sci-Fi Text from Improved Variant 4 - EXACT COPY WITH DIVIDER LINE */}
        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-96 h-1 bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent"></div>
          </div>
          <div className="relative text-center">
            <h2 className="text-3xl font-black uppercase tracking-[0.6em]"
                style={{
                  fontFamily: 'Orbitron, monospace',
                  background: 'linear-gradient(180deg, #fff 0%, #facc15 50%, #f59e0b 100%)',
                  backgroundClip: 'text',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  filter: 'drop-shadow(0 4px 8px rgba(250, 204, 21, 0.4))'
                }}>
              SUCCESS METER
            </h2>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-32 bg-yellow-500/20 rounded-full blur-3xl animate-pulse"></div>
          </div>
        </div>

        {/* Holographic Modern Bar from Improved Variant 2 - EXACT CORRECT COPY */}
        <div className="relative h-20 rounded-2xl overflow-hidden shadow-2xl"
             style={{
               background: 'linear-gradient(135deg, rgba(15, 15, 15, 0.9), rgba(30, 30, 30, 0.9))',
               backdropFilter: 'blur(10px)',
               border: '2px solid rgba(250, 204, 21, 0.3)'
             }}>

          {/* Holographic shimmer background */}
          <div className="absolute inset-0 opacity-30"
               style={{
                 background: 'linear-gradient(45deg, transparent 30%, rgba(250, 204, 21, 0.1) 50%, transparent 70%)',
                 animation: 'slide 4s infinite'
               }}></div>

          {/* Base track */}
          <div className="absolute inset-2 bg-black/50 rounded-xl">
            {/* Normal fill */}
            <div className="absolute inset-0 rounded-xl overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 transition-all duration-700 ease-out"
                style={{
                  width: `${Math.min(greenLine, successRate)}%`,
                  background: 'linear-gradient(90deg, #dc2626, #f59e0b, #facc15)',
                  filter: 'brightness(1.2)'
                }}>
                <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent"></div>
              </div>

              {/* Overshoot with intense glow */}
              {successRate > greenLine && (
                <div
                  className="absolute inset-y-0 transition-all duration-700 ease-out"
                  style={{
                    left: `${greenLine}%`,
                    width: `${successRate - greenLine}%`,
                    background: 'linear-gradient(90deg, #22c55e, #4ade80, #86efac)',
                    boxShadow: '0 0 40px #4ade80, inset 0 0 30px rgba(74, 222, 128, 0.5)',
                    filter: 'brightness(1.3)'
                  }}>
                  <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-transparent"></div>
                  <div className="absolute inset-0 animate-pulse bg-green-400/20"></div>
                </div>
              )}
            </div>

            {/* Goalpost with glow orb */}
            <div className="absolute top-0 bottom-0" style={{ left: `${greenLine}%` }}>
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2">
                {/* Glowing orb */}
                <div className="w-6 h-6 rounded-full bg-green-400"
                     style={{
                       boxShadow: '0 0 20px #4ade80, 0 0 40px #4ade80, 0 0 60px #22c55e'
                     }}></div>
                {/* Center dot */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Percentage under goalpost */}
        <div className="relative h-10 mt-2">
          <div className="absolute" style={{ left: `${greenLine}%`, transform: 'translateX(-50%)' }}>
            <div className="relative">
              <div className="absolute inset-0 bg-green-500/30 blur-xl"></div>
              <div className="relative bg-black/90 border-2 border-green-500/60 px-3 py-1 rounded-full">
                <span className="text-sm font-bold text-green-400 font-['Orbitron']">
                  GOAL: {greenLine}%
                </span>
              </div>
            </div>
          </div>
          {/* Current percentage */}
          {successRate !== greenLine && (
            <div className="absolute" style={{ left: `${successRate}%`, transform: 'translateX(-50%)' }}>
              <div className="bg-black/80 px-2 py-0.5 rounded text-xs text-gray-400">
                {successRate.toFixed(0)}%
              </div>
            </div>
          )}
        </div>

        {/* Mission Status Card - Different Variations */}
        {variant === 1 && (
          /* Variation 1: Original Style with Split Layout */
          <div className="mt-4 relative bg-black/90 border-2 border-yellow-500/50 shadow-2xl overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{
              backgroundImage: `linear-gradient(135deg, transparent 25%, rgba(250, 204, 21, 0.1) 25%, rgba(250, 204, 21, 0.1) 50%, transparent 50%, transparent 75%, rgba(250, 204, 21, 0.1) 75%, rgba(250, 204, 21, 0.1))`,
              backgroundSize: '20px 20px'
            }}></div>

            <div className="relative z-10">
              <div className="bg-gradient-to-b from-yellow-500/10 to-transparent px-4 py-3 flex items-center justify-between">
                <div className="text-left">
                  <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">MISSION STATUS</div>
                  <div className={`font-bold font-['Orbitron'] uppercase text-xl ${
                    successRate >= greenLine ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {getSuccessLikelihood(successRate, greenLine)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">OVERSHOOT</div>
                  <div className={`text-2xl font-bold font-['Orbitron'] ${
                    overshootBonus > 0 ? 'text-green-400' : 'text-gray-600'
                  }`} style={overshootBonus > 0 ? {
                    textShadow: '0 0 10px rgba(34, 197, 94, 0.8)',
                    filter: 'brightness(1.2)'
                  } : {}}>
                    {overshootBonus.toFixed(0)}%
                  </div>
                </div>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent"></div>

              <div className="px-4 py-3 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-yellow-500">Gold:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs tabular-nums text-gray-500">
                      {Math.round(baseRewards.gold * difficultyConfig.goldMultiplier).toLocaleString()}
                    </span>
                    <span className="text-xs text-yellow-500">→</span>
                    <span className="text-sm font-bold tabular-nums text-yellow-400">
                      {Math.round(baseRewards.gold * difficultyConfig.goldMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-blue-500">XP:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs tabular-nums text-gray-500">
                      {Math.round(baseRewards.xp * difficultyConfig.xpMultiplier).toLocaleString()}
                    </span>
                    <span className="text-xs text-blue-500">→</span>
                    <span className="text-sm font-bold tabular-nums text-blue-400">
                      {Math.round(baseRewards.xp * difficultyConfig.xpMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-green-500">Essence:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs tabular-nums text-gray-500">
                      {difficultyConfig.essenceAmountMultiplier.toFixed(1)}x
                    </span>
                    <span className="text-xs text-green-500">→</span>
                    <span className="text-sm font-bold tabular-nums text-green-400">
                      {(difficultyConfig.essenceAmountMultiplier * (1 + overshootBonus / 100)).toFixed(1)}x
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {variant === 2 && (
          /* Variation 2: Compact with Inline Overshoot */
          <div className="mt-4 relative bg-black/90 border-2 border-yellow-500/50 shadow-2xl overflow-hidden">
            <div className="relative z-10">
              <div className="bg-gradient-to-b from-yellow-500/10 to-transparent px-4 py-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div>
                      <div className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">STATUS</div>
                      <div className={`font-bold font-['Orbitron'] uppercase text-lg ${
                        successRate >= greenLine ? 'text-green-400' : 'text-yellow-400'
                      }`}>
                        {getSuccessLikelihood(successRate, greenLine)}
                      </div>
                    </div>
                    <div className="h-8 w-px bg-gray-600"></div>
                    <div>
                      <div className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">OVS</div>
                      <div className={`text-lg font-bold font-['Orbitron'] ${
                        overshootBonus > 0 ? 'text-green-400' : 'text-gray-600'
                      }`}>
                        +{overshootBonus.toFixed(0)}%
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent"></div>

              <div className="px-3 py-2">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <div className="text-[9px] text-yellow-500 uppercase font-bold">Gold</div>
                    <div className="text-sm font-bold text-yellow-400 tabular-nums">
                      {Math.round(baseRewards.gold * difficultyConfig.goldMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-[9px] text-blue-500 uppercase font-bold">XP</div>
                    <div className="text-sm font-bold text-blue-400 tabular-nums">
                      {Math.round(baseRewards.xp * difficultyConfig.xpMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-[9px] text-green-500 uppercase font-bold">Essence</div>
                    <div className="text-sm font-bold text-green-400 tabular-nums">
                      {(difficultyConfig.essenceAmountMultiplier * (1 + overshootBonus / 100)).toFixed(1)}x
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {variant === 3 && (
          /* Variation 3: Clean Modern with Badge */
          <div className="mt-4 relative bg-gradient-to-b from-gray-900 to-black border border-cyan-500/30 shadow-[0_0_20px_rgba(0,255,255,0.2)] overflow-hidden rounded-lg">
            <div className="relative z-10">
              <div className="px-4 py-3 relative">
                <div className="text-center">
                  <div className="text-[10px] font-bold text-cyan-400/70 uppercase tracking-wider mb-1">MISSION STATUS</div>
                  <div className={`font-bold font-['Orbitron'] uppercase text-2xl ${
                    successRate >= greenLine ? 'text-green-400' : 'text-yellow-400'
                  }`} style={{
                    textShadow: successRate >= greenLine ? '0 0 20px rgba(34, 197, 94, 0.8)' : '0 0 20px rgba(250, 204, 21, 0.5)'
                  }}>
                    {getSuccessLikelihood(successRate, greenLine)}
                  </div>
                </div>
                {/* Floating Overshoot Badge */}
                <div className="absolute top-2 right-2">
                  <div className={`px-2 py-1 rounded-full border ${
                    overshootBonus > 0
                      ? 'bg-gradient-to-r from-green-500/20 to-cyan-500/20 border-green-500/50'
                      : 'bg-gray-800/40 border-gray-600/40'
                  }`}>
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-gray-400 uppercase">OVS</span>
                      <span className={`text-base font-bold font-['Orbitron'] ${
                        overshootBonus > 0 ? 'text-green-400' : 'text-gray-600'
                      }`}>
                        {overshootBonus.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent"></div>

              <div className="px-4 py-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-yellow-400/80">Gold:</span>
                  <span className="text-sm font-bold tabular-nums text-yellow-400">
                    {Math.round(baseRewards.gold * difficultyConfig.goldMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-blue-400/80">XP:</span>
                  <span className="text-sm font-bold tabular-nums text-blue-400">
                    {Math.round(baseRewards.xp * difficultyConfig.xpMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs uppercase font-bold text-green-400/80">Essence:</span>
                  <span className="text-sm font-bold tabular-nums text-green-400">
                    {(difficultyConfig.essenceAmountMultiplier * (1 + overshootBonus / 100)).toFixed(1)}x
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {variant === 4 && (
          /* Variation 4: Data-First with Large Numbers */
          <div className="mt-4 relative bg-black/90 border-2 border-yellow-500/50 shadow-2xl overflow-hidden">
            <div className="relative z-10">
              <div className="bg-gradient-to-b from-yellow-500/10 to-transparent px-4 py-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">MISSION STATUS</div>
                    <div className={`font-bold font-['Orbitron'] uppercase text-lg ${
                      successRate >= greenLine ? 'text-green-400' : 'text-yellow-400'
                    }`}>
                      {getSuccessLikelihood(successRate, greenLine)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold font-['Orbitron'] ${
                      overshootBonus > 0 ? 'text-green-400' : 'text-gray-600'
                    }`} style={overshootBonus > 0 ? {
                      textShadow: '0 0 15px rgba(34, 197, 94, 1)',
                      filter: 'brightness(1.3)'
                    } : {}}>
                      {overshootBonus.toFixed(0)}%
                    </div>
                    <div className="text-[8px] font-bold text-gray-500 uppercase tracking-wider -mt-1">OVERSHOOT</div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-gradient-to-r from-transparent via-yellow-500/50 to-transparent"></div>

              <div className="px-4 py-3">
                <div className="flex justify-around">
                  <div className="text-center">
                    <div className="text-xl font-bold text-yellow-400 tabular-nums">
                      {Math.round(baseRewards.gold * difficultyConfig.goldMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </div>
                    <div className="text-[9px] text-yellow-500 uppercase font-bold">Gold</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-blue-400 tabular-nums">
                      {Math.round(baseRewards.xp * difficultyConfig.xpMultiplier * (1 + overshootBonus / 100)).toLocaleString()}
                    </div>
                    <div className="text-[9px] text-blue-500 uppercase font-bold">XP</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-green-400 tabular-nums">
                      {(difficultyConfig.essenceAmountMultiplier * (1 + overshootBonus / 100)).toFixed(1)}x
                    </div>
                    <div className="text-[9px] text-green-500 uppercase font-bold">Essence</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-yellow-400 mb-8">Combined Success Meter Test</h1>

        {/* Controls */}
        <div className="bg-gray-900 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Controls</h2>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="text-sm text-gray-400 block mb-2">Success Rate: {successRate}%</label>
              <input
                type="range"
                min="0"
                max="100"
                value={successRate}
                onChange={(e) => setSuccessRate(Number(e.target.value))}
                className="w-full"
              />
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-2">Green Line: {greenLine}%</label>
              <input
                type="range"
                min="0"
                max="100"
                value={greenLine}
                onChange={(e) => setGreenLine(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Variation Selector */}
        <div className="bg-gray-900 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Select Variation</h2>
          <div className="grid grid-cols-4 gap-3">
            {[
              { id: 1, name: 'Original Split', desc: 'Mission left, overshoot right with arrows' },
              { id: 2, name: 'Compact Inline', desc: 'Status and overshoot side-by-side' },
              { id: 3, name: 'Modern Badge', desc: 'Clean with floating overshoot badge' },
              { id: 4, name: 'Data Priority', desc: 'Large numbers with labels below' }
            ].map((variant) => (
              <button
                key={variant.id}
                onClick={() => setSelectedVariation(variant.id as 1 | 2 | 3 | 4)}
                className={`
                  p-3 rounded-lg border-2 transition-all
                  ${selectedVariation === variant.id
                    ? 'bg-purple-500/20 border-purple-400 text-purple-400'
                    : 'bg-black/40 border-gray-600 text-gray-400 hover:border-gray-400'
                  }
                `}
              >
                <div className="text-lg font-bold mb-1">V{variant.id}</div>
                <div className="text-xs font-bold mb-1">{variant.name}</div>
                <div className="text-[10px] text-gray-500">{variant.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Current Selection Display */}
        <div className="bg-gray-900 rounded-lg p-6 mb-8">
          <h2 className="text-xl font-bold text-gray-300 mb-4">Current Selection: Variation {selectedVariation}</h2>
          {renderCombinedSuccess(selectedVariation)}
        </div>

        {/* All Variations Side by Side */}
        <div className="bg-gray-900 rounded-lg p-6">
          <h2 className="text-xl font-bold text-gray-300 mb-4">All Variations</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((variant) => (
              <div key={variant} className="bg-black p-4 rounded">
                <h3 className="text-sm font-bold text-purple-400 mb-3 text-center">
                  Variation {variant}
                </h3>
                {renderCombinedSuccess(variant)}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Animation Styles */}
      <style jsx>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-20deg); }
          100% { transform: translateX(200%) skewX(-20deg); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 0.6; }
        }
        @keyframes glow-pulse {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
        @keyframes slide {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}