'use client';

import React, { useState, useEffect } from 'react';

interface TitleCardProps {
  chapter: string;
}

// Variation 1: Holographic Projection
export const HolographicTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 flex items-center justify-center bg-black/40 backdrop-blur-xl border-b border-cyan-500/30">
    <div className="relative">
      {/* Holographic scan lines */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        <div className="hologram-scanlines absolute inset-0"></div>
      </div>

      {/* Glowing frame */}
      <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/0 via-cyan-400/50 to-cyan-500/0 blur-xl"></div>

      {/* Main content */}
      <div className="relative bg-gradient-to-r from-black/50 via-cyan-950/30 to-black/50 px-12 py-3 border border-cyan-400/40">
        <h1 className="text-2xl font-orbitron font-bold tracking-[0.3em] text-cyan-300 uppercase flex items-center gap-6">
          <span className="text-3xl bg-clip-text text-transparent bg-gradient-to-r from-cyan-200 to-cyan-400">
            STORY MODE
          </span>
          <span className="text-cyan-500/50 text-xl">•</span>
          <span className="text-lg text-cyan-400/80 tracking-[0.2em] animate-pulse">
            {chapter}
          </span>
        </h1>
      </div>

      {/* Corner accents */}
      <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400"></div>
      <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400"></div>
      <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400"></div>
      <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400"></div>
    </div>
  </div>
);

// Variation 2: Circuit Board Matrix
export const CircuitBoardTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-gradient-to-b from-gray-900 to-black border-b-2 border-green-500/40">
    <div className="relative h-full flex items-center justify-center overflow-hidden">
      {/* Circuit pattern background */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <pattern id="circuit" x="0" y="0" width="50" height="50" patternUnits="userSpaceOnUse">
            <circle cx="25" cy="25" r="2" fill="#10b981"/>
            <path d="M25,5 L25,45 M5,25 L45,25" stroke="#10b981" strokeWidth="0.5" opacity="0.5"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#circuit)"/>
        </svg>
      </div>

      {/* Main title container */}
      <div className="relative px-16 py-3">
        <div className="flex items-center gap-8">
          {/* Left circuit node */}
          <div className="w-2 h-2 bg-green-400 rounded-full shadow-[0_0_10px_#10b981] animate-pulse"></div>

          <div className="relative">
            <h1 className="text-2xl font-mono font-bold uppercase tracking-[0.2em]">
              <span className="text-green-300">STORY_MODE</span>
              <span className="text-green-500/60 mx-4">::</span>
              <span className="text-green-400/80 text-lg">{chapter}</span>
            </h1>

            {/* Data flow lines */}
            <div className="absolute -bottom-2 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-green-500 to-transparent"></div>
          </div>

          {/* Right circuit node */}
          <div className="w-2 h-2 bg-green-400 rounded-full shadow-[0_0_10px_#10b981] animate-pulse"></div>
        </div>
      </div>

      {/* Binary data stream */}
      <div className="absolute bottom-1 left-0 text-green-500/20 text-[10px] font-mono whitespace-nowrap overflow-hidden">
        <div className="inline-block animate-slide-left">
          01001101 01000101 01001011 00100000 01010100 01011001 01000011 01001111 01001111 01001110
        </div>
      </div>
    </div>
  </div>
);

// Variation 3: Glitch Distortion
export const GlitchTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-black border-b border-red-900/50 overflow-hidden">
    <div className="relative h-full flex items-center justify-center">
      {/* Glitch background layers */}
      <div className="absolute inset-0 glitch-bg opacity-30"></div>

      <div className="relative">
        {/* Main title with glitch effect */}
        <div className="relative">
          <h1 className="text-2xl font-bold font-orbitron uppercase tracking-[0.25em] text-white">
            <span className="relative inline-block glitch-text" data-text="STORY MODE">
              STORY MODE
            </span>
            <span className="mx-6 text-red-500">▸</span>
            <span className="text-lg text-red-400/90 tracking-wider glitch-text-subtle" data-text={chapter}>
              {chapter}
            </span>
          </h1>

          {/* RGB split effect overlays */}
          <div className="absolute inset-0 pointer-events-none">
            <h1 className="text-2xl font-bold font-orbitron uppercase tracking-[0.25em] text-red-500/30 blur-[1px] transform translate-x-[2px]">
              STORY MODE <span className="mx-6 opacity-0">▸</span> <span className="text-lg tracking-wider">{chapter}</span>
            </h1>
          </div>
          <div className="absolute inset-0 pointer-events-none">
            <h1 className="text-2xl font-bold font-orbitron uppercase tracking-[0.25em] text-blue-500/30 blur-[1px] transform -translate-x-[2px]">
              STORY MODE <span className="mx-6 opacity-0">▸</span> <span className="text-lg tracking-wider">{chapter}</span>
            </h1>
          </div>
        </div>

        {/* Static noise bars */}
        <div className="absolute -top-1 left-0 right-0 h-[2px] bg-red-500/50 animate-glitch-bar-1"></div>
        <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-blue-500/30 animate-glitch-bar-2"></div>
      </div>
    </div>
  </div>
);

// Variation 4: Neon Cyberpunk
export const NeonCyberpunkTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-gradient-to-b from-purple-950/90 via-black to-black backdrop-blur-sm border-b-2 border-pink-500/50">
    <div className="relative h-full flex items-center justify-center">
      {/* Neon glow background */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/10 via-pink-600/10 to-purple-600/10"></div>

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full" style={{
          backgroundImage: 'linear-gradient(#ff00ff20 1px, transparent 1px), linear-gradient(90deg, #ff00ff20 1px, transparent 1px)',
          backgroundSize: '20px 20px'
        }}></div>
      </div>

      <div className="relative px-12 py-3">
        {/* Neon frame */}
        <div className="absolute inset-0 border-2 border-pink-500/50 shadow-[0_0_20px_#ec4899,inset_0_0_20px_#ec489920]"></div>

        {/* Title content */}
        <h1 className="relative text-2xl font-bold uppercase tracking-[0.3em] flex items-center gap-6">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 drop-shadow-[0_0_20px_#ec4899] font-orbitron">
            STORY MODE
          </span>
          <span className="text-pink-500 animate-pulse text-xl">◆</span>
          <span className="text-lg text-pink-300 tracking-[0.2em] drop-shadow-[0_0_10px_#ec4899]">
            {chapter}
          </span>
        </h1>

        {/* Neon accent lines */}
        <div className="absolute -bottom-3 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-pink-500 to-transparent shadow-[0_0_10px_#ec4899]"></div>
      </div>
    </div>
  </div>
);

// Variation 5: Military HUD
export const MilitaryHUDTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-gradient-to-b from-green-950/90 to-black border-b border-green-500/50">
    <div className="relative h-full flex items-center">
      {/* Tactical grid overlay */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full">
          <pattern id="tactical-grid" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
            <rect width="40" height="40" fill="none" stroke="#22c55e" strokeWidth="0.5" opacity="0.5"/>
            <circle cx="20" cy="20" r="1" fill="#22c55e" opacity="0.7"/>
          </pattern>
          <rect width="100%" height="100%" fill="url(#tactical-grid)"/>
        </svg>
      </div>

      {/* Left side: Status indicators */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 animate-pulse"></div>
          <span className="text-green-500 text-[10px] font-mono">ACTIVE</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400"></div>
          <span className="text-green-500 text-[10px] font-mono">SECURE</span>
        </div>
      </div>

      {/* Center: Main title */}
      <div className="flex-1 flex justify-center">
        <div className="relative">
          <div className="bg-black/60 border border-green-500/50 px-8 py-3">
            <h1 className="text-xl font-mono uppercase tracking-[0.3em] text-green-300 flex items-center gap-4">
              <span className="text-[10px] text-green-500/70">▶</span>
              <span>STORY MODE</span>
              <span className="text-green-500/50">|</span>
              <span className="text-lg text-green-400/90">{chapter}</span>
              <span className="text-[10px] text-green-500/70">◀</span>
            </h1>
          </div>

          {/* Corner brackets */}
          <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-green-400"></div>
          <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-green-400"></div>
          <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-green-400"></div>
          <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-green-400"></div>
        </div>
      </div>

      {/* Right side: Coordinates */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-green-500 font-mono text-[10px]">
        <div>LAT: 47.6062°</div>
        <div>LON: -122.3321°</div>
      </div>
    </div>
  </div>
);

// Variation 6: Space Station Display
export const SpaceStationTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-24 bg-gradient-to-b from-slate-900 to-black border-b border-blue-500/30">
    <div className="max-w-[1600px] mx-auto px-5">
      <div className="relative h-24">
      {/* Starfield background */}
      <div className="absolute inset-0 opacity-30">
        <div className="stars-bg absolute inset-0"></div>
      </div>

      {/* Texture overlay for gradient */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/10 to-transparent"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(
            90deg,
            transparent,
            transparent 2px,
            rgba(100, 181, 246, 0.05) 2px,
            rgba(100, 181, 246, 0.05) 4px
          ), repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            rgba(100, 181, 246, 0.03) 2px,
            rgba(100, 181, 246, 0.03) 4px
          )`
        }}></div>
      </div>

      {/* Main display panel */}
      <div className="relative h-full flex items-center justify-center">
        <div className="relative">
          {/* Outer frame with rivets */}
          <div className="bg-gradient-to-b from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-slate-600/50 px-16 py-4 rounded-sm">
            {/* Rivet details */}
            <div className="absolute top-1 left-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute top-1 right-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute bottom-1 left-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute bottom-1 right-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>

            {/* Title content */}
            <h1 className="text-2xl font-orbitron font-bold uppercase tracking-[0.4em] flex items-center gap-6">
              <span className="text-blue-300 drop-shadow-[0_0_10px_#60a5fa]">
                STORY MODE
              </span>
              <span className="flex items-center gap-2">
                <span className="w-1 h-4 bg-blue-400/60"></span>
                <span className="w-1 h-4 bg-blue-400/80"></span>
                <span className="w-1 h-4 bg-blue-400"></span>
              </span>
              <span className="text-lg text-blue-400/90 tracking-[0.3em]">
                {chapter}
              </span>
            </h1>
          </div>

          {/* Status lights */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
            <div className="w-2 h-2 bg-blue-400 rounded-full shadow-[0_0_5px_#60a5fa] animate-pulse"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full shadow-[0_0_5px_#60a5fa] animate-pulse delay-150"></div>
            <div className="w-2 h-2 bg-blue-400 rounded-full shadow-[0_0_5px_#60a5fa] animate-pulse delay-300"></div>
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
);

// Variation 7: Matrix Data Stream
export const MatrixDataTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-black border-b border-green-500/30 overflow-hidden">
    <div className="relative h-full">
      {/* Falling matrix code background */}
      <div className="absolute inset-0 opacity-20">
        <div className="matrix-rain absolute inset-0"></div>
      </div>

      {/* Main title */}
      <div className="relative h-full flex items-center justify-center">
        <div className="relative">
          {/* Terminal window frame */}
          <div className="bg-black/80 border border-green-500/50 shadow-[0_0_30px_#22c55e20]">
            {/* Terminal header */}
            <div className="bg-green-900/30 border-b border-green-500/30 px-2 py-1 flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-green-500 text-[10px] font-mono">SYSTEM://STORY_MODE</span>
            </div>

            {/* Terminal content */}
            <div className="px-8 py-2">
              <h1 className="text-xl font-mono uppercase text-green-400 flex items-center gap-4">
                <span className="text-green-500 animate-pulse">&gt;</span>
                <span className="tracking-[0.2em]">STORY MODE</span>
                <span className="text-green-600">::</span>
                <span className="text-lg text-green-500/90">{chapter}</span>
                <span className="inline-block w-2 h-4 bg-green-400 animate-blink ml-1"></span>
              </h1>
            </div>
          </div>

          {/* Matrix code accent */}
          <div className="absolute -top-2 -right-2 text-green-500/30 font-mono text-xs">
            <div>01110011</div>
            <div>01110100</div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

// Variation 8: Industrial Warning System
export const IndustrialWarningTitle: React.FC<TitleCardProps> = ({ chapter }) => (
  <div className="sticky top-0 z-50 h-20 bg-gradient-to-b from-gray-900 to-black border-b-2 border-yellow-500/50">
    <div className="relative h-full overflow-hidden">
      {/* Hazard stripes background */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, #eab308, #eab308 10px, #000000 10px, #000000 20px)'
        }}></div>
      </div>

      {/* Metal texture overlay */}
      <div className="absolute inset-0 opacity-20">
        <div className="metal-texture w-full h-full"></div>
      </div>

      {/* Main content */}
      <div className="relative h-full flex items-center justify-center">
        <div className="relative">
          {/* Industrial frame */}
          <div className="bg-gradient-to-b from-gray-800/80 to-gray-900/80 backdrop-blur-sm border-2 border-yellow-500/60 px-12 py-3">
            {/* Bolt decorations */}
            <div className="absolute top-2 left-2 w-3 h-3 bg-gray-700 rounded-full border border-gray-600 shadow-inner"></div>
            <div className="absolute top-2 right-2 w-3 h-3 bg-gray-700 rounded-full border border-gray-600 shadow-inner"></div>
            <div className="absolute bottom-2 left-2 w-3 h-3 bg-gray-700 rounded-full border border-gray-600 shadow-inner"></div>
            <div className="absolute bottom-2 right-2 w-3 h-3 bg-gray-700 rounded-full border border-gray-600 shadow-inner"></div>

            {/* Title text */}
            <h1 className="text-2xl font-orbitron font-black uppercase tracking-[0.3em] flex items-center gap-6">
              <span className="text-yellow-400 drop-shadow-[0_2px_4px_#00000080]">
                STORY MODE
              </span>
              <span className="flex gap-1">
                <span className="w-1 h-6 bg-yellow-500/60"></span>
                <span className="w-1 h-6 bg-yellow-500/80"></span>
                <span className="w-1 h-6 bg-yellow-500"></span>
              </span>
              <span className="text-lg text-yellow-500/90 tracking-[0.25em]">
                {chapter}
              </span>
            </h1>
          </div>

          {/* Warning lights */}
          <div className="absolute -top-3 left-4 w-3 h-3 bg-yellow-400 rounded-full shadow-[0_0_10px_#eab308] animate-pulse"></div>
          <div className="absolute -top-3 right-4 w-3 h-3 bg-yellow-400 rounded-full shadow-[0_0_10px_#eab308] animate-pulse delay-500"></div>

          {/* Bottom accent bar */}
          <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-yellow-500 to-transparent"></div>
        </div>
      </div>
    </div>
  </div>
);

// Style Selector Component
interface StyleSelectorProps {
  currentStyle: string;
  onStyleChange: (style: string) => void;
}

export const TitleCardStyleSelector: React.FC<StyleSelectorProps> = ({ currentStyle, onStyleChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const styles = [
    { id: 'holographic', name: 'Holographic Projection', icon: '◈' },
    { id: 'circuit', name: 'Circuit Board Matrix', icon: '⊞' },
    { id: 'glitch', name: 'Glitch Distortion', icon: '▓' },
    { id: 'neon', name: 'Neon Cyberpunk', icon: '◆' },
    { id: 'military', name: 'Military HUD', icon: '▶' },
    { id: 'space', name: 'Space Station', icon: '◉' },
    { id: 'matrix', name: 'Matrix Data Stream', icon: '▚' },
    { id: 'industrial', name: 'Industrial Warning', icon: '⚠' },
  ];

  return (
    <div className="fixed left-4 top-28 z-[60]">
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-black/80 backdrop-blur-sm border border-yellow-500/50 px-4 py-2 flex items-center gap-2 hover:bg-yellow-500/10 transition-colors"
        >
          <span className="text-yellow-400 font-orbitron text-sm uppercase tracking-wider">
            Style
          </span>
          <span className="text-yellow-500">{isOpen ? '▲' : '▼'}</span>
        </button>

        {isOpen && (
          <div className="absolute top-full left-0 mt-1 bg-black/90 backdrop-blur-sm border border-yellow-500/50 min-w-[250px]">
            {styles.map((style) => (
              <button
                key={style.id}
                onClick={() => {
                  onStyleChange(style.id);
                  setIsOpen(false);
                }}
                className={`w-full px-4 py-2 flex items-center gap-3 hover:bg-yellow-500/10 transition-colors text-left ${
                  currentStyle === style.id ? 'bg-yellow-500/20 border-l-2 border-yellow-400' : ''
                }`}
              >
                <span className="text-yellow-500 text-lg">{style.icon}</span>
                <span className="text-gray-300 text-sm">{style.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Main wrapper component that manages style selection
export const StoryModeTitleCard: React.FC<TitleCardProps> = ({ chapter }) => {
  const [selectedStyle, setSelectedStyle] = useState<string>('space');

  useEffect(() => {
    const saved = localStorage.getItem('storyTitleStyle');
    if (saved) setSelectedStyle(saved);
  }, []);

  const handleStyleChange = (style: string) => {
    setSelectedStyle(style);
    localStorage.setItem('storyTitleStyle', style);
  };

  const renderTitleCard = () => {
    switch (selectedStyle) {
      case 'holographic': return <HolographicTitle chapter={chapter} />;
      case 'circuit': return <CircuitBoardTitle chapter={chapter} />;
      case 'glitch': return <GlitchTitle chapter={chapter} />;
      case 'neon': return <NeonCyberpunkTitle chapter={chapter} />;
      case 'military': return <MilitaryHUDTitle chapter={chapter} />;
      case 'space': return <SpaceStationTitle chapter={chapter} />;
      case 'matrix': return <MatrixDataTitle chapter={chapter} />;
      case 'industrial': return <IndustrialWarningTitle chapter={chapter} />;
      default: return <HolographicTitle chapter={chapter} />;
    }
  };

  return (
    <>
      {renderTitleCard()}
      <TitleCardStyleSelector currentStyle={selectedStyle} onStyleChange={handleStyleChange} />
    </>
  );
};