'use client';

import React from 'react';

interface TitleCardProps {
  chapter: string;
  colorScheme?: 'blue' | 'yellow-black' | 'industrial-gold' | 'dark-amber';
}

// Space Station Display - The locked-in title card style
export const SpaceStationTitle: React.FC<TitleCardProps> = ({ chapter, colorScheme = 'blue' }) => {
  // Define color schemes
  const getColorClasses = () => {
    switch (colorScheme) {
      case 'yellow-black':
        return {
          bg: 'from-gray-900 to-black',
          border: 'border-yellow-500/30',
          text: 'text-yellow-400',
          glow: 'text-yellow-300',
          dots: 'bg-yellow-400',
          accent: 'text-yellow-500'
        };
      case 'industrial-gold':
        return {
          bg: 'from-amber-950 to-black',
          border: 'border-amber-600/30',
          text: 'text-amber-400',
          glow: 'text-amber-300',
          dots: 'bg-amber-400',
          accent: 'text-amber-500'
        };
      case 'dark-amber':
        return {
          bg: 'from-orange-950 to-black',
          border: 'border-orange-700/30',
          text: 'text-orange-400',
          glow: 'text-orange-300',
          dots: 'bg-orange-400',
          accent: 'text-orange-500'
        };
      case 'blue':
      default:
        return {
          bg: 'from-slate-900 to-black',
          border: 'border-blue-500/30',
          text: 'text-blue-400',
          glow: 'text-blue-300',
          dots: 'bg-blue-400',
          accent: 'text-blue-500'
        };
    }
  };

  const colors = getColorClasses();

  return (
  <div className={`sticky top-0 z-50 h-24 bg-gradient-to-b ${colors.bg} border-b ${colors.border}`}>
    <div className="max-w-[1600px] mx-auto px-5">
      <div className="relative h-24">
      {/* Starfield background */}
      <div className="absolute inset-0 opacity-30">
        <div className="stars-bg absolute inset-0"></div>
      </div>

      {/* Texture overlay for gradient */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/10 to-transparent"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(
            90deg,
            transparent,
            transparent 2px,
            rgba(100, 181, 246, 0.05) 2px,
            rgba(100, 181, 246, 0.05) 4px
          ), repeating-linear-gradient(
            0deg,
            transparent,
            transparent 2px,
            rgba(100, 181, 246, 0.03) 2px,
            rgba(100, 181, 246, 0.03) 4px
          )`
        }}></div>
      </div>

      {/* Main display panel */}
      <div className="relative h-full flex items-center justify-center">
        <div className="relative">
          {/* Outer frame with rivets */}
          <div className="bg-gradient-to-b from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-slate-600/50 px-16 py-4 rounded-sm">
            {/* Rivet details */}
            <div className="absolute top-1 left-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute top-1 right-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute bottom-1 left-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>
            <div className="absolute bottom-1 right-2 w-2 h-2 bg-slate-600 rounded-full shadow-inner"></div>

            {/* Title content */}
            <h1 className="text-2xl font-orbitron font-bold uppercase tracking-[0.4em] flex items-center gap-6">
              <span className={`${colors.glow} drop-shadow-[0_0_10px_currentColor]`}>
                STORY MODE
              </span>
              <span className="flex items-center gap-2">
                <span className="w-1 h-4 bg-blue-400/60"></span>
                <span className="w-1 h-4 bg-blue-400/80"></span>
                <span className="w-1 h-4 bg-blue-400"></span>
              </span>
              <span className={`text-lg ${colors.text}/90 tracking-[0.3em]`}>
                {chapter}
              </span>
            </h1>
          </div>

          {/* Status lights */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-2">
            <div className={`w-2 h-2 ${colors.dots} rounded-full shadow-[0_0_5px_currentColor] animate-pulse`}></div>
            <div className={`w-2 h-2 ${colors.dots} rounded-full shadow-[0_0_5px_currentColor] animate-pulse delay-150`}></div>
            <div className={`w-2 h-2 ${colors.dots} rounded-full shadow-[0_0_5px_currentColor] animate-pulse delay-300`}></div>
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
  );
};

// Main wrapper component - now passes colorScheme through
export const StoryModeTitleCard: React.FC<TitleCardProps> = ({ chapter, colorScheme }) => {
  return <SpaceStationTitle chapter={chapter} colorScheme={colorScheme} />;
};