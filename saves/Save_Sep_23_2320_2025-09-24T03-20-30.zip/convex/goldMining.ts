import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { Doc } from "./_generated/dataModel";

// MEK NFT Policy ID
const MEK_POLICY_ID = "ffa56051fda3d106a96f09c3d209d4bf24a117406fb813fb8b4548e3";

// Initialize or update gold mining for a wallet
export const initializeGoldMining = mutation({
  args: {
    walletAddress: v.string(),
    walletType: v.optional(v.string()),
    ownedMeks: v.array(v.object({
      assetId: v.string(),
      policyId: v.string(),
      assetName: v.string(),
      imageUrl: v.optional(v.string()),
      goldPerHour: v.number(),
      rarityRank: v.optional(v.number()),
      headVariation: v.optional(v.string()),
      bodyVariation: v.optional(v.string()),
      itemVariation: v.optional(v.string()),
    })),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Check if user already exists
    const existing = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    const totalGoldPerHour = args.ownedMeks.reduce((sum, mek) => sum + mek.goldPerHour, 0);

    if (existing) {
      // Calculate offline earnings
      const hoursOffline = (now - existing.lastActiveTime) / (1000 * 60 * 60);
      const offlineEarnings = existing.totalGoldPerHour * hoursOffline;

      // Update existing record
      await ctx.db.patch(existing._id, {
        walletType: args.walletType,
        ownedMeks: args.ownedMeks,
        totalGoldPerHour,
        currentGold: existing.currentGold + offlineEarnings,
        lastCheckTime: now,
        lastActiveTime: now,
        sessionStartTime: now,
        offlineEarnings,
        updatedAt: now,
      });

      return {
        currentGold: existing.currentGold + offlineEarnings,
        offlineEarnings,
        totalGoldPerHour
      };
    } else {
      // Create new record
      const newRecord = await ctx.db.insert("goldMining", {
        walletAddress: args.walletAddress,
        walletType: args.walletType,
        ownedMeks: args.ownedMeks,
        totalGoldPerHour,
        currentGold: 0,
        lastCheckTime: now,
        lastActiveTime: now,
        sessionStartTime: now,
        offlineEarnings: 0,
        createdAt: now,
        updatedAt: now,
      });

      return {
        currentGold: 0,
        offlineEarnings: 0,
        totalGoldPerHour
      };
    }
  },
});

// Get gold mining data for a wallet
export const getGoldMiningData = query({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const data = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!data) {
      return null;
    }

    // Calculate current gold including time since last check
    const hoursSinceLastCheck = (now - data.lastCheckTime) / (1000 * 60 * 60);
    const accumulatedGold = data.totalGoldPerHour * hoursSinceLastCheck;
    const currentGold = data.currentGold + accumulatedGold;

    return {
      ...data,
      currentGold,
      accumulatedSinceLastCheck: accumulatedGold,
    };
  },
});

// Update gold checkpoint (called periodically to save progress)
export const updateGoldCheckpoint = mutation({
  args: {
    walletAddress: v.string(),
    currentGold: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const existing = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!existing) {
      throw new Error("Gold mining data not found for wallet");
    }

    await ctx.db.patch(existing._id, {
      currentGold: args.currentGold,
      lastCheckTime: now,
      lastActiveTime: now,
      updatedAt: now,
    });

    return { success: true };
  },
});

// Update last active time (called when user leaves page)
export const updateLastActive = mutation({
  args: {
    walletAddress: v.string(),
    currentGold: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    const existing = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!existing) {
      throw new Error("Gold mining data not found for wallet");
    }

    await ctx.db.patch(existing._id, {
      currentGold: args.currentGold,
      lastActiveTime: now,
      updatedAt: now,
    });

    return { success: true };
  },
});

// Get gold rates for Meks based on rarity ranking
export const calculateGoldRates = query({
  args: {
    meks: v.array(v.object({
      assetId: v.string(),
      rarityRank: v.optional(v.number()),
    })),
  },
  handler: async (ctx, args) => {
    // Get the current gold rate configuration
    const goldRateConfig = await ctx.db
      .query("mekGoldRateSaves")
      .withIndex("by_current", (q) => q.eq("isCurrentConfig", true))
      .first();

    if (!goldRateConfig) {
      // Use default linear rates if no config exists
      return args.meks.map(mek => {
        const rank = mek.rarityRank || 2000; // Default to mid-rank if unknown
        // Linear scale from 100 gold/hr (rank 1) to 10 gold/hr (rank 4000)
        const goldPerHour = Math.max(10, 100 - (rank - 1) * 0.0225);
        return {
          assetId: mek.assetId,
          goldPerHour: Math.round(goldPerHour * 100) / 100, // Round to 2 decimals
        };
      });
    }

    // Calculate rates based on the configured curve
    const { curveType, minGold, maxGold, steepness, midPoint, totalMeks } = goldRateConfig;

    return args.meks.map(mek => {
      const rank = mek.rarityRank || totalMeks / 2; // Default to mid-rank if unknown
      const normalizedRank = (rank - 1) / (totalMeks - 1); // Normalize to 0-1

      let goldPerHour: number;

      switch (curveType) {
        case 'exponential':
          goldPerHour = maxGold * Math.exp(-steepness * normalizedRank);
          break;

        case 'logarithmic':
          goldPerHour = maxGold - (maxGold - minGold) * Math.log(1 + steepness * normalizedRank) / Math.log(1 + steepness);
          break;

        case 'sigmoid':
          const sigmoidX = (rank - midPoint) / (totalMeks / 10); // Scale factor for sigmoid
          const sigmoidValue = 1 / (1 + Math.exp(steepness * sigmoidX));
          goldPerHour = minGold + (maxGold - minGold) * sigmoidValue;
          break;

        case 'linear':
        default:
          goldPerHour = maxGold - (maxGold - minGold) * normalizedRank;
          break;
      }

      // Apply rounding based on config
      switch (goldRateConfig.rounding) {
        case 'whole':
          goldPerHour = Math.round(goldPerHour);
          break;
        case '1decimal':
          goldPerHour = Math.round(goldPerHour * 10) / 10;
          break;
        case '2decimal':
          goldPerHour = Math.round(goldPerHour * 100) / 100;
          break;
      }

      return {
        assetId: mek.assetId,
        goldPerHour: Math.max(minGold, Math.min(maxGold, goldPerHour)), // Ensure within bounds
      };
    });
  },
});

// Get all gold mining users (for leaderboard)
export const getTopMiners = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const limit = args.limit || 10;

    const miners = await ctx.db
      .query("goldMining")
      .withIndex("by_total_rate")
      .order("desc")
      .take(limit);

    return miners.map(miner => ({
      walletAddress: miner.walletAddress,
      totalGoldPerHour: miner.totalGoldPerHour,
      currentGold: miner.currentGold,
      mekCount: miner.ownedMeks.length,
    }));
  },
});

// Get all gold mining data for admin dashboard
export const getAllGoldMiningData = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const allMiners = await ctx.db.query("goldMining").collect();

    return allMiners.map(miner => {
      // Calculate current gold including time since last check
      const hoursSinceLastCheck = (now - miner.lastCheckTime) / (1000 * 60 * 60);
      const accumulatedGold = miner.totalGoldPerHour * hoursSinceLastCheck;
      const currentGold = miner.currentGold + accumulatedGold;

      // Calculate time since last active
      const minutesSinceActive = Math.floor((now - miner.lastActiveTime) / (1000 * 60));
      const hoursSinceActive = Math.floor(minutesSinceActive / 60);
      const daysSinceActive = Math.floor(hoursSinceActive / 24);

      let lastActiveDisplay = "Just now";
      if (daysSinceActive > 0) {
        lastActiveDisplay = `${daysSinceActive}d ago`;
      } else if (hoursSinceActive > 0) {
        lastActiveDisplay = `${hoursSinceActive}h ago`;
      } else if (minutesSinceActive > 0) {
        lastActiveDisplay = `${minutesSinceActive}m ago`;
      }

      // Get highest gold rate Mek
      const highestRateMek = miner.ownedMeks.reduce((best, mek) =>
        mek.goldPerHour > (best?.goldPerHour || 0) ? mek : best,
        miner.ownedMeks[0]
      );

      return {
        _id: miner._id,
        walletAddress: miner.walletAddress,
        walletType: miner.walletType || "Unknown",
        mekCount: miner.ownedMeks.length,
        totalGoldPerHour: miner.totalGoldPerHour,
        currentGold: Math.floor(currentGold * 100) / 100, // Round to 2 decimals
        lastActiveTime: miner.lastActiveTime,
        lastActiveDisplay,
        createdAt: miner.createdAt,
        sessionStartTime: miner.sessionStartTime,
        offlineEarnings: miner.offlineEarnings || 0,
        highestRateMek: highestRateMek ? {
          name: highestRateMek.assetName,
          rate: highestRateMek.goldPerHour,
          rank: highestRateMek.rarityRank
        } : null,
        ownedMeks: miner.ownedMeks,
      };
    });
  },
});

// Get gold mining statistics
export const getGoldMiningStats = query({
  args: {},
  handler: async (ctx) => {
    const allMiners = await ctx.db.query("goldMining").collect();

    if (allMiners.length === 0) {
      return {
        totalUsers: 0,
        totalMeks: 0,
        totalGoldPerHour: 0,
        totalGoldAccumulated: 0,
        averageMeksPerUser: 0,
        averageGoldPerHour: 0,
        topWalletType: "None",
        activeUsersLast24h: 0,
      };
    }

    const now = Date.now();
    const last24h = now - (24 * 60 * 60 * 1000);

    // Calculate totals
    const totalMeks = allMiners.reduce((sum, miner) => sum + miner.ownedMeks.length, 0);
    const totalGoldPerHour = allMiners.reduce((sum, miner) => sum + miner.totalGoldPerHour, 0);

    // Calculate accumulated gold
    const totalGoldAccumulated = allMiners.reduce((sum, miner) => {
      const hoursSinceLastCheck = (now - miner.lastCheckTime) / (1000 * 60 * 60);
      const accumulatedGold = miner.totalGoldPerHour * hoursSinceLastCheck;
      return sum + miner.currentGold + accumulatedGold;
    }, 0);

    // Count wallet types
    const walletTypes: Record<string, number> = {};
    allMiners.forEach(miner => {
      const type = miner.walletType || "unknown";
      walletTypes[type] = (walletTypes[type] || 0) + 1;
    });

    // Find most popular wallet type
    const topWalletType = Object.entries(walletTypes)
      .sort(([,a], [,b]) => b - a)[0]?.[0] || "None";

    // Count active users in last 24h
    const activeUsersLast24h = allMiners.filter(
      miner => miner.lastActiveTime > last24h
    ).length;

    return {
      totalUsers: allMiners.length,
      totalMeks,
      totalGoldPerHour: Math.floor(totalGoldPerHour * 100) / 100,
      totalGoldAccumulated: Math.floor(totalGoldAccumulated * 100) / 100,
      averageMeksPerUser: Math.floor((totalMeks / allMiners.length) * 10) / 10,
      averageGoldPerHour: Math.floor((totalGoldPerHour / allMiners.length) * 100) / 100,
      topWalletType,
      activeUsersLast24h,
      walletTypeBreakdown: walletTypes,
    };
  },
});

// Reset all gold mining data (admin function)
export const resetAllGoldMiningData = mutation({
  args: {},
  handler: async (ctx) => {
    // Get all gold mining records
    const allRecords = await ctx.db.query("goldMining").collect();

    // Delete each record
    for (const record of allRecords) {
      await ctx.db.delete(record._id);
    }

    return {
      success: true,
      deletedCount: allRecords.length
    };
  },
});