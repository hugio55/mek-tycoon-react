'use client'

import React, { useState, useMemo } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";

type SortField = 'walletAddress' | 'walletType' | 'mekCount' | 'totalGoldPerHour' | 'currentGold' | 'lastActiveDisplay' | 'createdAt';
type SortDirection = 'asc' | 'desc';
type ViewMode = 'table' | 'cards';

interface MinerData {
  _id: string;
  walletAddress: string;
  walletType: string;
  mekCount: number;
  totalGoldPerHour: number;
  currentGold: number;
  lastActiveTime: number;
  lastActiveDisplay: string;
  createdAt: number;
  offlineEarnings: number;
  highestRateMek: {
    name: string;
    rate: number;
    rank?: number;
  } | null;
}

export default function MekRateExperiment() {
  const [sortField, setSortField] = useState<SortField>('currentGold');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('table');

  // Fetch data from Convex
  const goldMiningData = useQuery(api.goldMining.getAllGoldMiningData) as MinerData[] | undefined;
  const stats = useQuery(api.goldMining.getGoldMiningStats);
  const resetAllData = useMutation(api.goldMining.resetAllGoldMiningData);

  // Handle sorting
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Handle reset
  const handleReset = async () => {
    setShowResetConfirm(false);
    await resetAllData();
  };

  // Sort data
  const sortedData = useMemo(() => {
    if (!goldMiningData) return [];

    return [...goldMiningData].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];

      if (sortField === 'lastActiveDisplay') {
        // Convert to minutes for sorting
        const parseTime = (str: string): number => {
          if (str === 'Just now') return 0;
          const match = str.match(/(\d+)([mhd])/);
          if (!match) return 0;
          const [, num, unit] = match;
          const multiplier = unit === 'm' ? 1 : unit === 'h' ? 60 : 1440;
          return parseInt(num) * multiplier;
        };
        aVal = parseTime(a.lastActiveDisplay);
        bVal = parseTime(b.lastActiveDisplay);
      }

      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [goldMiningData, sortField, sortDirection]);

  // Format date
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Truncate wallet address
  const truncateWallet = (address: string) => {
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  // Get rarity color based on gold rate
  const getRarityColor = (goldPerHour: number) => {
    if (goldPerHour >= 1000) return 'from-purple-500 to-pink-500';
    if (goldPerHour >= 500) return 'from-yellow-500 to-orange-500';
    if (goldPerHour >= 250) return 'from-blue-500 to-cyan-500';
    if (goldPerHour >= 100) return 'from-green-500 to-emerald-500';
    return 'from-gray-500 to-gray-600';
  };

  // Get activity status color
  const getActivityColor = (lastActive: string) => {
    if (lastActive === 'Just now') return 'bg-green-500';
    if (lastActive.includes('m')) return 'bg-yellow-500';
    if (lastActive.includes('h')) return 'bg-orange-500';
    return 'bg-red-500';
  };

  return (
    <div className="min-h-screen relative">
      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-950 to-black" />
        <div className="absolute inset-0" style={{
          backgroundImage: `
            repeating-linear-gradient(
              0deg,
              transparent,
              transparent 2px,
              rgba(250, 182, 23, 0.03) 2px,
              rgba(250, 182, 23, 0.03) 4px
            )
          `
        }} />
      </div>

      <div className="relative z-10 space-y-6 p-6">
        {/* Header Section */}
        <div className="bg-black/20 backdrop-blur-xl border-2 border-yellow-500/30 rounded-lg p-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold text-yellow-500 uppercase tracking-wider font-['Orbitron']">
                Gold Mining Dashboard
              </h1>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-green-400 text-sm uppercase tracking-wider">System Active</span>
                </div>
                <span className="text-gray-500">|</span>
                <span className="text-gray-400 text-sm">Real-time Gold Accumulation Analytics</span>
              </div>
            </div>

            <div className="text-right">
              <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Total Accumulated</div>
              <div className="text-3xl font-bold text-yellow-500 font-mono">
                {stats?.totalGoldAccumulated.toLocaleString() || '0'}
              </div>
              <div className="text-yellow-500/50 text-sm mt-1">Gold Units</div>
            </div>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-4 mt-6">
            <div className="flex gap-2 bg-black/40 p-1 rounded-lg border border-yellow-500/20">
              <button
                onClick={() => setViewMode('table')}
                className={`px-4 py-2 rounded transition-all ${
                  viewMode === 'table'
                    ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/50'
                    : 'text-gray-400 hover:text-yellow-500'
                }`}
              >
                <span className="uppercase text-xs tracking-wider font-bold">Table View</span>
              </button>
              <button
                onClick={() => setViewMode('cards')}
                className={`px-4 py-2 rounded transition-all ${
                  viewMode === 'cards'
                    ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/50'
                    : 'text-gray-400 hover:text-yellow-500'
                }`}
              >
                <span className="uppercase text-xs tracking-wider font-bold">Card View</span>
              </button>
            </div>

            <div className="flex-1" />

            {/* Reset Button */}
            <button
              onClick={() => setShowResetConfirm(true)}
              className="relative px-6 py-3 bg-red-900/20 border-2 border-red-500/50 text-red-400
                       hover:bg-red-900/30 transition-all uppercase tracking-wider text-sm font-bold
                       backdrop-blur-sm overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-red-600/0 via-red-600/20 to-red-600/0
                            translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
              <span className="relative z-10">⚠ Reset All Data</span>
            </button>
          </div>
        </div>

        {/* Statistics Cards Grid */}
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Users Card */}
            <div className="relative bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-yellow-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-yellow-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-yellow-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-yellow-500/50" />
              </div>

              <div className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-3">Total Users</div>
              <div className="text-4xl font-bold text-yellow-500 font-mono mb-2">
                {stats.totalUsers}
              </div>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-yellow-500/30 to-transparent" />

              <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
                <div className="w-full h-full" style={{
                  background: 'repeating-linear-gradient(45deg, transparent, transparent 3px, #FAB617 3px, #FAB617 6px)'
                }} />
              </div>
            </div>

            {/* Total Meks Card */}
            <div className="relative bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-yellow-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-yellow-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-yellow-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-yellow-500/50" />
              </div>

              <div className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-3">Total Meks</div>
              <div className="text-4xl font-bold text-yellow-500 font-mono mb-1">
                {stats.totalMeks}
              </div>
              <div className="text-xs text-yellow-500/60">
                AVG: {stats.averageMeksPerUser} per user
              </div>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-yellow-500/30 to-transparent mt-2" />

              <div className="absolute top-0 right-0 w-20 h-20 opacity-10">
                <div className="w-full h-full" style={{
                  background: 'repeating-linear-gradient(-45deg, transparent, transparent 3px, #FAB617 3px, #FAB617 6px)'
                }} />
              </div>
            </div>

            {/* Gold Per Hour Card */}
            <div className="relative bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-yellow-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-yellow-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-yellow-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-yellow-500/50" />
              </div>

              <div className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-3">Gold/Hour</div>
              <div className="text-3xl font-bold text-yellow-500 font-mono mb-1">
                {stats.totalGoldPerHour.toLocaleString()}
              </div>
              <div className="text-xs text-yellow-500/60">
                AVG: {stats.averageGoldPerHour}/user
              </div>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-yellow-500/30 to-transparent mt-2" />

              <div className="absolute inset-0 bg-gradient-to-t from-yellow-500/5 to-transparent pointer-events-none" />
            </div>

            {/* Active Users Card */}
            <div className="relative bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6 overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-yellow-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-yellow-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-yellow-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-yellow-500/50" />
              </div>

              <div className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-3">Active 24H</div>
              <div className="text-4xl font-bold text-green-500 font-mono mb-2">
                {stats.activeUsersLast24h}
              </div>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-green-500/30 to-transparent" />

              <div className="absolute inset-0 bg-gradient-to-t from-green-500/5 to-transparent pointer-events-none" />
            </div>
          </div>
        )}

        {/* Wallet Type Breakdown */}
        {stats?.walletTypeBreakdown && Object.keys(stats.walletTypeBreakdown).length > 0 && (
          <div className="bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6">
            <div className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-4">Wallet Distribution</div>
            <div className="flex gap-6 flex-wrap">
              {Object.entries(stats.walletTypeBreakdown).map(([type, count]) => (
                <div key={type} className="flex items-center gap-3 bg-black/30 px-4 py-2 rounded-lg border border-yellow-500/10">
                  <div className="w-2 h-8 bg-gradient-to-b from-yellow-500 to-orange-500 rounded-full" />
                  <div>
                    <span className="text-yellow-500 font-bold text-lg capitalize">{type}</span>
                    <span className="text-gray-400 ml-2">{count} users</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* View Mode Content */}
        {viewMode === 'table' ? (
          /* Table View */
          <div className="bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-black/40 border-b border-yellow-500/20">
                    <th
                      onClick={() => handleSort('walletAddress')}
                      className="px-6 py-4 text-left text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em] cursor-pointer hover:bg-yellow-500/5 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        Wallet
                        {sortField === 'walletAddress' && (
                          <span className="text-yellow-400">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort('mekCount')}
                      className="px-6 py-4 text-center text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em] cursor-pointer hover:bg-yellow-500/5 transition-all"
                    >
                      <div className="flex items-center justify-center gap-2">
                        Meks
                        {sortField === 'mekCount' && (
                          <span className="text-yellow-400">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort('totalGoldPerHour')}
                      className="px-6 py-4 text-right text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em] cursor-pointer hover:bg-yellow-500/5 transition-all"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Gold/Hr
                        {sortField === 'totalGoldPerHour' && (
                          <span className="text-yellow-400">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort('currentGold')}
                      className="px-6 py-4 text-right text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em] cursor-pointer hover:bg-yellow-500/5 transition-all"
                    >
                      <div className="flex items-center justify-end gap-2">
                        Total
                        {sortField === 'currentGold' && (
                          <span className="text-yellow-400">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>

                    <th
                      onClick={() => handleSort('lastActiveDisplay')}
                      className="px-6 py-4 text-center text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em] cursor-pointer hover:bg-yellow-500/5 transition-all"
                    >
                      <div className="flex items-center justify-center gap-2">
                        Status
                        {sortField === 'lastActiveDisplay' && (
                          <span className="text-yellow-400">{sortDirection === 'asc' ? '▲' : '▼'}</span>
                        )}
                      </div>
                    </th>

                    <th className="px-6 py-4 text-center text-xs font-bold text-yellow-500/80 uppercase tracking-[0.2em]">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-yellow-500/10">
                  {sortedData.map((miner) => (
                    <React.Fragment key={miner._id}>
                      <tr
                        className="hover:bg-yellow-500/5 transition-all bg-black/10"
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-500/20 to-orange-500/20
                                          border border-yellow-500/30 flex items-center justify-center">
                              <span className="text-yellow-500 text-xs font-bold">
                                {miner.walletType[0].toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <div className="text-gray-300 font-mono text-sm">
                                {truncateWallet(miner.walletAddress)}
                              </div>
                              <div className="text-gray-500 text-xs capitalize">{miner.walletType}</div>
                            </div>
                          </div>
                        </td>

                        <td className="px-6 py-4 text-center">
                          <span className="text-white font-bold text-lg">{miner.mekCount}</span>
                        </td>

                        <td className="px-6 py-4 text-right">
                          <span className="text-yellow-400 font-bold text-lg font-mono">
                            {miner.totalGoldPerHour.toFixed(1)}
                          </span>
                        </td>

                        <td className="px-6 py-4 text-right">
                          <div>
                            <span className="text-green-400 font-bold text-lg font-mono">
                              {miner.currentGold.toLocaleString()}
                            </span>
                            {miner.offlineEarnings > 0 && (
                              <div className="text-xs text-gray-500">
                                +{miner.offlineEarnings.toFixed(0)} offline
                              </div>
                            )}
                          </div>
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex items-center justify-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${getActivityColor(miner.lastActiveDisplay)}`} />
                            <span className={`text-sm ${
                              miner.lastActiveDisplay === 'Just now'
                                ? 'text-green-400'
                                : miner.lastActiveDisplay.includes('m')
                                ? 'text-yellow-400'
                                : miner.lastActiveDisplay.includes('h')
                                ? 'text-orange-400'
                                : 'text-red-400'
                            }`}>
                              {miner.lastActiveDisplay}
                            </span>
                          </div>
                        </td>

                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => setExpandedRow(expandedRow === miner._id ? null : miner._id)}
                            className="px-3 py-1 bg-yellow-500/10 border border-yellow-500/30 rounded
                                     text-yellow-500 hover:bg-yellow-500/20 transition-all text-xs uppercase tracking-wider"
                          >
                            {expandedRow === miner._id ? 'Hide' : 'Details'}
                          </button>
                        </td>
                      </tr>

                      {/* Expanded Details */}
                      {expandedRow === miner._id && (
                        <tr className="bg-black/30">
                          <td colSpan={6} className="px-6 py-6">
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                              {miner.highestRateMek && (
                                <div className="bg-black/40 border border-yellow-500/20 rounded-lg p-4">
                                  <div className="text-gray-500 text-xs uppercase tracking-wider mb-2">Best Mek</div>
                                  <div className="text-yellow-500 font-bold text-lg">{miner.highestRateMek.name}</div>
                                  <div className="text-gray-400 text-sm">
                                    {miner.highestRateMek.rate.toFixed(2)} gold/hr
                                    {miner.highestRateMek.rank && (
                                      <span className="ml-2 text-gray-500">Rank #{miner.highestRateMek.rank}</span>
                                    )}
                                  </div>
                                </div>
                              )}

                              <div className="bg-black/40 border border-yellow-500/20 rounded-lg p-4">
                                <div className="text-gray-500 text-xs uppercase tracking-wider mb-2">Full Address</div>
                                <div className="text-gray-300 font-mono text-xs break-all">{miner.walletAddress}</div>
                              </div>

                              <div className="bg-black/40 border border-yellow-500/20 rounded-lg p-4">
                                <div className="text-gray-500 text-xs uppercase tracking-wider mb-2">Timestamps</div>
                                <div className="text-gray-400 text-sm space-y-1">
                                  <div>Last: {formatDate(miner.lastActiveTime)}</div>
                                  <div>Joined: {formatDate(miner.createdAt)}</div>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>

              {(!goldMiningData || goldMiningData.length === 0) && (
                <div className="text-center py-12 text-gray-500">
                  <div className="text-2xl mb-2">No Mining Data Available</div>
                  <div className="text-sm">Waiting for miners to connect...</div>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Card View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {sortedData.map((miner) => (
              <div
                key={miner._id}
                className="relative bg-black/20 backdrop-blur-xl border border-yellow-500/20 rounded-lg p-6
                         hover:border-yellow-500/40 transition-all overflow-hidden group"
              >
                {/* Corner Brackets */}
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-yellow-500/50" />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-yellow-500/50" />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-yellow-500/50" />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-yellow-500/50" />

                {/* Status Indicator */}
                <div className="absolute top-4 right-4">
                  <div className={`w-3 h-3 rounded-full ${getActivityColor(miner.lastActiveDisplay)}`} />
                </div>

                {/* Wallet Info */}
                <div className="mb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-yellow-500/20 to-orange-500/20
                                  border border-yellow-500/30 flex items-center justify-center">
                      <span className="text-yellow-500 font-bold">
                        {miner.walletType[0].toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <div className="text-gray-300 font-mono text-sm">
                        {truncateWallet(miner.walletAddress)}
                      </div>
                      <div className="text-gray-500 text-xs capitalize">{miner.walletType}</div>
                    </div>
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="space-y-3 mb-4">
                  <div>
                    <div className="text-gray-500 text-xs uppercase tracking-wider">Meks Owned</div>
                    <div className="text-2xl font-bold text-white">{miner.mekCount}</div>
                  </div>

                  <div>
                    <div className="text-gray-500 text-xs uppercase tracking-wider">Gold Rate</div>
                    <div className="text-2xl font-bold text-yellow-400 font-mono">
                      {miner.totalGoldPerHour.toFixed(1)}/hr
                    </div>
                  </div>

                  <div>
                    <div className="text-gray-500 text-xs uppercase tracking-wider">Total Gold</div>
                    <div className="text-2xl font-bold text-green-400 font-mono">
                      {miner.currentGold.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Gradient Bar Based on Gold Rate */}
                <div className="h-1 w-full bg-black/40 rounded-full overflow-hidden mb-4">
                  <div
                    className={`h-full bg-gradient-to-r ${getRarityColor(miner.totalGoldPerHour)}`}
                    style={{ width: `${Math.min(100, (miner.totalGoldPerHour / 1000) * 100)}%` }}
                  />
                </div>

                {/* Details Button */}
                <button
                  onClick={() => setExpandedRow(expandedRow === miner._id ? null : miner._id)}
                  className="w-full py-2 bg-yellow-500/10 border border-yellow-500/30 rounded
                           text-yellow-500 hover:bg-yellow-500/20 transition-all text-xs uppercase tracking-wider
                           font-bold group-hover:border-yellow-500/50"
                >
                  View Details
                </button>

                {/* Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-t from-yellow-500/10 to-transparent
                              opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              </div>
            ))}
          </div>
        )}

        {/* Reset Confirmation Modal */}
        {showResetConfirm && (
          <div className="fixed inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center z-50">
            <div className="bg-black/95 border-2 border-red-500 rounded-lg p-8 max-w-md relative overflow-hidden">
              {/* Hazard Stripes Background */}
              <div className="absolute inset-0 opacity-10">
                <div className="w-full h-full" style={{
                  background: 'repeating-linear-gradient(45deg, transparent, transparent 10px, #EF4444 10px, #EF4444 20px)'
                }} />
              </div>

              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="text-4xl">⚠</div>
                  <h3 className="text-2xl font-bold text-red-500 uppercase tracking-wider">System Reset</h3>
                </div>

                <div className="bg-red-950/50 border border-red-500/30 rounded p-4 mb-6 font-mono text-sm">
                  <div className="text-red-400 mb-2">WARNING: PERMANENT DATA DELETION</div>
                  <div className="text-gray-400 space-y-1">
                    <div>• All wallet connections will be erased</div>
                    <div>• All gold accumulation will be reset to 0</div>
                    <div>• All Mek ownership records will be deleted</div>
                    <div>• All mining history will be purged</div>
                  </div>
                </div>

                <div className="text-red-300 font-bold text-center mb-6 uppercase tracking-wider">
                  This action cannot be undone!
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={handleReset}
                    className="flex-1 px-4 py-3 bg-red-600/20 border-2 border-red-600 text-red-500
                             hover:bg-red-600/30 font-bold rounded transition-all uppercase tracking-wider"
                  >
                    Confirm Reset
                  </button>
                  <button
                    onClick={() => setShowResetConfirm(false)}
                    className="flex-1 px-4 py-3 bg-gray-800/50 border-2 border-gray-600 text-gray-300
                             hover:bg-gray-700/50 font-bold rounded transition-all uppercase tracking-wider"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}