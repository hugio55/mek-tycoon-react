import { mutation, query, action } from "./_generated/server";
import { v } from "convex/values";
import { api } from "./_generated/api";

// Link a secondary wallet to a primary wallet
export const linkWallet = action({
  args: {
    primaryWallet: v.string(),
    linkedWallet: v.string(),
    signature: v.string(),
    nonce: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      // Verify both wallets have signed the linking request
      const primaryAuth = await ctx.runQuery(api.walletAuthentication.checkAuthentication, {
        stakeAddress: args.primaryWallet,
      });

      if (!primaryAuth.authenticated) {
        return {
          success: false,
          error: "Primary wallet not authenticated",
        };
      }

      // Check if link already exists
      const existingLink = await ctx.runQuery(api.multiWalletAggregation.checkWalletLink, {
        primaryWallet: args.primaryWallet,
        linkedWallet: args.linkedWallet,
      });

      if (existingLink && existingLink.active) {
        return {
          success: false,
          error: "Wallets are already linked",
        };
      }

      // Create the wallet link
      await ctx.runMutation(api.multiWalletAggregation.createWalletLink, {
        primaryWallet: args.primaryWallet,
        linkedWallet: args.linkedWallet,
        signatureVerified: true, // In production, verify the signature
      });

      // Log the linking event
      await ctx.runMutation(api.auditLogs.logWalletLink, {
        primaryWallet: args.primaryWallet,
        linkedWallet: args.linkedWallet,
        signatureVerified: true,
        timestamp: Date.now(),
      });

      return {
        success: true,
        message: "Wallets linked successfully",
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to link wallets",
      };
    }
  },
});

// Create wallet link mutation
export const createWalletLink = mutation({
  args: {
    primaryWallet: v.string(),
    linkedWallet: v.string(),
    signatureVerified: v.boolean(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("walletLinks", {
      primaryWallet: args.primaryWallet,
      linkedWallet: args.linkedWallet,
      signatureVerified: args.signatureVerified,
      linkDate: Date.now(),
      active: true,
    });
  },
});

// Check if wallets are linked
export const checkWalletLink = query({
  args: {
    primaryWallet: v.string(),
    linkedWallet: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("walletLinks")
      .filter(q =>
        q.and(
          q.eq(q.field("primaryWallet"), args.primaryWallet),
          q.eq(q.field("linkedWallet"), args.linkedWallet)
        )
      )
      .first();
  },
});

// Get all linked wallets for an address
export const getLinkedWallets = query({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, args) => {
    // Check if this is a primary wallet
    const asPrimary = await ctx.db
      .query("walletLinks")
      .withIndex("by_primary_active", q =>
        q.eq("primaryWallet", args.walletAddress).eq("active", true)
      )
      .collect();

    // Check if this is a linked wallet
    const asLinked = await ctx.db
      .query("walletLinks")
      .filter(q =>
        q.and(
          q.eq(q.field("linkedWallet"), args.walletAddress),
          q.eq(q.field("active"), true)
        )
      )
      .collect();

    // Determine the primary wallet
    let primaryWallet = args.walletAddress;
    let linkedWallets: string[] = [];

    if (asLinked.length > 0) {
      // This wallet is linked to another primary
      primaryWallet = asLinked[0].primaryWallet;

      // Get all wallets linked to this primary
      const allLinks = await ctx.db
        .query("walletLinks")
        .withIndex("by_primary_active", q =>
          q.eq("primaryWallet", primaryWallet).eq("active", true)
        )
        .collect();

      linkedWallets = allLinks.map(link => link.linkedWallet);
    } else {
      // This is a primary wallet
      linkedWallets = asPrimary.map(link => link.linkedWallet);
    }

    return {
      primaryWallet,
      linkedWallets,
      totalWallets: linkedWallets.length + 1,
    };
  },
});

// Get aggregated MEKs from all linked wallets
export const getAggregatedMeks = action({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, args) => {
    try {
      // Get all linked wallets
      const walletInfo = await ctx.runQuery(api.multiWalletAggregation.getLinkedWallets, {
        walletAddress: args.walletAddress,
      });

      const allWallets = [walletInfo.primaryWallet, ...walletInfo.linkedWallets];
      const aggregatedMeks: any[] = [];
      const verificationResults: any[] = [];

      // Fetch MEKs from each wallet
      for (const wallet of allWallets) {
        try {
          // Get MEKs using Blockfrost
          const result = await ctx.runAction(api.blockfrostService.getWalletAssets, {
            stakeAddress: wallet,
          });

          if (result.success && result.meks) {
            aggregatedMeks.push(...result.meks.map((mek: any) => ({
              ...mek,
              walletAddress: wallet,
              isPrimary: wallet === walletInfo.primaryWallet,
            })));

            verificationResults.push({
              wallet,
              verified: true,
              mekCount: result.meks.length,
            });
          }
        } catch (error) {
          console.error(`Error fetching MEKs for wallet ${wallet}:`, error);
          verificationResults.push({
            wallet,
            verified: false,
            error: "Failed to fetch",
          });
        }
      }

      // Calculate aggregated rates
      const totalGoldRate = aggregatedMeks.reduce((sum, mek) => {
        // Use smart contract calculation (simulated)
        return sum + (mek.goldRate || 10);
      }, 0);

      return {
        success: true,
        primaryWallet: walletInfo.primaryWallet,
        linkedWallets: walletInfo.linkedWallets,
        aggregatedMeks,
        totalMeks: aggregatedMeks.length,
        totalGoldRate,
        verificationResults,
        timestamp: Date.now(),
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to aggregate MEKs",
        aggregatedMeks: [],
        totalMeks: 0,
        totalGoldRate: 0,
      };
    }
  },
});

// Unlink wallets
export const unlinkWallet = mutation({
  args: {
    primaryWallet: v.string(),
    linkedWallet: v.string(),
  },
  handler: async (ctx, args) => {
    const link = await ctx.db
      .query("walletLinks")
      .filter(q =>
        q.and(
          q.eq(q.field("primaryWallet"), args.primaryWallet),
          q.eq(q.field("linkedWallet"), args.linkedWallet),
          q.eq(q.field("active"), true)
        )
      )
      .first();

    if (link) {
      await ctx.db.patch(link._id, {
        active: false,
      });

      // Log the unlinking
      await ctx.db.insert("auditLogs", {
        type: "walletUnlink",
        primaryWallet: args.primaryWallet,
        linkedWallet: args.linkedWallet,
        timestamp: Date.now(),
        createdAt: Date.now(),
      });

      return { success: true };
    }

    return { success: false, error: "Link not found" };
  },
});

// Get wallet aggregation statistics
export const getAggregationStats = query({
  args: {},
  handler: async (ctx) => {
    const allLinks = await ctx.db
      .query("walletLinks")
      .filter(q => q.eq(q.field("active"), true))
      .collect();

    // Count unique primary wallets
    const primaryWallets = new Set(allLinks.map(link => link.primaryWallet));

    // Calculate average links per primary
    const linksPerPrimary: Record<string, number> = {};
    allLinks.forEach(link => {
      linksPerPrimary[link.primaryWallet] = (linksPerPrimary[link.primaryWallet] || 0) + 1;
    });

    const avgLinks = primaryWallets.size > 0
      ? allLinks.length / primaryWallets.size
      : 0;

    const maxLinks = Math.max(0, ...Object.values(linksPerPrimary));

    return {
      totalPrimaryWallets: primaryWallets.size,
      totalLinkedWallets: allLinks.length,
      averageLinksPerPrimary: avgLinks,
      maxLinksOnSinglePrimary: maxLinks,
      totalActiveLinks: allLinks.length,
    };
  },
});