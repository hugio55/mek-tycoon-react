import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { Doc, Id } from "./_generated/dataModel";

// Gold cost structure for each level upgrade
const UPGRADE_COSTS = [
  0,      // Level 0 (doesn't exist)
  0,      // Level 1 (starting level, no cost)
  100,    // Level 1→2
  250,    // Level 2→3
  500,    // Level 3→4
  1000,   // Level 4→5
  2000,   // Level 5→6
  4000,   // Level 6→7
  8000,   // Level 7→8
  16000,  // Level 8→9
  32000,  // Level 9→10
];

// Calculate the gold cost for upgrading from current level to next level
export function calculateUpgradeCost(currentLevel: number): number {
  if (currentLevel < 1 || currentLevel >= 10) {
    return 0; // Can't upgrade past level 10 or from invalid levels
  }
  return UPGRADE_COSTS[currentLevel + 1];
}

// Calculate total gold spent to reach a given level
export function calculateTotalGoldSpent(level: number): number {
  let total = 0;
  for (let i = 2; i <= level; i++) {
    total += UPGRADE_COSTS[i];
  }
  return total;
}

// Get Mek levels for a wallet
export const getMekLevels = query({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, args) => {
    const levels = await ctx.db
      .query("mekLevels")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .filter((q) => q.neq(q.field("ownershipStatus"), "transferred"))
      .collect();

    return levels;
  },
});

// Get level for a specific Mek
export const getMekLevel = query({
  args: {
    walletAddress: v.string(),
    assetId: v.string(),
  },
  handler: async (ctx, args) => {
    const level = await ctx.db
      .query("mekLevels")
      .withIndex("by_wallet_asset", (q) =>
        q.eq("walletAddress", args.walletAddress).eq("assetId", args.assetId)
      )
      .first();

    return level || null;
  },
});

// Get all levels for a specific Mek (across all wallets) for history
export const getMekLevelHistory = query({
  args: {
    assetId: v.string(),
  },
  handler: async (ctx, args) => {
    const levels = await ctx.db
      .query("mekLevels")
      .withIndex("by_asset", (q) => q.eq("assetId", args.assetId))
      .collect();

    return levels;
  },
});

// Main upgrade mutation
export const upgradeMekLevel = mutation({
  args: {
    walletAddress: v.string(),
    assetId: v.string(),
    mekNumber: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // 1. Get the current gold mining data for the wallet
    const goldMiningData = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!goldMiningData) {
      throw new Error("Wallet not found in gold mining system");
    }

    // Check if wallet is verified
    if (!goldMiningData.isBlockchainVerified) {
      throw new Error("Wallet must be blockchain verified to upgrade Meks");
    }

    // 2. Verify the wallet still owns this Mek
    const ownedMek = goldMiningData.ownedMeks.find(
      (mek) => mek.assetId === args.assetId
    );

    if (!ownedMek) {
      throw new Error("You do not own this Mek");
    }

    // 3. Get or create the level record for this wallet+mek
    let mekLevel = await ctx.db
      .query("mekLevels")
      .withIndex("by_wallet_asset", (q) =>
        q.eq("walletAddress", args.walletAddress).eq("assetId", args.assetId)
      )
      .first();

    if (!mekLevel) {
      // Create new level record
      await ctx.db.insert("mekLevels", {
        walletAddress: args.walletAddress,
        assetId: args.assetId,
        mekNumber: args.mekNumber,
        currentLevel: 1,
        totalGoldSpent: 0,
        levelAcquiredAt: now,
        lastVerifiedAt: now,
        ownershipStatus: "verified",
        createdAt: now,
        updatedAt: now,
      });

      mekLevel = await ctx.db
        .query("mekLevels")
        .withIndex("by_wallet_asset", (q) =>
          q.eq("walletAddress", args.walletAddress).eq("assetId", args.assetId)
        )
        .first();
    }

    if (!mekLevel) {
      throw new Error("Failed to create level record");
    }

    // 4. Check if the Mek can be upgraded
    if (mekLevel.currentLevel >= 10) {
      throw new Error("Mek is already at maximum level");
    }

    // 5. Calculate upgrade cost
    const upgradeCost = calculateUpgradeCost(mekLevel.currentLevel);

    // 6. Calculate current gold balance (with time-based accumulation)
    const hoursSinceLastSnapshot = goldMiningData.lastSnapshotTime
      ? (now - goldMiningData.lastSnapshotTime) / (1000 * 60 * 60)
      : 0;

    const goldSinceSnapshot = goldMiningData.totalGoldPerHour * hoursSinceLastSnapshot;
    const currentGold = Math.min(
      50000, // Cap at 50,000 gold
      (goldMiningData.accumulatedGold || 0) + goldSinceSnapshot
    );

    // 7. Check if player has enough gold
    if (currentGold < upgradeCost) {
      throw new Error(
        `Insufficient gold. You have ${Math.floor(
          currentGold
        )} gold but need ${upgradeCost} gold`
      );
    }

    // 8. Create upgrade transaction ID
    const upgradeId = `${args.walletAddress}-${args.assetId}-${now}`;

    // 9. Log the upgrade attempt
    await ctx.db.insert("levelUpgrades", {
      upgradeId,
      walletAddress: args.walletAddress,
      assetId: args.assetId,
      mekNumber: args.mekNumber,
      fromLevel: mekLevel.currentLevel,
      toLevel: mekLevel.currentLevel + 1,
      goldCost: upgradeCost,
      signatureRequired: mekLevel.currentLevel >= 7, // Require signature for levels 8-10
      ownershipVerified: true,
      status: "pending",
      timestamp: now,
      goldBalanceBefore: currentGold,
      goldBalanceAfter: currentGold - upgradeCost,
    });

    // 10. ATOMIC TRANSACTION: Deduct gold and update level
    try {
      // Deduct gold from accumulated balance
      const newAccumulatedGold = currentGold - upgradeCost;

      // Update gold mining record
      await ctx.db.patch(goldMiningData._id, {
        accumulatedGold: newAccumulatedGold,
        lastSnapshotTime: now,
        totalGoldSpentOnUpgrades: (goldMiningData.totalGoldSpentOnUpgrades || 0) + upgradeCost,
        totalUpgradesPurchased: (goldMiningData.totalUpgradesPurchased || 0) + 1,
        lastUpgradeSpend: now,
        updatedAt: now,
      });

      // Update Mek level
      await ctx.db.patch(mekLevel._id, {
        currentLevel: mekLevel.currentLevel + 1,
        totalGoldSpent: mekLevel.totalGoldSpent + upgradeCost,
        lastUpgradeAt: now,
        updatedAt: now,
      });

      // Mark upgrade as completed
      const upgradeRecord = await ctx.db
        .query("levelUpgrades")
        .filter((q) => q.eq(q.field("upgradeId"), upgradeId))
        .first();

      if (upgradeRecord) {
        await ctx.db.patch(upgradeRecord._id, {
          status: "completed",
          completedAt: now,
        });
      }

      return {
        success: true,
        newLevel: mekLevel.currentLevel + 1,
        goldSpent: upgradeCost,
        remainingGold: newAccumulatedGold,
      };
    } catch (error) {
      // Mark upgrade as failed
      const upgradeRecord = await ctx.db
        .query("levelUpgrades")
        .filter((q) => q.eq(q.field("upgradeId"), upgradeId))
        .first();

      if (upgradeRecord) {
        await ctx.db.patch(upgradeRecord._id, {
          status: "failed",
          failureReason: String(error),
        });
      }

      throw error;
    }
  },
});

// Check and reset levels for transferred Meks
export const checkAndResetTransferredMeks = mutation({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();

    // Get gold mining data with current Meks
    const goldMiningData = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!goldMiningData) {
      return { checked: 0, reset: 0 };
    }

    const currentMekIds = new Set(
      goldMiningData.ownedMeks.map((mek) => mek.assetId)
    );

    // Get all level records for this wallet
    const mekLevels = await ctx.db
      .query("mekLevels")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .collect();

    let checkedCount = 0;
    let resetCount = 0;

    for (const levelRecord of mekLevels) {
      checkedCount++;

      // If this Mek is no longer owned by the wallet, mark it as transferred
      if (
        !currentMekIds.has(levelRecord.assetId) &&
        levelRecord.ownershipStatus === "verified"
      ) {
        // Log the transfer event
        await ctx.db.insert("mekTransferEvents", {
          assetId: levelRecord.assetId,
          fromWallet: args.walletAddress,
          toWallet: "unknown", // We don't know the new owner yet
          levelAtTransfer: levelRecord.currentLevel,
          goldInvestedAtTransfer: levelRecord.totalGoldSpent,
          detectedBy: "ownership_check",
          detectedAt: now,
          processed: true,
          processedAt: now,
        });

        // Mark the level record as transferred
        await ctx.db.patch(levelRecord._id, {
          ownershipStatus: "transferred",
          updatedAt: now,
        });

        resetCount++;
      }
    }

    return {
      checked: checkedCount,
      reset: resetCount,
    };
  },
});

// Initialize level records for newly detected Meks
export const initializeMekLevels = mutation({
  args: {
    walletAddress: v.string(),
    meks: v.array(
      v.object({
        assetId: v.string(),
        mekNumber: v.optional(v.number()),
      })
    ),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    let initialized = 0;

    for (const mek of args.meks) {
      // Check if level record already exists
      const existing = await ctx.db
        .query("mekLevels")
        .withIndex("by_wallet_asset", (q) =>
          q.eq("walletAddress", args.walletAddress).eq("assetId", mek.assetId)
        )
        .first();

      if (!existing) {
        // Check if this Mek was previously owned by this wallet
        const history = await ctx.db
          .query("mekLevels")
          .withIndex("by_asset", (q) => q.eq("assetId", mek.assetId))
          .filter((q) =>
            q.and(
              q.eq(q.field("walletAddress"), args.walletAddress),
              q.eq(q.field("ownershipStatus"), "transferred")
            )
          )
          .first();

        if (history) {
          // Restore previous level
          await ctx.db.patch(history._id, {
            ownershipStatus: "verified",
            levelAcquiredAt: now,
            lastVerifiedAt: now,
            updatedAt: now,
          });
        } else {
          // Create new level record
          await ctx.db.insert("mekLevels", {
            walletAddress: args.walletAddress,
            assetId: mek.assetId,
            mekNumber: mek.mekNumber,
            currentLevel: 1,
            totalGoldSpent: 0,
            levelAcquiredAt: now,
            lastVerifiedAt: now,
            ownershipStatus: "verified",
            createdAt: now,
            updatedAt: now,
          });
        }
        initialized++;
      }
    }

    return { initialized };
  },
});

// Get upgrade history for a wallet
export const getUpgradeHistory = query({
  args: {
    walletAddress: v.string(),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const query = ctx.db
      .query("levelUpgrades")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .order("desc");

    if (args.limit) {
      return await query.take(args.limit);
    }

    return await query.collect();
  },
});

// Get leaderboard of highest level Meks
export const getMekLevelLeaderboard = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const allLevels = await ctx.db
      .query("mekLevels")
      .withIndex("by_level")
      .order("desc")
      .filter((q) => q.eq(q.field("ownershipStatus"), "verified"))
      .take(args.limit || 10);

    return allLevels;
  },
});