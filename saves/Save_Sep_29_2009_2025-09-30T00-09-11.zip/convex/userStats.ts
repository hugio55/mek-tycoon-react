import { v } from "convex/values";
import { query } from "./_generated/server";

export const getUserStats = query({
  args: {
    walletAddress: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // If no wallet address provided, return default stats
    if (!args.walletAddress) {
      return {
        mekCount: 0,
        totalCumulativeGold: 0,
        currentGold: 0,
        goldPerHour: 0,
      };
    }

    // Get the goldMining record for this wallet
    const goldMiner = await ctx.db
      .query("goldMining")
      .withIndex("by_wallet", (q) => q.eq("walletAddress", args.walletAddress))
      .first();

    if (!goldMiner) {
      return {
        mekCount: 0,
        totalCumulativeGold: 0,
        currentGold: 0,
        goldPerHour: 0,
      };
    }

    // Calculate current gold (respecting verification status)
    const now = Date.now();
    let currentGold = goldMiner.accumulatedGold || 0;
    let goldEarnedSinceLastUpdate = 0;

    if (goldMiner.isBlockchainVerified === true) {
      const lastUpdateTime = goldMiner.lastSnapshotTime || goldMiner.updatedAt || goldMiner.createdAt;
      const hoursSinceLastUpdate = (now - lastUpdateTime) / (1000 * 60 * 60);
      goldEarnedSinceLastUpdate = goldMiner.totalGoldPerHour * hoursSinceLastUpdate;
      currentGold = Math.min(50000, (goldMiner.accumulatedGold || 0) + goldEarnedSinceLastUpdate);
    }

    // Calculate cumulative gold in real-time
    // Start with the stored cumulative gold
    let baseCumulativeGold = goldMiner.totalCumulativeGold || 0;

    // If totalCumulativeGold isn't set yet, estimate from current accumulated gold
    if (!goldMiner.totalCumulativeGold) {
      baseCumulativeGold = (goldMiner.accumulatedGold || 0) + (goldMiner.totalGoldSpentOnUpgrades || 0);
    }

    // Add the gold earned since last update (this makes it real-time)
    // Only add if verified (same as current gold calculation)
    const totalCumulativeGold = baseCumulativeGold + goldEarnedSinceLastUpdate;

    return {
      mekCount: goldMiner.ownedMeks.length,
      totalCumulativeGold: Math.floor(totalCumulativeGold),
      currentGold: Math.floor(currentGold),
      goldPerHour: goldMiner.totalGoldPerHour,
    };
  },
});