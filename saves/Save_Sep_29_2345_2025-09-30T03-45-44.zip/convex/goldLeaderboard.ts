import { v } from "convex/values";
import { query } from "./_generated/server";

// Get top 5 miners from goldMining table with real-time gold calculations
export const getTopGoldMiners = query({
  args: {
    currentWallet: v.optional(v.string()),
  },
  handler: async (ctx, { currentWallet }) => {
    // Get all verified gold miners (using isBlockchainVerified field)
    const miners = await ctx.db
      .query("goldMining")
      .filter(q => q.eq(q.field("isBlockchainVerified"), true))
      .collect();

    if (miners.length === 0) {
      return [];
    }

    const now = Date.now();

    // Calculate current gold for each miner
    const minersWithCurrentGold = miners.map(miner => {
      // Calculate accumulated gold since last checkpoint
      const lastCheckpoint = miner.lastGoldCheckpoint || miner.lastLogin || now;
      const timeDiff = Math.max(0, now - lastCheckpoint);
      const hoursElapsed = timeDiff / (1000 * 60 * 60);

      // Only accumulate if blockchain verified
      const accumulatedGold = miner.isBlockchainVerified ?
        (miner.totalGoldPerHour || 0) * hoursElapsed : 0;

      const currentGold = (miner.totalGold || 0) + accumulatedGold;

      return {
        walletAddress: miner.walletAddress,
        displayWallet: miner.companyName || (miner.walletAddress ?
          `${miner.walletAddress.slice(0, 8)}...${miner.walletAddress.slice(-6)}` :
          'Unknown'),
        currentGold: Math.floor(currentGold),
        hourlyRate: miner.totalGoldPerHour || 0,
        mekCount: miner.ownedMeks?.length || 0,
        isCurrentUser: currentWallet === miner.walletAddress,
        lastActive: miner.lastActiveTime || miner.lastLogin,
      };
    });

    // Sort by current gold (highest first) and take top 5
    const topMiners = minersWithCurrentGold
      .sort((a, b) => b.currentGold - a.currentGold)
      .slice(0, 5)
      .map((miner, index) => ({
        ...miner,
        rank: index + 1,
      }));

    return topMiners;
  },
});

// Get wallet's Meks for the lightbox display
export const getWalletMeksForDisplay = query({
  args: {
    walletAddress: v.string(),
  },
  handler: async (ctx, { walletAddress }) => {
    // Get gold mining data
    const goldMiningData = await ctx.db
      .query("goldMining")
      .filter(q => q.eq(q.field("walletAddress"), walletAddress))
      .first();

    if (!goldMiningData || !goldMiningData.ownedMeks) {
      return {
        walletAddress,
        displayWallet: `${walletAddress.slice(0, 8)}...${walletAddress.slice(-6)}`,
        meks: [],
        totalMeks: 0,
      };
    }

    // Get level data for the Meks
    const mekLevels = await ctx.db
      .query("mekLevels")
      .filter(q => q.eq(q.field("walletAddress"), walletAddress))
      .collect();

    // Create level map
    const levelMap = new Map(
      mekLevels.map(level => [level.assetId, level.level])
    );

    // Format Meks with their levels
    const meksWithLevels = goldMiningData.ownedMeks.map(mek => {
      // Clean the source key for image URL
      const cleanSourceKey = mek.sourceKey ?
        mek.sourceKey.replace(/-[A-Z]$/, '').toLowerCase() : null;

      return {
        assetId: mek.assetId,
        assetName: mek.assetName,
        level: levelMap.get(mek.assetId) || 1,
        goldPerHour: mek.goldPerHour,
        rarityRank: mek.rarityRank,
        imageUrl: cleanSourceKey ?
          `/mek-images/150px/${cleanSourceKey}.webp` :
          mek.imageUrl || null,
        headVariation: mek.headVariation,
        bodyVariation: mek.bodyVariation,
        itemVariation: mek.itemVariation,
      };
    });

    // Sort by level, then by gold rate
    meksWithLevels.sort((a, b) => {
      if (b.level !== a.level) return b.level - a.level;
      return b.goldPerHour - a.goldPerHour;
    });

    return {
      walletAddress,
      displayWallet: goldMiningData.companyName || `${walletAddress.slice(0, 8)}...${walletAddress.slice(-6)}`,
      meks: meksWithLevels,
      totalMeks: meksWithLevels.length,
      totalGoldPerHour: goldMiningData.totalGoldPerHour || 0,
    };
  },
});

// Subscribe to real-time updates for the top 5
export const subscribeToTopMiners = query({
  args: {},
  handler: async (ctx) => {
    // This query will automatically re-run when goldMining data changes
    const miners = await ctx.db
      .query("goldMining")
      .filter(q => q.eq(q.field("isBlockchainVerified"), true))
      .collect();

    const now = Date.now();

    // Process and return just the data needed for real-time updates
    const processedMiners = miners.map(miner => {
      const lastCheckpoint = miner.lastGoldCheckpoint || miner.lastLogin || now;
      const timeDiff = Math.max(0, now - lastCheckpoint);
      const hoursElapsed = timeDiff / (1000 * 60 * 60);
      const accumulatedGold = miner.isBlockchainVerified ?
        (miner.totalGoldPerHour || 0) * hoursElapsed : 0;
      const currentGold = (miner.totalGold || 0) + accumulatedGold;

      return {
        walletAddress: miner.walletAddress,
        currentGold: Math.floor(currentGold),
        hourlyRate: miner.totalGoldPerHour || 0,
      };
    });

    // Return top 5 sorted by gold
    return processedMiners
      .sort((a, b) => b.currentGold - a.currentGold)
      .slice(0, 5);
  },
});