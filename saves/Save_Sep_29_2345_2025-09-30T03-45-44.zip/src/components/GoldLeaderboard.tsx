'use client';

import { useState, useEffect } from 'react';
import { useQuery } from 'convex/react';
import { api } from '@/convex/_generated/api';

interface LeaderboardEntry {
  rank: number;
  walletAddress: string;
  displayWallet: string;
  currentGold: number;
  hourlyRate: number;
  mekCount: number;
  isCurrentUser: boolean;
}

interface WalletMek {
  assetId: string;
  assetName: string;
  level: number;
  goldPerHour: number;
  imageUrl: string | null;
}

interface GoldLeaderboardProps {
  currentWallet?: string;
}

export default function GoldLeaderboard({ currentWallet }: GoldLeaderboardProps) {
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [realtimeGold, setRealtimeGold] = useState<Map<string, number>>(new Map());

  // Get top miners data
  const topMiners = useQuery(api.goldLeaderboard.getTopGoldMiners, {
    currentWallet: currentWallet,
  });

  // Get selected wallet's Meks
  const walletMeks = useQuery(api.goldLeaderboard.getWalletMeksForDisplay,
    selectedWallet ? { walletAddress: selectedWallet } : 'skip'
  );

  // Subscribe to real-time updates
  const realtimeData = useQuery(api.goldLeaderboard.subscribeToTopMiners);

  // Initialize and animate real-time gold
  useEffect(() => {
    if (!topMiners) return;

    // Initialize the map with current gold values
    const initMap = new Map();
    topMiners.forEach(miner => {
      initMap.set(miner.walletAddress, miner.currentGold);
    });
    setRealtimeGold(initMap);

    // Start the animation
    const interval = setInterval(() => {
      setRealtimeGold(prev => {
        const newMap = new Map(prev);
        topMiners.forEach(miner => {
          const currentValue = newMap.get(miner.walletAddress) || miner.currentGold;
          const increment = (miner.hourlyRate / 3600) / 10; // Gold per decisecond (1/10th second)
          newMap.set(miner.walletAddress, currentValue + increment);
        });
        return newMap;
      });
    }, 100); // Update 10 times per second for smooth animation

    return () => clearInterval(interval);
  }, [topMiners]);

  // Update base values when real-time data changes
  useEffect(() => {
    if (realtimeData) {
      const newMap = new Map();
      realtimeData.forEach(miner => {
        newMap.set(miner.walletAddress, miner.currentGold);
      });
      setRealtimeGold(newMap);
    }
  }, [realtimeData]);

  // Always create 3 slots, fill with empty if needed
  const displayData = [...(topMiners || [])];
  while (displayData.length < 3) {
    displayData.push(null);
  }

  return (
    <>
      {/* Top Companies styled like Mek cards */}
      <div className="w-[500px]">
        <div className="bg-black/10 border-2 border-yellow-500/50 backdrop-blur-xl relative overflow-hidden">
          {/* Subtle grid overlay */}
          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: `
                repeating-linear-gradient(0deg, transparent, transparent 9px, #FAB617 9px, #FAB617 10px),
                repeating-linear-gradient(90deg, transparent, transparent 9px, #FAB617 9px, #FAB617 10px)
              `
            }}
          />

          {/* Header */}
          <div className="relative bg-gradient-to-r from-black/60 via-gray-900/60 to-black/60 backdrop-blur-md border-b border-yellow-500/30 p-2">
            <div className="flex items-center justify-between">
              <div className="text-2xl font-black text-white" style={{
                textShadow: '0 0 20px rgba(250, 182, 23, 0.5)',
                fontFamily: 'Orbitron, monospace'
              }}>
                TOP COMPANIES
              </div>
              <div className="text-right">
                <div className="text-sm font-bold text-yellow-400">Cumulative Gold</div>
                <div className="text-[10px] text-gray-500">Gold/hr</div>
              </div>
            </div>
          </div>

          {/* Company slots */}
          <div className="relative space-y-1 p-2 bg-black/80 backdrop-blur-sm">
            {displayData.map((miner, index) => {
              const rank = index + 1;
              const displayGold = miner ? (realtimeGold.get(miner.walletAddress) || miner.currentGold) : 0;

              // Rank colors
              const rankColor = rank === 1 ? '#FFD700' : rank === 2 ? '#C0C0C0' : rank === 3 ? '#CD7F32' : '#FFFFFF';
              const rankGlow = rank === 1 ? '0 0 20px rgba(255, 215, 0, 0.8)' :
                                rank === 2 ? '0 0 15px rgba(192, 192, 192, 0.6)' :
                                rank === 3 ? '0 0 10px rgba(205, 127, 50, 0.6)' : 'none';

              return (
                <div key={`slot-${rank}`} className="relative group">
                  <div className="relative bg-gradient-to-r from-black/60 via-gray-900/60 to-black/60 backdrop-blur-md border border-yellow-500/30 p-2">
                    {miner ? (
                      <>
                        {/* Active company */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {/* Rank */}
                            <div className="text-3xl font-black" style={{
                              color: rankColor,
                              textShadow: rankGlow,
                              fontFamily: 'Orbitron, monospace',
                              minWidth: '40px'
                            }}>
                              {rank}
                            </div>

                            {/* Company info */}
                            <button
                              onClick={() => setSelectedWallet(miner.walletAddress)}
                              className="text-left hover:text-yellow-400 transition-colors"
                            >
                              <div className="text-sm font-bold text-white">
                                {miner.displayWallet}
                                {miner.isCurrentUser && (
                                  <span className="ml-2 text-[10px] text-yellow-400 bg-yellow-400/20 px-1.5 py-0.5 rounded">YOU</span>
                                )}
                              </div>
                              <div className="text-[10px] text-gray-500">{miner.mekCount} Meks</div>
                            </button>
                          </div>

                          {/* Gold stats */}
                          <div className="text-right">
                            <div className="text-lg font-bold text-yellow-400">
                              {Math.floor(displayGold).toLocaleString()}
                            </div>
                            <div className="text-[10px] text-gray-500">{miner.hourlyRate.toFixed(0)}/hr</div>
                          </div>
                        </div>
                      </>
                    ) : (
                      <>
                        {/* Empty slot */}
                        <div className="flex items-center justify-between opacity-30">
                          <div className="flex items-center gap-3">
                            {/* Rank */}
                            <div className="text-3xl font-black" style={{
                              color: rankColor,
                              textShadow: rankGlow,
                              fontFamily: 'Orbitron, monospace',
                              minWidth: '40px'
                            }}>
                              {rank}
                            </div>

                            {/* Empty placeholder */}
                            <div>
                              <div className="text-sm font-bold text-gray-600">---</div>
                              <div className="text-[10px] text-gray-600">No Company</div>
                            </div>
                          </div>

                          {/* Empty stats */}
                          <div className="text-right">
                            <div className="text-lg font-bold text-gray-600">0</div>
                            <div className="text-[10px] text-gray-600">0/hr</div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Meks Lightbox */}
      {selectedWallet && walletMeks && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          onClick={() => setSelectedWallet(null)}
        >
          <div
            className="relative max-w-5xl w-full bg-black/90 border border-yellow-500/30 p-6 rounded-sm max-h-[80vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-yellow-500/20">
              <div>
                <h2 className="text-xl font-mono text-yellow-400 tracking-wider">
                  {walletMeks.displayWallet}
                </h2>
                <p className="text-xs text-white/50 font-mono mt-1">
                  {walletMeks.totalMeks} Meks • {walletMeks.totalGoldPerHour?.toFixed(1)} Gold/hr
                </p>
              </div>
              <button
                onClick={() => setSelectedWallet(null)}
                className="text-yellow-500/50 hover:text-yellow-400 text-2xl font-bold w-8 h-8 flex items-center justify-center"
              >
                ×
              </button>
            </div>

            {/* Meks Grid */}
            <div className="overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
              {walletMeks.meks.length === 0 ? (
                <p className="text-center text-white/30 py-8">No Meks found</p>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
                  {walletMeks.meks.map((mek) => (
                    <div
                      key={mek.assetId}
                      className="relative bg-black/50 border border-white/10 hover:border-yellow-500/30 transition-all group"
                    >
                      {/* Level Badge */}
                      <div className="absolute top-1 right-1 bg-black/80 backdrop-blur-sm px-1.5 py-0.5 rounded-sm z-10">
                        <span className="text-yellow-400 font-bold text-xs">
                          Lv.{mek.level}
                        </span>
                      </div>

                      {/* Mek Image */}
                      <div className="aspect-square bg-black/20 overflow-hidden">
                        {mek.imageUrl ? (
                          <img
                            src={mek.imageUrl}
                            alt={mek.assetName}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-white/20 text-xs">
                            No Image
                          </div>
                        )}
                      </div>

                      {/* Info */}
                      <div className="p-2">
                        <p className="text-[10px] text-white/60 font-mono truncate">
                          {mek.assetName}
                        </p>
                        <p className="text-xs text-yellow-400/80 font-mono">
                          {mek.goldPerHour.toFixed(1)} g/hr
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Custom scrollbar styles */}
      <style jsx>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(250, 204, 21, 0.3);
          border-radius: 3px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(250, 204, 21, 0.5);
        }
      `}</style>
    </>
  );
}