import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { Doc, Id } from "./_generated/dataModel";

// Mock data for testing - in production this would come from Blockfrost/Koios
const MOCK_MEK_VARIATIONS = [
  "aa1-aa4-gh1", "bc2-dm1-ap1", "cf3-el2-bm2", "dg4-fm3-cn3",
  "eh5-gn4-do4", "fi6-ho5-ep5", "gj7-ip6-fq6", "hk8-jq7-gr7",
  "il9-kr8-hs8", "jm10-ls9-it9", "kn11-mt10-ju10", "lo12-nu11-kv11"
];

// Generate mock wallet addresses
function generateMockWallet(): string {
  const prefix = "addr1q";
  const chars = "0123456789abcdefghijklmnopqrstuvwxyz";
  let result = prefix;
  for (let i = 0; i < 98; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// Bot behavior profiles
const BEHAVIOR_PROFILES = {
  active: {
    loginFrequency: 0.9,      // 90% chance to be online
    goldCollectionRate: 0.95,  // Collects gold 95% of the time
    verificationDelay: 1000,    // Verifies quickly (1 second)
    sessionDuration: 7200000,   // 2 hours average session
  },
  moderate: {
    loginFrequency: 0.6,
    goldCollectionRate: 0.7,
    verificationDelay: 5000,
    sessionDuration: 3600000,   // 1 hour
  },
  casual: {
    loginFrequency: 0.3,
    goldCollectionRate: 0.5,
    verificationDelay: 10000,
    sessionDuration: 1800000,   // 30 mins
  },
  dormant: {
    loginFrequency: 0.1,
    goldCollectionRate: 0.2,
    verificationDelay: 30000,
    sessionDuration: 600000,    // 10 mins
  }
};

// Get test bots
export const getTestBots = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("testBots")
      .order("desc")
      .take(100);
  },
});

// Get bot status overview
export const getBotStatus = query({
  args: {},
  handler: async (ctx) => {
    const bots = await ctx.db.query("testBots").collect();

    const activeBots = bots.filter(b => b.isActive).length;
    const verifiedBots = bots.filter(b => b.isVerified).length;
    const totalGold = bots.reduce((sum, b) => sum + (b.goldBalance || 0), 0);

    // Get simulation status
    const simStatus = await ctx.db.query("botSimulation").first();

    return {
      totalBots: bots.length,
      activeBots,
      verifiedBots,
      totalGold,
      isRunning: simStatus?.isRunning || false,
      simulationSpeed: simStatus?.speed || 1
    };
  },
});

// Get active wallets from snapshot
export const getActiveWallets = query({
  args: {},
  handler: async (ctx) => {
    const snapshot = await ctx.db.query("walletSnapshot").collect();
    return snapshot.map(w => ({
      address: w.address,
      mekCount: w.mekCount,
      lastActivity: w.lastActivity,
      isActive: w.isActive
    }));
  },
});

// Create wallet snapshot
export const createWalletSnapshot = mutation({
  args: {
    activeOnly: v.boolean(),
    daysBack: v.number()
  },
  handler: async (ctx, args) => {
    // Clear existing snapshot
    const existing = await ctx.db.query("walletSnapshot").collect();
    for (const wallet of existing) {
      await ctx.db.delete(wallet._id);
    }

    // Generate mock active wallets
    const mockWallets = [];
    const totalWallets = 400; // Simulating ~400 active wallets from 1300 total

    for (let i = 0; i < totalWallets; i++) {
      const mekCount =
        i < 20 ? Math.floor(Math.random() * 50) + 50 :  // 20 whales
        i < 100 ? Math.floor(Math.random() * 40) + 10 : // 80 medium
        Math.floor(Math.random() * 9) + 1;               // Rest small

      const wallet = {
        address: generateMockWallet(),
        mekCount,
        mekVariations: Array.from({ length: Math.min(mekCount, 12) }, () =>
          MOCK_MEK_VARIATIONS[Math.floor(Math.random() * MOCK_MEK_VARIATIONS.length)]
        ),
        lastActivity: Date.now() - Math.floor(Math.random() * args.daysBack * 24 * 60 * 60 * 1000),
        isActive: true
      };

      await ctx.db.insert("walletSnapshot", wallet);
      mockWallets.push(wallet);
    }

    return { walletsAdded: totalWallets };
  },
});

// Initialize bots from wallet snapshot
export const initializeBots = mutation({
  args: {
    config: v.object({
      totalBots: v.number(),
      behaviorPresets: v.object({
        active: v.number(),
        moderate: v.number(),
        casual: v.number(),
        dormant: v.number()
      }),
      simulationSpeed: v.number(),
      autoVerify: v.boolean(),
      goldAccumulation: v.boolean()
    }),
    walletPool: v.array(v.any())
  },
  handler: async (ctx, args) => {
    // Clear existing bots
    const existing = await ctx.db.query("testBots").collect();
    for (const bot of existing) {
      await ctx.db.delete(bot._id);
    }

    // Select random wallets from pool
    const selectedWallets = [];
    const poolCopy = [...args.walletPool];

    for (let i = 0; i < Math.min(args.config.totalBots, poolCopy.length); i++) {
      const randomIndex = Math.floor(Math.random() * poolCopy.length);
      selectedWallets.push(poolCopy.splice(randomIndex, 1)[0]);
    }

    // Create bots with assigned behaviors
    let behaviorCounts = { ...args.config.behaviorPresets };
    const behaviors = Object.keys(behaviorCounts) as Array<keyof typeof behaviorCounts>;

    for (const wallet of selectedWallets) {
      // Assign behavior type
      let behaviorType = 'casual' as keyof typeof behaviorCounts;
      for (const behavior of behaviors) {
        if (behaviorCounts[behavior] > 0) {
          behaviorType = behavior;
          behaviorCounts[behavior]--;
          break;
        }
      }

      const bot = {
        walletAddress: wallet.address,
        mekCount: wallet.mekCount,
        mekVariations: wallet.mekVariations || [],
        behaviorType,
        isActive: false,
        isVerified: false,
        goldBalance: 0,
        goldPerHour: wallet.mekCount * 10, // Base rate
        lastLogin: Date.now(),
        lastGoldCollection: Date.now(),
        sessionStarted: undefined,
        createdAt: Date.now()
      };

      await ctx.db.insert("testBots", bot);
    }

    // Initialize simulation config
    const simConfig = await ctx.db.query("botSimulation").first();
    if (simConfig) {
      await ctx.db.patch(simConfig._id, {
        isRunning: false,
        speed: args.config.simulationSpeed,
        autoVerify: args.config.autoVerify,
        goldAccumulation: args.config.goldAccumulation
      });
    } else {
      await ctx.db.insert("botSimulation", {
        isRunning: false,
        speed: args.config.simulationSpeed,
        autoVerify: args.config.autoVerify,
        goldAccumulation: args.config.goldAccumulation,
        lastTick: Date.now()
      });
    }

    return { botsCreated: selectedWallets.length };
  },
});

// Start simulation
export const startSimulation = mutation({
  args: {
    speed: v.number()
  },
  handler: async (ctx, args) => {
    const simConfig = await ctx.db.query("botSimulation").first();
    if (!simConfig) {
      throw new Error("Simulation not initialized");
    }

    await ctx.db.patch(simConfig._id, {
      isRunning: true,
      speed: args.speed,
      lastTick: Date.now()
    });

    // Start initial bot activities
    const bots = await ctx.db.query("testBots").collect();

    for (const bot of bots) {
      const profile = BEHAVIOR_PROFILES[bot.behaviorType as keyof typeof BEHAVIOR_PROFILES];

      // Randomly activate bots based on behavior
      if (Math.random() < profile.loginFrequency) {
        await ctx.db.patch(bot._id, {
          isActive: true,
          lastLogin: Date.now(),
          sessionStarted: Date.now()
        });

        // Auto-verify if enabled
        if (simConfig.autoVerify && Math.random() < 0.8) {
          setTimeout(async () => {
            await ctx.db.patch(bot._id, {
              isVerified: true
            });
          }, profile.verificationDelay / args.speed);
        }
      }
    }

    return { success: true };
  },
});

// Stop simulation
export const stopSimulation = mutation({
  args: {},
  handler: async (ctx) => {
    const simConfig = await ctx.db.query("botSimulation").first();
    if (!simConfig) {
      throw new Error("Simulation not initialized");
    }

    await ctx.db.patch(simConfig._id, {
      isRunning: false
    });

    // Deactivate all bots
    const bots = await ctx.db.query("testBots").collect();
    for (const bot of bots) {
      if (bot.isActive) {
        await ctx.db.patch(bot._id, {
          isActive: false,
          sessionStarted: undefined
        });
      }
    }

    return { success: true };
  },
});

// Simulation tick - should be called periodically
export const simulationTick = mutation({
  args: {},
  handler: async (ctx) => {
    const simConfig = await ctx.db.query("botSimulation").first();
    if (!simConfig || !simConfig.isRunning) {
      return { processed: 0 };
    }

    const now = Date.now();
    const timeDelta = now - simConfig.lastTick;
    const adjustedDelta = timeDelta * simConfig.speed;

    const bots = await ctx.db.query("testBots").collect();
    let processed = 0;

    for (const bot of bots) {
      const profile = BEHAVIOR_PROFILES[bot.behaviorType as keyof typeof BEHAVIOR_PROFILES];

      // Handle active bots
      if (bot.isActive) {
        // Check if session should end
        if (bot.sessionStarted && (now - bot.sessionStarted) > (profile.sessionDuration / simConfig.speed)) {
          await ctx.db.patch(bot._id, {
            isActive: false,
            sessionStarted: undefined
          });
          continue;
        }

        // Collect gold if verified
        if (bot.isVerified && simConfig.goldAccumulation) {
          if (Math.random() < profile.goldCollectionRate) {
            const goldEarned = Math.floor((bot.goldPerHour / 3600000) * adjustedDelta);
            await ctx.db.patch(bot._id, {
              goldBalance: bot.goldBalance + goldEarned,
              lastGoldCollection: now
            });
          }
        }

        // Random verification for unverified bots
        if (!bot.isVerified && simConfig.autoVerify && Math.random() < 0.01) {
          await ctx.db.patch(bot._id, {
            isVerified: true
          });
        }

        // Random de-verification (simulating expiry)
        if (bot.isVerified && Math.random() < 0.001) {
          await ctx.db.patch(bot._id, {
            isVerified: false
          });
        }
      } else {
        // Check if bot should login
        if (Math.random() < (profile.loginFrequency * 0.01)) {
          await ctx.db.patch(bot._id, {
            isActive: true,
            lastLogin: now,
            sessionStarted: now
          });
        }
      }

      processed++;
    }

    // Update last tick
    await ctx.db.patch(simConfig._id, {
      lastTick: now
    });

    return { processed };
  },
});

// Clear all bots
export const clearAllBots = mutation({
  args: {},
  handler: async (ctx) => {
    // Clear bots
    const bots = await ctx.db.query("testBots").collect();
    for (const bot of bots) {
      await ctx.db.delete(bot._id);
    }

    // Clear snapshot
    const snapshot = await ctx.db.query("walletSnapshot").collect();
    for (const wallet of snapshot) {
      await ctx.db.delete(wallet._id);
    }

    // Reset simulation
    const simConfig = await ctx.db.query("botSimulation").first();
    if (simConfig) {
      await ctx.db.patch(simConfig._id, {
        isRunning: false
      });
    }

    return { success: true };
  },
});

// Time jump - simulate jumping forward in time
export const timeJump = mutation({
  args: {
    hours: v.number()
  },
  handler: async (ctx, args) => {
    const simConfig = await ctx.db.query("botSimulation").first();
    if (!simConfig) {
      throw new Error("Simulation not initialized");
    }

    // Convert hours to milliseconds
    const jumpMs = args.hours * 60 * 60 * 1000;

    const bots = await ctx.db.query("testBots").collect();
    let totalGoldEarned = 0;
    let botsUpdated = 0;

    for (const bot of bots) {
      // Only accumulate for verified bots
      if (bot.isVerified && simConfig.goldAccumulation) {
        const profile = BEHAVIOR_PROFILES[bot.behaviorType as keyof typeof BEHAVIOR_PROFILES];

        // Calculate gold earned based on time jump and behavior
        const effectiveTime = jumpMs * profile.goldCollectionRate;
        const goldEarned = Math.floor((bot.goldPerHour / 3600000) * effectiveTime);

        await ctx.db.patch(bot._id, {
          goldBalance: bot.goldBalance + goldEarned,
          lastGoldCollection: Date.now()
        });

        totalGoldEarned += goldEarned;
        botsUpdated++;
      }

      // Randomly change active/inactive status based on behavior
      const profile = BEHAVIOR_PROFILES[bot.behaviorType as keyof typeof BEHAVIOR_PROFILES];
      const shouldBeActive = Math.random() < profile.loginFrequency;

      if (shouldBeActive !== bot.isActive) {
        await ctx.db.patch(bot._id, {
          isActive: shouldBeActive,
          lastLogin: shouldBeActive ? Date.now() : bot.lastLogin,
          sessionStarted: shouldBeActive ? Date.now() : undefined
        });
      }

      // Randomly verify/unverify bots
      if (!bot.isVerified && simConfig.autoVerify && Math.random() < 0.3) {
        await ctx.db.patch(bot._id, {
          isVerified: true
        });
      } else if (bot.isVerified && Math.random() < 0.05) {
        // Small chance to lose verification
        await ctx.db.patch(bot._id, {
          isVerified: false
        });
      }
    }

    // Update simulation last tick
    await ctx.db.patch(simConfig._id, {
      lastTick: Date.now()
    });

    return {
      success: true,
      hoursJumped: args.hours,
      totalGoldEarned,
      botsUpdated,
      totalBots: bots.length
    };
  },
});