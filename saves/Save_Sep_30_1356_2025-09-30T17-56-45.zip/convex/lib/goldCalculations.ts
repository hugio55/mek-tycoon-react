/**
 * Shared gold calculation utilities
 * Used across frontend and backend to ensure consistency
 */

export interface GoldCalculationParams {
  accumulatedGold: number;
  goldPerHour: number;
  lastSnapshotTime: number;
  isVerified: boolean;
}

/**
 * Calculates current gold based on accumulated gold and time elapsed
 * @param params - Gold calculation parameters
 * @returns Current gold amount (capped at 50,000)
 */
export function calculateCurrentGold(params: GoldCalculationParams): number {
  if (!params.isVerified) {
    return params.accumulatedGold;
  }

  const now = Date.now();
  const hoursSinceLastUpdate = (now - params.lastSnapshotTime) / (1000 * 60 * 60);
  const goldSinceLastUpdate = params.goldPerHour * hoursSinceLastUpdate;
  const calculatedGold = Math.min(50000, params.accumulatedGold + goldSinceLastUpdate);

  return calculatedGold;
}

/**
 * Calculates gold earned since last update
 * @param goldPerHour - Gold mining rate per hour
 * @param lastSnapshotTime - Timestamp of last snapshot
 * @returns Gold earned since last snapshot
 */
export function calculateGoldSinceLastUpdate(
  goldPerHour: number,
  lastSnapshotTime: number
): number {
  const now = Date.now();
  const hoursSinceLastUpdate = (now - lastSnapshotTime) / (1000 * 60 * 60);
  return goldPerHour * hoursSinceLastUpdate;
}

/**
 * Gold cap constant
 */
export const GOLD_CAP = 50000;
